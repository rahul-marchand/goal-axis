#!/bin/bash
set -u
export PATH=$HOME/.local/bin:$PATH UV_NO_SYNC=1 PYTHONUNBUFFERED=1 XLA_PYTHON_CLIENT_PREALLOCATE=false
cd /workspace/gm-craft
D=/workspace/data/craftax/craft; R=$D/runs; LOGS=/workspace/data/logs/craftax
uv run python experiments/023_train_bc.py --demos $D/demos/train.rho100 --hide-values \
  --eval rho100=$D/demos/valid.rho100 rho050=$D/demos/valid.rho050 rho000=$D/demos/valid.rho000 \
  --init-from $R/cxcraft15.s1/checkpoints/step_00030000 --schedule cosine --lr 3e-4 --warmup 500 \
  --out $R/cxcraft15.s1c --seed 11 --steps 60000 --eval-levels 512 --checkpoint-ratio 2.0 \
  --note "Continuation of cxcraft15.s1 (3% reached at 30k): 60k more steps, fresh cosine at 3e-4, from step 30000." \
  > $LOGS/cxcraft15.s1c.log 2>&1 || { echo "CONTINUE_FAILED"; exit 1; }
echo "CONTINUE_DONE"
