#!/bin/bash
# Colour-keyed arms past parity, for the "limits of the dial" figure.
set -u
export PATH=$HOME/.local/bin:$PATH
export PYTHONUNBUFFERED=1
export JAX_COMPILATION_CACHE_DIR=/workspace/data/jax-cache
cd /workspace/GoalMisgeneralisation
UV=$HOME/.local/bin/uv
LEVELS=/workspace/data/levels/values/1.00-0.50@500k
BASES="novalue11g1.s1234 novalue11g1.s9012 novalue11g1.s3456e resnet11nvg1.s1234 resnet11nvg1.s2468 resnet11nvg1.s3456 vit11nvg1.s9012"

for base in $BASES; do
  echo "=== $base: colour-keyed crossing arms"
  $UV run python scripts/value_axis_sweep.py --agent "$base" --objectives 1 \
    --values 1.0 1.1 1.2 --family k --colour-keyed --allow-reorder --steps 400000 \
    || echo "KSWEEP_FAILED $base k1"
  $UV run python scripts/value_axis_sweep.py --agent "$base" --objectives 0 \
    --values 0.5 0.4 0.3 --family k --colour-keyed --allow-reorder --steps 400000 \
    || echo "KSWEEP_FAILED $base k0"
done

for base in $BASES; do
  cp=$(python3 -c "import json;print(json.load(open('/workspace/data/runs/$base/BASE.json'))['checkpoint'])")
  for spec in "k1:0.5" "k0:1.0"; do
    prefix=${spec%%:*}; bv=${spec##*:}
    $UV run python experiments/014_value_axis_analysis.py \
      --base "/workspace/data/runs/$base/$cp" --arms "/workspace/data/runs/$base/arms" \
      --levels "$LEVELS" --prefix "$prefix" --base-value "$bv" --arm-steps 400000 --at -1 \
      > "results/g1-$base-$prefix.txt" 2> "results/g1-$base-$prefix.err" \
      || echo "KMEASURE_FAILED $base $prefix"
  done
done
echo CROSSING_DONE
