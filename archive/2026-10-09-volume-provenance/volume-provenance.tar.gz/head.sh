set -euo pipefail
export PATH=$HOME/.local/bin:$PATH
cd /workspace/GoalMisgeneralisation
git fetch -q origin && git checkout -q steer-distance-field && git pull -q
LOG=/workspace/data/steer-head.txt
: > "$LOG"
uv run python experiments/008_steer_at_the_head.py \
    /workspace/data/runs/clean11fv/local-files/cp_140206080 \
    --levels /workspace/data/levels11 --episodes 2048 2>&1 \
    | grep -viE "userwarning|logger\.warn|gym\.logger|^\s*$" | tee -a "$LOG"
echo "DONEHEAD" | tee -a "$LOG"
