"""Embedding geometry of the route model's colour rows, per base.

The rotation edit turns colour c's row of ``cell_in`` towards the other
colour's, holding its length. How much that can buy depends on where the two
rows already sit, and on whether the value comparison reads them at all. This
prints, per base, the rows' norms, the angles between them and the other input
channels, and how much of the fine-tuned axis lands on the two colour rows --
the geometry behind s2's rotation working and s1's not.
"""

import pathlib
import sys

import numpy as np

sys.path.insert(0, "/workspace/gvf-e9-snap")

from goalmisgen.analysis.input_gain import input_kernel  # noqa: E402
from goalmisgen.analysis.weights import fit_axis_and_drift  # noqa: E402
from goalmisgen.offline.axis import arm_dirs, load_base, load_diffs  # noqa: E402

BASES = sys.argv[1:] or [
    "/workspace/data/offline/runs/bcnv11.s1",
    "/workspace/data/offline/runs/bcnv11.s2",
    "/workspace/data/offline/runs/bcnv11.s3",
]
NAMES = {0: "wall", 1: "agent", 2: "colour 0", 3: "colour 1"}
FIT_WINDOW = 0.45


def angle(a, b):
    c = float(a @ b / (np.linalg.norm(a) * np.linalg.norm(b)))
    return float(np.degrees(np.arccos(np.clip(c, -1, 1))))


for run in BASES:
    run = pathlib.Path(run)
    base = load_base(run)
    kernel = np.asarray(base.params["params"]["cell_in"]["kernel"], dtype=np.float64)  # (n_channels, d_model)
    print(f"\n=== {run.name}  cell_in {kernel.shape}")
    for i in range(kernel.shape[0]):
        print(f"  row {i} ({NAMES.get(i, str(i)):8s}) norm {np.linalg.norm(kernel[i]):.4f}")
    print(f"  angle(colour 0, colour 1) = {angle(kernel[2], kernel[3]):7.1f} deg")
    print(f"  angle(colour 0, wall)     = {angle(kernel[2], kernel[0]):7.1f} deg")
    print(f"  angle(colour 1, wall)     = {angle(kernel[3], kernel[0]):7.1f} deg")
    print(f"  angle(colour 0, agent)    = {angle(kernel[2], kernel[1]):7.1f} deg")
    print(f"  norm(colour 1)/norm(colour 0) = {np.linalg.norm(kernel[3]) / np.linalg.norm(kernel[2]):.3f}")

    arms = arm_dirs(run, "o1", 1000)
    arms = {o: d for o, d in arms.items() if 1e-9 < abs(o) <= FIT_WINDOW}
    if not arms:
        print("  (no arms in the fit window)")
        continue
    diffs = load_diffs(base, arms, dtype=np.float64)
    offsets = np.array(sorted(diffs))
    stack = np.stack([diffs[o] for o in offsets])
    axis, _drift = fit_axis_and_drift(offsets, stack)
    v = np.asarray(axis, dtype=np.float64)
    info = input_kernel(base.params)
    colour_rows = np.concatenate([info.plane(2), info.plane(3)])
    all_rows = np.concatenate([info.plane(c) for c in range(kernel.shape[0])])
    print(f"  axis: {len(arms)} arms, |v| {np.linalg.norm(v):.3f}")
    print(f"  axis length on the two colour rows of cell_in: {100 * float(v[colour_rows] @ v[colour_rows] / (v @ v)):.4f}%")
    print(f"  axis length on all of cell_in:                 {100 * float(v[all_rows] @ v[all_rows] / (v @ v)):.4f}%")
    # Is the axis's colour-row part a length change or a turn?
    for c in (2, 3):
        rows = info.plane(c)
        k = np.asarray(base.flat[rows], dtype=np.float64)
        d = v[rows]
        along = float(d @ k / (k @ k))  # length component, per unit of v
        residual = d - along * k
        print(
            f"    colour {c - 2}: cos(axis slice, base row) {float(d @ k / (np.linalg.norm(d) * np.linalg.norm(k))):+.3f}"
            f"  length part {100 * float((along * k) @ (along * k) / (d @ d)):5.1f}%"
            f"  turn part {100 * float(residual @ residual / (d @ d)):5.1f}%"
        )
