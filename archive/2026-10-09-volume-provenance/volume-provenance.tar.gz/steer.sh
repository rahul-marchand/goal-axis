set -euo pipefail
export PATH=$HOME/.local/bin:$PATH
cd /workspace/GoalMisgeneralisation
until ! pgrep -f "006_psycho|005_outcome" > /dev/null; do sleep 15; done
git fetch -q origin && git checkout -q steer-distance-field && git pull -q
LOG=/workspace/data/steering.txt
: > "$LOG"
uv run python experiments/007_steer_distance.py \
    /workspace/data/runs/clean11fv/local-files/cp_140206080 \
    --levels /workspace/data/levels11 --episodes 2048 2>&1 \
    | grep -viE "userwarning|logger\.warn|gym\.logger|^\s*$" | tee -a "$LOG"
echo "DONESTEER" | tee -a "$LOG"
