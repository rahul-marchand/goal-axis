set -euo pipefail
export PATH=$HOME/.local/bin:$PATH
cd /workspace/GoalMisgeneralisation
uv run python experiments/001_maze_repro.py \
    --levels /workspace/data/levels11 \
    --min-size 11 --max-size 11 \
    --correlation 0.5 \
    --total-timesteps 150000000 \
    --run-dir /workspace/data/runs/clean11fv
