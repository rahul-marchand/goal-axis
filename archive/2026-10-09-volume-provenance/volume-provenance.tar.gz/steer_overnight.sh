set -uo pipefail
export PATH=$HOME/.local/bin:$PATH
# Share the card with training rather than preallocating against it.
export XLA_PYTHON_CLIENT_PREALLOCATE=false
export XLA_PYTHON_CLIENT_MEM_FRACTION=0.20
cd /workspace/GoalMisgeneralisation

# Wait for the analysis chain to clear and training to be properly under way.
until grep -q ANALYSISDONE /workspace/data/value-representation.txt 2>/dev/null; do sleep 30; done
sleep 300

git fetch -q origin && git checkout -q steer-distance-field && git pull -q
CK=/workspace/data/runs/clean11fv/local-files/cp_140206080
LOG=/workspace/data/steer-variants.txt
: > "$LOG"

run () {
    echo "### $1" | tee -a "$LOG"
    shift
    uv run python experiments/008_steer_at_the_head.py "$CK" \
        --levels /workspace/data/levels11 --episodes 2048 "$@" 2>&1 \
        | grep -viE "userwarning|logger\.warn|gym\.logger|^\s*$" | tee -a "$LOG"
    echo | tee -a "$LOG"
}

run "differential and localised variants" --differential --at-objectives
run "localised only, all directions at the objective cells" --at-objectives
echo "DONEVARIANTS" | tee -a "$LOG"
