#!/bin/bash
# edit_chain.sh JOBFILE : each line "TAG RUN_KIND BASE extra args..." ; RUN_KIND rl|bc
export XLA_PYTHON_CLIENT_PREALLOCATE=false
ulimit -n $(ulimit -Hn)
cd /workspace/GoalMisgeneralisation
JOBS=$1
NAME=$(basename $JOBS .jobs)
LOG=/workspace/data/logs/edit/$NAME.log
mkdir -p /workspace/data/logs/edit results figures/data/cheapest_edit /workspace/data/cheapest_edit
LV=/workspace/data/levels/values/1.00-0.50@500k
while read -r TAG KIND BASE ARGS; do
  [ -z "$TAG" ] && continue
  case "$TAG" in \#*) continue;; esac
  if [ -f figures/data/cheapest_edit/$TAG.json ]; then echo "$TAG skip (done)" >> $LOG; continue; fi
  if [ "$KIND" = bc ]; then
    SRC="/workspace/data/offline/runs/$BASE --offline --demos /workspace/data/offline/demos"
  else
    SRC="/workspace/data/runs/$BASE --levels $LV"
  fi
  echo "$TAG start $(date -u +%H:%M)" >> $LOG
  uv run --no-sync python scripts/cheapest_edit.py $SRC $ARGS --json figures/data/cheapest_edit/$TAG.json \
    --save-deltas /workspace/data/cheapest_edit/$TAG.npz > results/edit-$TAG.txt 2> results/edit-$TAG.err
  echo "$TAG exit $? $(date -u +%H:%M)" >> $LOG
done < $JOBS
echo EDIT_CHAIN_DONE >> $LOG
