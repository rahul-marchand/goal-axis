#!/bin/bash
# edit_worker.sh QUEUE : claims jobs from a shared queue (one line "TAG rl|bc BASE args") with mkdir locks.
export XLA_PYTHON_CLIENT_PREALLOCATE=false
ulimit -n $(ulimit -Hn)
cd /workspace/GoalMisgeneralisation
QUEUE=$1
LOCKS=/workspace/data/cheapest_edit/locks
LOG=/workspace/data/logs/edit/worker-$(hostname).log
mkdir -p $LOCKS /workspace/data/logs/edit results figures/data/cheapest_edit
LV=/workspace/data/levels/values/1.00-0.50@500k
while true; do
  claimed=0
  while read -r TAG KIND BASE ARGS; do
    [ -z "$TAG" ] && continue
    case "$TAG" in \#*) continue;; esac
    mkdir $LOCKS/$TAG 2>/dev/null || continue
    claimed=1
    echo "$(hostname)" > $LOCKS/$TAG/host
    if [ "$KIND" = bc ]; then SRC="/workspace/data/offline/runs/$BASE --offline --demos /workspace/data/offline/demos"; else SRC="/workspace/data/runs/$BASE --levels $LV"; fi
    echo "$TAG start $(date -u +%H:%M)" >> $LOG
    uv run --no-sync python scripts/cheapest_edit.py $SRC $ARGS --json figures/data/cheapest_edit/$TAG.json \
      --save-deltas /workspace/data/cheapest_edit/$TAG.npz > results/edit-$TAG.txt 2> results/edit-$TAG.err
    code=$?
    echo "$TAG exit $code $(date -u +%H:%M)" >> $LOG
    [ $code -ne 0 ] && echo failed > $LOCKS/$TAG/failed
    break
  done < $QUEUE
  [ $claimed -eq 0 ] && break
done
echo WORKER_DONE >> $LOG
