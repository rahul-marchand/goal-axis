set -uo pipefail
export PATH=$HOME/.local/bin:$PATH
export XLA_PYTHON_CLIENT_PREALLOCATE=false
export XLA_PYTHON_CLIENT_MEM_FRACTION=0.20
cd /workspace/GoalMisgeneralisation
git fetch -q origin && git checkout -q goal-structure && git pull -q
LOG=/workspace/data/choice-direction.txt
: > "$LOG"
uv run python experiments/010_choice_direction.py \
    /workspace/data/runs/clean11fv/local-files/cp_140206080 \
    --levels /workspace/data/levels11 --episodes 2048 2>&1 \
    | grep -viE "userwarning|logger\.warn|gym\.logger|^\s*$" | tee -a "$LOG"
echo "DONECHOICE" | tee -a "$LOG"
