#!/bin/bash
# Five fine-tune seeds x both sweeps x even grid, for the core figure.
set -uo pipefail
export PATH=/root/.local/bin:$PATH
cd /workspace/GoalMisgeneralisation
UV=/root/.local/bin/uv
LEVELS=/workspace/data/levels/values/1.00-0.50@500k
while pgrep -f run_replicates.sh > /dev/null; do sleep 60; done

sweep() { # agent objectives... via env OBJ, replicate
  local agent=$1 r=$2; shift 2
  $UV run python scripts/value_axis_sweep.py --agent "$agent" --objectives "$@" \
    --offsets 0.1 0.2 0.3 0.4 --steps 400000 --replicate "$r" || echo "SWEEP_FAILED $agent r$r obj=$*"
}
measure() { # agent prefix base_value replicate outfile
  local agent=$1 prefix=$2 bv=$3 r=$4 out=$5
  local cp; cp=$(python3 -c "import json;print(json.load(open('/workspace/data/runs/$agent/BASE.json'))['checkpoint'])")
  local flag=""; [ "$r" != 1 ] && flag="--replicate $r"
  $UV run python experiments/014_value_axis_analysis.py \
    --base "/workspace/data/runs/$agent/$cp" --arms "/workspace/data/runs/$agent/arms" \
    --levels "$LEVELS" --prefix "$prefix" --base-value "$bv" --arm-steps 400000 --at -1 $flag \
    > "results/$out.txt" 2> "results/$out.err" || echo "MEASURE_FAILED $out"
}

for r in 2 3 4 5; do sweep novalue11.s1234 $r 0 1; done
for agent in resnet11novalue.s1234-cp130M vit11novalue.s1234; do
  for r in 2 3; do sweep "$agent" $r 0; done
  for r in 4 5; do sweep "$agent" $r 0 1; done
done

measure novalue11.s9012 o0 1.0 1 wide-novalue11.s9012-o0
for r in 2 3 4 5; do
  measure novalue11.s1234 o1 0.5 $r "wide-novalue11.s1234-o1.r$r"
  measure novalue11.s1234 o0 1.0 $r "wide-novalue11.s1234-o0.r$r"
done
for agent in resnet11novalue.s1234-cp130M vit11novalue.s1234; do
  for r in 2 3 4 5; do
    measure "$agent" o0 1.0 $r "arch-swap-value-axis-$agent-o0.r$r"
    [ $r -ge 4 ] && measure "$agent" o1 0.5 $r "arch-swap-value-axis-$agent-o1.r$r"
  done
done
echo PROGRAM_DONE
