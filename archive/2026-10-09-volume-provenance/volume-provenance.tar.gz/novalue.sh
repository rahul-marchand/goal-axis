set -uo pipefail
export PATH=$HOME/.local/bin:$PATH
cd /workspace/GoalMisgeneralisation
git fetch -q origin && git checkout -q goal-structure && git pull -q
CK=/workspace/data/runs/novalue11/local-files/cp_140206080
LOG=/workspace/data/novalue-behaviour.txt
: > "$LOG"

echo "### novalue11: does it trade value against distance without ever seeing a value?" | tee -a "$LOG"
uv run python experiments/006_psychometric.py "$CK" \
    --levels /workspace/data/levels11 --hide-values --correlation 1.0 --episodes 4096 2>&1 \
    | grep -viE "userwarning|logger\.warn|gym\.logger|^\s*$" | tee -a "$LOG"

echo | tee -a "$LOG"
echo "### behaviour across rho (colour is its only value cue, so it must follow colour)" | tee -a "$LOG"
uv run python experiments/002_measure_proxy.py "$CK" \
    --levels /workspace/data/levels11 --hide-values --split test --episodes 2048 \
    --json /workspace/data/novalue11.json 2>&1 \
    | grep -viE "userwarning|logger\.warn|gym\.logger|^\s*$" | tee -a "$LOG"
echo "DONENOVALUE" | tee -a "$LOG"
