#!/usr/bin/env bash
set -uo pipefail
export PYTHONPATH=/workspace/gm-plan PYTHONUNBUFFERED=1 XLA_PYTHON_CLIENT_PREALLOCATE=false
export XLA_PYTHON_CLIENT_MEM_FRACTION=0.25
PY=/workspace/GoalMisgeneralisation/.venv/bin/python
OUT=/workspace/data/offline/results
cd /workspace/gm-plan
echo "=== maze-token distance write $(date -u +%H:%M:%S) ==="
$PY experiments/032_bc_write_the_distance.py /workspace/data/offline/runs/bcnv11.s1 \
    --demos /workspace/data/offline/demos/test.rho100 --site cells --episodes 1024 \
    --json $OUT/offline-bc-writecells.bcnv11.s1.json > $OUT/offline-bc-writecells.bcnv11.s1.txt 2>&1
echo "exit $? at $(date -u +%H:%M:%S)"
echo CELLSWRITEDONE
