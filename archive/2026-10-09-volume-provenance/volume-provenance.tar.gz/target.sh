set -uo pipefail
export PATH=$HOME/.local/bin:$PATH
cd /workspace/GoalMisgeneralisation
git fetch -q origin && git checkout -q goal-structure && git pull -q
LOG=/workspace/data/target-probe.txt
: > "$LOG"

echo "### novalue11 - values are internal constants, so the decision is the only variable" | tee -a "$LOG"
uv run python experiments/011_target_probe.py \
    /workspace/data/runs/novalue11/local-files/cp_140206080 \
    --levels /workspace/data/levels11 --hide-values --correlation 1.0 --last-layer-only 2>&1 \
    | grep -viE "userwarning|logger\.warn|gym\.logger|invalid value|c /=|^\s*$" | tee -a "$LOG"

echo | tee -a "$LOG"
echo "### clean11fv - the control agent, same probe" | tee -a "$LOG"
uv run python experiments/011_target_probe.py \
    /workspace/data/runs/clean11fv/local-files/cp_140206080 \
    --levels /workspace/data/levels11 --correlation 1.0 --last-layer-only 2>&1 \
    | grep -viE "userwarning|logger\.warn|gym\.logger|invalid value|c /=|^\s*$" | tee -a "$LOG"
echo "DONETARGET" | tee -a "$LOG"
