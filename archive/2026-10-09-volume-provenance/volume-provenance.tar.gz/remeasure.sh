set -euo pipefail
export PATH=$HOME/.local/bin:$PATH
cd /workspace/GoalMisgeneralisation
git pull --ff-only -q
mkdir -p figures/data
LOG=/workspace/data/remeasure-2026-08-04.txt
: > "$LOG"

run () {
    echo "### $1" | tee -a "$LOG"
    shift
    uv run python "$@" 2>&1 | grep -viE "userwarning|logger\.warn|gym\.logger|^\s*$" | tee -a "$LOG"
    echo | tee -a "$LOG"
}

run "maze11 - 11x11, trained rho=1.0, fixed values" \
    experiments/002_measure_proxy.py /workspace/data/runs/maze11/local-files/cp_140206080 \
    --levels /workspace/data/levels11 --split test --episodes 2048 --num-envs 64 \
    --json figures/data/maze11.json

run "clean11 - 11x11 control, trained rho=0.5, randomised values" \
    experiments/002_measure_proxy.py /workspace/data/runs/clean11/local-files/cp_130191360 \
    --levels /workspace/data/levels11rv --randomise-values --split test --episodes 2048 --num-envs 64 \
    --json figures/data/clean11.json

run "smoke5b - 5x5, trained rho=1.0, fixed values, live levels" \
    experiments/002_measure_proxy.py /workspace/data/runs/smoke5b/local-files/cp_9011200 \
    --min-size 5 --max-size 5 --episodes 2048 --num-envs 64 \
    --json figures/data/smoke5b.json

run "optimum reference for the maze11 evaluation curves" \
    scripts/optimum.py --levels /workspace/data/levels11 --json figures/data/optimum_maze11.json

run "optimum reference for the clean11 evaluation curves" \
    scripts/optimum.py --levels /workspace/data/levels11rv --randomise-values \
    --json figures/data/optimum_clean11.json

cp /workspace/data/runs/maze11/metrics.csv figures/data/maze11.csv
cp /workspace/data/runs/clean11/metrics.csv figures/data/clean11.csv
cp /workspace/data/runs/smoke5b/metrics.csv figures/data/smoke5b.csv
echo "DONE" | tee -a "$LOG"
