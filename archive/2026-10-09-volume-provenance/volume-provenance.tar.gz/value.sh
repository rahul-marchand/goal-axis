set -euo pipefail
export PATH=$HOME/.local/bin:$PATH
cd /workspace/GoalMisgeneralisation
until ! pgrep -f "008_steer" > /dev/null; do sleep 20; done
git fetch -q origin && git checkout -q steer-distance-field && git pull -q
LOG=/workspace/data/value-representation.txt
: > "$LOG"
for flag in "" "--last-layer-only"; do
  echo "### clean11 (randomised values) ${flag:-all layers}" | tee -a "$LOG"
  uv run python experiments/009_value_representation.py \
      /workspace/data/runs/clean11/local-files/cp_130191360 \
      --levels /workspace/data/levels11rv --randomise-values --correlation 0.5 $flag 2>&1 \
      | grep -viE "userwarning|logger\.warn|gym\.logger|^\s*$" | tee -a "$LOG"
  echo | tee -a "$LOG"
done
echo "DONEVALUE" | tee -a "$LOG"
