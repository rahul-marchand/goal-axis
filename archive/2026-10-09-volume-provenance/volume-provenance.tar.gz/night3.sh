#!/bin/bash
# Table-channel continuation of the stage-4 base (warm start from step 60000 with a
# zero row for the new channel), pool + DAgger states, then the axis machinery.
set -u
unset JAX_PLATFORMS
export PATH=$HOME/.local/bin:$PATH UV_PROJECT_ENVIRONMENT=/root/venv-control UV_CACHE_DIR=/root/.cache/uv UV_NO_SYNC=1 PYTHONUNBUFFERED=1 XLA_PYTHON_CLIENT_PREALLOCATE=false
cd /workspace/gm-control
D=/workspace/data/craftax/craft; R=$D/runs; LOGS=/workspace/data/logs/craftax
export DEMOS=$D/demos-rh ARM_OFFSETS="0.45 0.3 0.2 0.1"
if [ ! -f $R/cxcraft15.s1t/done.json ]; then
  uv run python experiments/023_train_bc.py --demos $D/demos-rh/train.rho100 --extra-demos $D/demos-rh/dagger.s1 --extra-fraction 0.2 --hide-values \
    --init-from $R/cxcraft15.s1t-init/checkpoints/step_00000000 --schedule cosine --lr 1e-4 --warmup 200 \
    --eval rho100=$D/demos-rh/valid.rho100 rho050=$D/demos-rh/valid.rho050 rho000=$D/demos-rh/valid.rho000 --eval-levels 512 \
    --out $R/cxcraft15.s1t --seed 41 --steps 20000 --batch-size 128 --checkpoint-first 2500 --checkpoint-ratio 2.0 \
    --note "Table-channel continuation of cxcraft15.s1: warm start from step 60000 (zero row for the new channel), pool plus the s1 DAgger states at a fifth of samples, 20k steps at batch 128." \
    > $LOGS/cxcraft15.s1t.log 2>&1 || { echo "S1T_TRAIN_FAILED"; exit 1; }
fi
echo "$(date -u +%FT%TZ) cxcraft15.s1t iron share $(python3 /workspace/iron_share.py $R/cxcraft15.s1t)"
grep checkpoint $LOGS/cxcraft15.s1t.log | tail -3
bash scripts/craft_chain.sh arms cxcraft15.s1t
bash scripts/craft_chain.sh analysis cxcraft15.s1t
echo "CRAFT_NIGHT_DONE cxcraft15.s1t"
