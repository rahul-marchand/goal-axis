import csv, sys
r = list(csv.DictReader(open(sys.argv[1] + "/eval.csv")))[-1]
reached = float(r["rho100/reached"]); f0 = float(r["rho100/followed_feature_zero"])
print(f"{reached * f0:.3f} reached={reached:.2f} iron_among_reached={f0:.2f}")
