#!/bin/bash
set -u
export PATH=/root/.local/bin:$PATH
export JAX_COMPILATION_CACHE_DIR=/workspace/data/jax-cache
cd /workspace/GoalMisgeneralisation
for name in vit11nvg1.s1234 vit11nvg1.s5678; do
  RUN=/workspace/data/runs/$name
  CP=$(python3 -c "import json;print(json.load(open(\"$RUN/BASE.json\"))[\"checkpoint\"])")
  /root/.local/bin/uv run python experiments/014_value_axis_analysis.py \
    --base "$RUN/$CP" --arms "$RUN/arms" --levels /workspace/data/levels/values/1.00-0.50@500k \
    --prefix o1 --base-value 0.5 --arm-steps 400000 --at -1 \
    > "results/g1-$name-o1.h1check.txt" 2> "results/g1-$name-o1.h1check.err" || echo "CROSSCHECK_FAILED $name"
done
echo CROSSCHECK_DONE
