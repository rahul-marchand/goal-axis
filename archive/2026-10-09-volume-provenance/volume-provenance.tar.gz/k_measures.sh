#!/bin/bash
# Threshold of every colour-keyed crossing arm, without fitting an axis to them.
set -u
export PATH=$HOME/.local/bin:$PATH
export PYTHONUNBUFFERED=1
export JAX_COMPILATION_CACHE_DIR=/workspace/data/jax-cache
cd /workspace/GoalMisgeneralisation
LEVELS=/workspace/data/levels/values/1.00-0.50@500k
while pgrep -f "[c]rossing_arms.sh" > /dev/null; do sleep 60; done
for base in novalue11g1.s1234 novalue11g1.s9012 novalue11g1.s3456e resnet11nvg1.s1234 resnet11nvg1.s2468 resnet11nvg1.s3456 vit11nvg1.s9012; do
  for spec in "k1:0.5" "k0:1.0"; do
    fam=${spec%%:*}; bv=${spec##*:}
    $HOME/.local/bin/uv run python scripts/arm_thresholds.py "/workspace/data/runs/$base" \
      --family "$fam" --base-value "$bv" --levels "$LEVELS" --arm-steps 400000 \
      > "results/g1-$base-$fam.txt" 2> "results/g1-$base-$fam.err" || echo "KTHRESH_FAILED $base $fam"
  done
done
echo KTHRESH_DONE
