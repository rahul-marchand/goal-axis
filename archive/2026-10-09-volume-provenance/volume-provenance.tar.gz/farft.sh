#!/bin/bash
# Appendix: held-out (colour-keyed) fine-tunes further past parity, then their thresholds.
# RL: k1 at 1.3..2.0, k0 at 0.2..0.0 (400k steps) -> results/g1-<base>-k{0,1}.txt (superset tables)
# BC: matching demos + arms for bcnv11 s1-3 -> results/g1-bcnv11.s<n>-k{0,1}.txt
set -u
export PATH=$HOME/.local/bin:$PATH
export PYTHONUNBUFFERED=1
export JAX_COMPILATION_CACHE_DIR=/workspace/data/jax-cache
cd /workspace/GoalMisgeneralisation
UV=$HOME/.local/bin/uv
DATA=/workspace/data
LEVELS=$DATA/levels/values/1.00-0.50@500k
BASES="novalue11g1.s1234 novalue11g1.s9012 novalue11g1.s3456e resnet11nvg1.s1234 resnet11nvg1.s2468 resnet11nvg1.s3456 vit11nvg1.s9012"

sweep() { # base objective values...
  local base=$1 obj=$2; shift 2
  $UV run python scripts/value_axis_sweep.py --agent "$base" --objectives "$obj" \
    --values "$@" --family k --colour-keyed --allow-reorder --steps 400000 \
    || echo "KSWEEP_FAILED $base o$obj values $*"
}
for base in $BASES; do
  echo "=== $base: far crossing arms $(date -u +%H:%M)"
  sweep "$base" 1 1.3 1.4 1.5
  sweep "$base" 1 1.75 2.0
  sweep "$base" 0 0.2 0.1
  sweep "$base" 0 0.0
done

echo "=== thresholds (all k arms, old and new)"
for base in $BASES; do
  for spec in "k1:0.5" "k0:1.0"; do
    fam=${spec%%:*}; bv=${spec##*:}
    $UV run python scripts/arm_thresholds.py "$DATA/runs/$base" \
      --family "$fam" --base-value "$bv" --levels "$LEVELS" --arm-steps 400000 \
      > "results/g1-$base-$fam.far.tmp" 2> "results/g1-$base-$fam.err" \
      && mv "results/g1-$base-$fam.far.tmp" "results/g1-$base-$fam.txt" \
      || echo "KTHRESH_FAILED $base $fam"
  done
done
echo RL_FARFT_DONE

echo "=== BC: crossing demonstrations further out"
DEMOS=$DATA/offline/demos; RUNS=$DATA/offline/runs
for tag in 1.00-1.30 1.00-1.40 1.00-1.50 1.00-1.75 1.00-2.00 0.20-0.50 0.10-0.50 0.00-0.50; do
  src="$DATA/levels/values/$tag@150k"
  [ -d "$src" ] || { echo "DEMOS_NO_LEVELS $tag"; continue; }
  for split_n in "train 50000" "test 2048"; do
    set -- $split_n
    out="$DEMOS/arms/$tag.$1.rho100.keyed"
    [ -f "$out/meta.json" ] && { echo "have $(basename $out)"; continue; }
    $UV run python scripts/generate_demos.py --levels "$src" --split "$1" --rho 1.0 --n "$2" \
      --colour-keyed --objective-values ${tag//-/ } --out "$out" > /dev/null 2>&1 \
      || echo "DEMOS_FAILED $tag $1"
  done
done
echo "=== BC: far crossing arms, three seeds"
for seed in 1 2 3; do
  base=$RUNS/bcnv11.s$seed
  [ -d "$base" ] || { echo "no base bcnv11.s$seed"; continue; }
  init=$(ls -d $base/checkpoints/step_* | sort | tail -n1)
  i=10
  for spec in "k1+080@1k:1.00-1.30" "k1+090@1k:1.00-1.40" "k1+100@1k:1.00-1.50" "k1+125@1k:1.00-1.75" "k1+150@1k:1.00-2.00" \
              "k0-080@1k:0.20-0.50" "k0-090@1k:0.10-0.50" "k0-100@1k:0.00-0.50"; do
    dirname=${spec%%:*}; tag=${spec##*:}
    out="$base/arms/$dirname"
    [ -f "$out/done.json" ] && { echo "have $dirname of s$seed"; i=$((i+1)); continue; }
    [ -f "$DEMOS/arms/$tag.train.rho100.keyed/meta.json" ] || { echo "BCARM_NO_DEMOS $tag"; i=$((i+1)); continue; }
    XLA_PYTHON_CLIENT_PREALLOCATE=true XLA_PYTHON_CLIENT_MEM_FRACTION=0.3 \
    $UV run python experiments/023_train_bc.py \
      --demos "$DEMOS/arms/$tag.train.rho100.keyed" --init-from "$init" --schedule constant \
      --eval "base=$DEMOS/test.rho100" "own=$DEMOS/arms/$tag.test.rho100.keyed" --eval-levels 1024 \
      --out "$out" --seed $((7000 + i)) --steps 1000 --lr 3e-5 --warmup 50 \
      --checkpoint-first 100000000 \
      --note "Colour-keyed crossing arm $dirname of bcnv11.s$seed, further past parity: values $tag." \
      > /dev/null 2>&1 || echo "BCARM_FAILED s$seed $dirname"
    i=$((i+1))
  done
done
echo "=== BC thresholds"
for seed in 1 2 3; do
  for spec in "k1:0.5" "k0:1.0"; do
    fam=${spec%%:*}; bv=${spec##*:}
    $UV run python scripts/bc_arm_thresholds.py "$RUNS/bcnv11.s$seed" --family "$fam" --base-value "$bv" \
      --demos "$DEMOS/test.rho100" > "results/g1-bcnv11.s$seed-$fam.far.tmp" 2> "results/g1-bcnv11.s$seed-$fam.err" \
      && mv "results/g1-bcnv11.s$seed-$fam.far.tmp" "results/g1-bcnv11.s$seed-$fam.txt" \
      || echo "BCTHRESH_FAILED s$seed $fam"
  done
done
echo FARFT_DONE
