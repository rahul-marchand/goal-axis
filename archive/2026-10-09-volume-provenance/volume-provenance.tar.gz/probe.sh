set -euo pipefail
export PATH=$HOME/.local/bin:$PATH
cd /workspace/GoalMisgeneralisation
git pull --ff-only -q
LOG=/workspace/data/probe-2026-08-04.txt
: > "$LOG"

run () {
    echo "### $1" | tee -a "$LOG"
    shift
    uv run python "$@" 2>&1 | grep -viE "userwarning|logger\.warn|gym\.logger|^\s*$" | tee -a "$LOG"
    echo | tee -a "$LOG"
}

run "maze11 - trained with a proxy, held-out test levels" \
    experiments/003_probe_plan.py /workspace/data/runs/maze11/local-files/cp_140206080 \
    --levels /workspace/data/levels11 --split test --by-distance --think 0 4

run "clean11 - control, held-out test levels" \
    experiments/003_probe_plan.py /workspace/data/runs/clean11/local-files/cp_130191360 \
    --levels /workspace/data/levels11rv --randomise-values --split test --by-distance --think 0

echo "DONE" | tee -a "$LOG"
