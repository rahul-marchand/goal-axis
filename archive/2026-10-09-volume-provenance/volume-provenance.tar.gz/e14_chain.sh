#!/bin/bash
# E14: fit the decision readout at the agent's cell, three DRC bases.
set -uo pipefail
ulimit -n $(ulimit -Hn) 2>/dev/null
export PYTHONUNBUFFERED=1 XLA_PYTHON_CLIENT_PREALLOCATE=false JAX_COMPILATION_CACHE_DIR=/workspace/data/jax-cache
SNAP=/workspace/gvf-e14-snap
PY=/workspace/GoalMisgeneralisation/.venv/bin/python
DATA=/workspace/data
REPO=/workspace/GoalMisgeneralisation
OUT=$REPO/results/gain-vs-factorised
JSON=$DATA/figures-data/gain-vs-factorised/e14
LOG=$DATA/logs/gvf
mkdir -p "$OUT" "$JSON" "$LOG"
L=$LOG/e14.log
say() { echo "[$(date -u +%H:%M:%S)] $*" >> "$L"; }
cd "$SNAP" || exit 1
say "=== E14 start, snapshot $SNAP"
for base in novalue11g1.s1234 novalue11g1.s9012 novalue11g1.s3456e; do
  say "$base start"
  timeout 7200 $PY scripts/readout_fit.py "$DATA/runs/$base" \
    --levels "$DATA/levels/values/1.00-0.50@500k" --n-levels 4096 --n-random 64 \
    --json "$JSON/$base.json" > "$OUT/e14-$base.txt" 2> "$LOG/e14-$base.err" \
    && say "$base ok" || say "$base FAILED"
  $PY scripts/e14_report.py "$JSON" "$OUT/E14.md" "$OUT" >> "$LOG/e14.report.log" 2>&1
  cp -f "$OUT/E14.md" "$DATA/figures-data/gain-vs-factorised/E14.md" 2>/dev/null
  say "E14_STAGE_DONE $base"
done
say "E14_CHAIN_DONE"
