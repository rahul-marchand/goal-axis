set -euo pipefail
export PATH=$HOME/.local/bin:$PATH
cd /workspace/GoalMisgeneralisation
git fetch -q origin && git checkout -q probe-distance-field && git pull -q
LOG=/workspace/data/distance-pilot.txt
: > "$LOG"
echo "### clean11fv, field = distance to feature 0" | tee -a "$LOG"
uv run python experiments/004_distance_pilot.py \
    /workspace/data/runs/clean11fv/local-files/cp_140206080 \
    --levels /workspace/data/levels11 --split test \
    --train-episodes 256 --test-episodes 512 --think 0 4 2>&1 \
    | grep -viE "userwarning|logger\.warn|gym\.logger|^\s*$" | tee -a "$LOG"
echo "DONE" | tee -a "$LOG"
