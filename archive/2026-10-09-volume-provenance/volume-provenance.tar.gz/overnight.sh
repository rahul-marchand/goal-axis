set -uo pipefail
export PATH=$HOME/.local/bin:$PATH
cd /workspace/GoalMisgeneralisation
git fetch -q origin && git checkout -q steer-distance-field && git pull -q

# The two short analyses first; they need the GPU only briefly.
{
  echo "### 008 steering at the head"
  uv run python experiments/008_steer_at_the_head.py \
      /workspace/data/runs/clean11fv/local-files/cp_140206080 \
      --levels /workspace/data/levels11 --episodes 2048 2>&1 \
      | grep -viE "userwarning|logger\.warn|gym\.logger|^\s*$"
} | tee /workspace/data/steer-head.txt

{
  echo "### 009 value representation, clean11"
  for flag in "" "--last-layer-only"; do
    echo "--- ${flag:-all layers}"
    uv run python experiments/009_value_representation.py \
        /workspace/data/runs/clean11/local-files/cp_130191360 \
        --levels /workspace/data/levels11rv --randomise-values --correlation 0.5 $flag 2>&1 \
        | grep -viE "userwarning|logger\.warn|gym\.logger|^\s*$"
  done
} | tee /workspace/data/value-representation.txt

echo "ANALYSISDONE" | tee -a /workspace/data/value-representation.txt

# Then the long one: values hidden, so the agent must learn them internally.
uv run python experiments/001_maze_repro.py \
    --levels /workspace/data/levels11 \
    --min-size 11 --max-size 11 \
    --correlation 1.0 \
    --hide-values \
    --total-timesteps 150000000 \
    --run-dir /workspace/data/runs/novalue11 > /workspace/data/runs/novalue11.log 2>&1
echo "TRAINDONE" >> /workspace/data/runs/novalue11.log
