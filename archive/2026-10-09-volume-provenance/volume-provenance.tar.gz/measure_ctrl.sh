set -euo pipefail
export PATH=$HOME/.local/bin:$PATH
cd /workspace/GoalMisgeneralisation
git pull --ff-only -q
LOG=/workspace/data/remeasure-clean11fv.txt
: > "$LOG"

run () {
    echo "### $1" | tee -a "$LOG"
    shift
    uv run python "$@" 2>&1 | grep -viE "userwarning|logger\.warn|gym\.logger|^\s*$" | tee -a "$LOG"
    echo | tee -a "$LOG"
}

run "clean11fv - 11x11, trained rho=0.5, FIXED values (single-variable control)" \
    experiments/002_measure_proxy.py /workspace/data/runs/clean11fv/local-files/cp_140206080 \
    --levels /workspace/data/levels11 --split test --episodes 2048 --num-envs 64 \
    --json /workspace/data/clean11fv.json

run "clean11fv - plan probe, held-out test levels" \
    experiments/003_probe_plan.py /workspace/data/runs/clean11fv/local-files/cp_140206080 \
    --levels /workspace/data/levels11 --split test --by-distance --think 0

echo "DONE" | tee -a "$LOG"
