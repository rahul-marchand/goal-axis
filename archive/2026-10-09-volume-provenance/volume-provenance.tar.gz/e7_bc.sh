#!/bin/bash
set -uo pipefail
ulimit -n $(ulimit -Hn)
export PYTHONUNBUFFERED=1 XLA_PYTHON_CLIENT_PREALLOCATE=false JAX_COMPILATION_CACHE_DIR=/workspace/data/jax-cache
SNAP=/workspace/gvf-e7-snap; cd $SNAP
PY=/workspace/GoalMisgeneralisation/.venv/bin/python
DATA=/workspace/data; REPO=/workspace/GoalMisgeneralisation
OUT=$REPO/figures/data/gain_vs_factorised/e7; RES=$REPO/results/gain-vs-factorised; LOG=$DATA/logs/gvf
mkdir -p $OUT $RES $LOG
L=$LOG/e7-BC.log
say() { echo "[$(date -u +%H:%M:%S)] $*" >> $L; }
BC="--offline --demos $DATA/offline/demos --n-edit 4096 --n-eval 2048 --steps-tag 1000"
for spec in "bcnv11.s1 rotation" "bcnv11.s1 gain" "bcnv11.s2 rotation"; do
  set -- $spec; tag=$1; family=$2
  say "edit $tag $family"
  timeout 5400 $PY scripts/cheapest_edit.py $DATA/offline/runs/$tag --family $family --target soft --rule threshold \
    --seeds 0 1 --steps 400 --batch 32 --lr 3e-2 --l2 1e-3 --optimizer adam \
    --shifts -4 -2 2 4 --eval-shifts -8 -6 -4 -2 2 4 6 8 --sweep o1 --fit-window 0.45 \
    --json $OUT/$tag.$family.json --save-deltas $OUT/$tag.$family.npz $BC \
    > $RES/e7-edit-$tag.$family.txt 2> $LOG/e7-edit-$tag.$family.err \
    && say "edit $tag $family ok" || say "edit $tag $family FAILED"
done
say "profile bcnv11.s1"
timeout 3600 $PY scripts/direction_profile.py $DATA/offline/runs/bcnv11.s1 --offline --demos $DATA/offline/demos \
  --steps-tag 1000 --n-levels 256 --json $OUT/bcnv11.s1.profile.json \
  > $RES/e7-profile-bcnv11.s1.txt 2> $LOG/e7-profile-bcnv11.s1.err && say "profile ok" || say "profile FAILED"
say "E7_BC_DONE"
