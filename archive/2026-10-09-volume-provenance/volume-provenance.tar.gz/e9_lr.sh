#!/bin/bash
# E9b: is the route model's base-to-base difference in rotation reach real, or
# just the search not moving? The default lr 3e-4 turns s1 by 0.6 degrees over
# 400 steps and s2 by 1.9; if s1 works at a larger step, the "base dependence"
# is an optimiser artefact, not an architecture fact.
set -uo pipefail
ulimit -n $(ulimit -Hn)
export PYTHONUNBUFFERED=1 XLA_PYTHON_CLIENT_PREALLOCATE=false JAX_COMPILATION_CACHE_DIR=/workspace/data/jax-cache

SNAP=/workspace/gvf-e9-snap
PY=/workspace/GoalMisgeneralisation/.venv/bin/python
DATA=/workspace/data
DEMOS=$DATA/offline/demos
OUT=$DATA/figures-data/gain-vs-factorised/e9
RES=/workspace/GoalMisgeneralisation/results/gain-vs-factorised
LOG=$DATA/logs/gvf
mkdir -p "$OUT" "$RES" "$LOG"
cd $SNAP || exit 1
L=$LOG/e9lr.log
say() { echo "[$(date -u +%H:%M:%S)] $*" >> $L; }

say "=== E9b start: rotation and gain at lr 3e-2"
for s in 1 3 2; do
  for fam in rotation gain; do
    tag=$fam.lr3e-2
    if [ -f "$OUT/bcnv11.s$s.$tag.json" ]; then say "s$s $tag done already"; continue; fi
    say "s$s $tag"
    timeout 5400 $PY scripts/cheapest_edit.py $DATA/offline/runs/bcnv11.s$s --offline --demos $DEMOS \
      --family $fam --target soft --seeds 0 1 --steps 400 --lr 3e-2 \
      --shifts -4 -2 2 4 --eval-shifts -16 -12 -8 -4 -2 2 4 8 \
      --json "$OUT/bcnv11.s$s.$tag.json" --save-deltas "$OUT/bcnv11.s$s.$tag.npz" \
      > "$RES/e9-edit-bcnv11.s$s.$tag.txt" 2> "$LOG/e9-edit-bcnv11.s$s.$tag.err" \
      && say "s$s $tag ok" || say "s$s $tag FAILED"
  done
done
say "E9LR_DONE"
