#!/bin/bash
# Overnight driver toward a competent crafting policy. Waits for the first DAgger
# continuation (cxcraft15.s1d); if it takes iron often enough, runs its arms and
# analysis; otherwise a second round (states from the DAgger model, hard-leg
# oversampling) and then the axis machinery on that. Leaves CRAFT_NIGHT_DONE.
set -u
export PATH=$HOME/.local/bin:$PATH UV_PROJECT_ENVIRONMENT=/root/venv-control UV_CACHE_DIR=/root/.cache/uv UV_NO_SYNC=1 PYTHONUNBUFFERED=1 XLA_PYTHON_CLIENT_PREALLOCATE=false
cd /workspace/gm-control
D=/workspace/data/craftax/craft; R=$D/runs; LOGS=/workspace/data/logs/craftax
export DEMOS=$D/demos-rh ARM_OFFSETS="0.45 0.3 0.2 0.1"
iron_share() {  # reached x took-iron on the last evaluation row of a run
  python3 - "$1" <<PY
import csv, sys
r = list(csv.DictReader(open(sys.argv[1] + "/eval.csv")))[-1]
print(f"{float(r[rho100/reached]) * float(r[rho100/followed_feature_zero]):.3f} reached={float(r[rho100/reached]):.2f} iron_among_reached={float(r[rho100/followed_feature_zero]):.2f}")
PY
}
until [ -f $R/cxcraft15.s1d/done.json ] || grep -q "DAGGER_TRAIN_FAILED" $LOGS/dagger_round.log; do sleep 120; done
tmux kill-session -t dagger 2>/dev/null   # round 1 would sweep arms regardless; this script decides instead
git pull -q origin craftax 2>&1 | tail -1
S1D=$(iron_share $R/cxcraft15.s1d); echo "$(date -u +%FT%TZ) cxcraft15.s1d iron share $S1D"
BEST=cxcraft15.s1d
if [ "$(echo "$S1D" | cut -d" " -f1 | awk '{print ($1 >= 0.15)}')" != "1" ]; then
  echo "$(date -u +%FT%TZ) round 2: collect from s1d, continue with hard-leg weight 4"
  [ -f $D/demos-rh/dagger.s1d/meta.json ] || uv run python scripts/craft_dagger.py $R/cxcraft15.s1d $D/demos-rh/train.rho100 --fields 5000 --start 905000 --guard --states-per-route 8 --out $D/demos-rh/dagger.s1d > $LOGS/dagger.s1d.collect.log 2>&1
  if [ ! -f $R/cxcraft15.s1d2/done.json ]; then
    uv run python experiments/023_train_bc.py --demos $D/demos-rh/train.rho100 --extra-demos $D/demos-rh/dagger.s1 $D/demos-rh/dagger.s1d --extra-fraction 0.33 --after-pickaxe-weight 4 --hide-values \
      --init-from $(ls -d $R/cxcraft15.s1d/checkpoints/step_* | sort | tail -1) --schedule cosine --lr 1e-4 --warmup 200 \
      --eval rho100=$D/demos-rh/valid.rho100 rho050=$D/demos-rh/valid.rho050 rho000=$D/demos-rh/valid.rho000 --eval-levels 512 \
      --out $R/cxcraft15.s1d2 --seed 31 --steps 24000 --batch-size 128 --checkpoint-first 6000 --checkpoint-ratio 2.0 \
      --note "DAgger round 2 from cxcraft15.s1d: states visited by s1 and s1d (a third of samples), states after the wood pickaxe repeated 4x, 24k steps at batch 128." \
      > $LOGS/cxcraft15.s1d2.log 2>&1 || { echo "ROUND2_TRAIN_FAILED"; exit 1; }
  fi
  echo "$(date -u +%FT%TZ) cxcraft15.s1d2 iron share $(iron_share $R/cxcraft15.s1d2)"
  BEST=cxcraft15.s1d2
fi
echo "$(date -u +%FT%TZ) axis machinery on $BEST"
bash scripts/craft_chain.sh arms $BEST
bash scripts/craft_chain.sh analysis $BEST
echo "CRAFT_NIGHT_DONE $BEST"
