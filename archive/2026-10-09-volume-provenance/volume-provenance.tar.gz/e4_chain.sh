#!/bin/bash
# Experiment 4 (gain vs factorised): frozen-input arms, module-restricted cheapest edits, collateral readout.
#   nohup bash /workspace/e4_chain.sh novalue11g1.s1234 [STEPS] > /dev/null 2>&1 &
set -uo pipefail
ulimit -n $(ulimit -Hn)
export PYTHONUNBUFFERED=1
export XLA_PYTHON_CLIENT_PREALLOCATE=false
export JAX_COMPILATION_CACHE_DIR=/workspace/data/jax-cache
cd /workspace/GoalMisgeneralisation
BASE=$1
STEPS=${2:-400}
PY="uv run --no-sync python"
DATA=/workspace/data
RUN=$DATA/runs/$BASE
LV=$DATA/levels/values/1.00-0.50@500k
LOG=$DATA/logs/gvf; mkdir -p $LOG results/gain-vs-factorised figures/data/gain_vs_factorised/e4
OUT=figures/data/gain_vs_factorised/e4
L=$LOG/e4-$BASE.log
say() { echo "[$(date -u +%H:%M:%S)] $*" >> $L; }

say "=== $BASE: frozen arms (input conv + conv 1 frozen), same argv as the free arms"
for arm in o1-030 o1-020 o1+020 o1+030; do
  dest=$RUN/arms-frozen/$arm@400k
  if ls $dest/local-files/cp_* >/dev/null 2>&1 && [ -f $dest/DONE ]; then say "$arm frozen done already"; continue; fi
  argv=$(grep -m1 '^argv' $RUN/logs/$arm@400k.log | sed 's/^argv *//')
  [ -z "$argv" ] && { say "no argv for $arm"; continue; }
  newargv=$(echo "$argv" | sed "s#--run-dir [^ ]*#--run-dir $dest#; s#--note .*#--note frozen-input-arm-e4#")
  rm -rf $dest
  say "$arm: $newargv"
  $PY scripts/frozen_arm.py --freeze "input conv" "conv 1" -- $newargv > $LOG/e4-$BASE-$arm.frozen.log 2>&1 \
    && touch $dest/DONE && say "$arm frozen ok" || say "$arm frozen FAILED"
done

edit() { local name=$1; shift
  if [ -f $OUT/$BASE.$name.npz ]; then say "edit $name done already"; return; fi
  say "edit $name: $*"
  $PY scripts/cheapest_edit.py $RUN --levels $LV --family dense --seeds 0 1 --steps $STEPS \
    --shifts -4 -2 2 4 --eval-shifts -4 -2 2 4 --json $OUT/$BASE.$name.json --save-deltas $OUT/$BASE.$name.npz "$@" \
    > results/gain-vs-factorised/e4-edit-$BASE.$name.txt 2> $LOG/e4-edit-$BASE.$name.err \
    && say "edit $name ok" || say "edit $name FAILED"
}
edit readout --modules dense heads
edit late --modules "cell 2 input" "cell 2 recurrent" dense heads
edit input --modules "input conv"
edit all

say "collateral"
arms=()
for arm in o1-030 o1-020 o1+020 o1+030; do
  arms+=("frozen/$arm=$RUN/arms-frozen/$arm@400k" "free/$arm=$RUN/arms/$arm@400k")
done
deltas=()
for n in readout late input all; do [ -f $OUT/$BASE.$n.npz ] && deltas+=("$n=$OUT/$BASE.$n.npz"); done
$PY scripts/edit_collateral.py $RUN --levels $LV --deltas "${deltas[@]}" --axis-from all --arms "${arms[@]}" \
  --json $OUT/$BASE.collateral.json > results/gain-vs-factorised/e4-collateral-$BASE.txt 2> $LOG/e4-collateral-$BASE.err \
  && say "collateral ok" || say "collateral FAILED"
say "E4_DONE $BASE"
