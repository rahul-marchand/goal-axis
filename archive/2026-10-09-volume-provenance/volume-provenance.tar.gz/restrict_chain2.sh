#!/usr/bin/env bash
set -uo pipefail
cd /workspace/GoalMisgeneralisation
export PATH="$HOME/.local/bin:$PATH"
export JAX_COMPILATION_CACHE_DIR=/workspace/data/jax-cache
mkdir -p /workspace/data/logs/restrict figures/data/restricted results
LOG=/workspace/data/logs/restrict/chain2.log
base=vit11nvg1.s9012
echo "=== $base $(date -u +%H:%M) ===" >> $LOG
uv run python scripts/restricted_writes.py /workspace/data/runs/$base --levels /workspace/data/levels/values/1.00-0.50@500k \
    --json figures/data/restricted/$base.o1.json > results/restrict-$base.o1.txt 2> /workspace/data/logs/restrict/$base.err \
    && echo "$base ok" >> $LOG || echo "$base FAILED" >> $LOG
for s in 1 2 3; do
  base=bcnv11.s$s
  echo "=== $base $(date -u +%H:%M) ===" >> $LOG
  uv run python scripts/restricted_writes_bc.py /workspace/data/offline/runs/$base --demos /workspace/data/offline/demos/test.rho100 \
      --json figures/data/restricted/$base.o1.json > results/restrict-$base.o1.txt 2> /workspace/data/logs/restrict/$base.err \
      && echo "$base ok" >> $LOG || echo "$base FAILED" >> $LOG
done
mkdir -p /workspace/data/figures-data/restricted && cp figures/data/restricted/*.json /workspace/data/figures-data/restricted/
echo RESTRICT2_DONE >> $LOG
