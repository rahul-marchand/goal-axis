#!/usr/bin/env bash
set -uo pipefail
export PYTHONPATH=/workspace/gm-plan
export PYTHONUNBUFFERED=1
export XLA_PYTHON_CLIENT_PREALLOCATE=false
PY=/workspace/GoalMisgeneralisation/.venv/bin/python
OUT=/workspace/data/offline/results
mkdir -p $OUT
cd /workspace/gm-plan
for run in bc11.rho050.s1 bc11.rho100.s1; do
  echo "=== $run $(date -u +%H:%M:%S) ==="
  $PY experiments/030_bc_rewrite_the_plan.py /workspace/data/offline/runs/$run \
      --demos /workspace/data/offline/demos/test.rho050 \
      --patch --json $OUT/offline-bc-rewrite.$run.json \
      > $OUT/offline-bc-rewrite.$run.txt 2>&1
  echo "exit $? at $(date -u +%H:%M:%S)"
done
echo ALLDONE
