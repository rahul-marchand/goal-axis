#!/bin/bash
set -uo pipefail
export PATH=/root/.local/bin:$PATH
export JAX_COMPILATION_CACHE_DIR=/workspace/data/jax-cache
cd /workspace/GoalMisgeneralisation
UV=/root/.local/bin/uv
LEVELS=/workspace/data/levels/values/1.00-0.50@500k
for agent in novalue11g1.s1234 resnet11nvg1.s1234 vit11nvg1.s9012; do
  for r in 2 3; do
    $UV run python scripts/value_axis_sweep.py --agent "$agent" --objectives 1 \
      --offsets 0.1 0.2 0.3 0.4 --steps 400000 --replicate "$r" || echo "SIGMAFT_SWEEP_FAILED $agent r$r"
  done
  cp=$(python3 -c "import json;print(json.load(open(\"/workspace/data/runs/$agent/BASE.json\"))[\"checkpoint\"])")
  for r in 2 3; do
    $UV run python experiments/014_value_axis_analysis.py \
      --base "/workspace/data/runs/$agent/$cp" --arms "/workspace/data/runs/$agent/arms" \
      --levels "$LEVELS" --prefix o1 --base-value 0.5 --arm-steps 400000 --at -1 --replicate "$r" \
      > "results/g1-sigmaft-$agent-o1.r$r.txt" 2> "results/g1-sigmaft-$agent-o1.r$r.err" || echo "SIGMAFT_MEASURE_FAILED $agent r$r"
  done
done
echo SIGMAFT_DONE
