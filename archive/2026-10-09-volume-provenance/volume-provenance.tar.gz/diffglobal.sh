set -uo pipefail
export PATH=$HOME/.local/bin:$PATH
export XLA_PYTHON_CLIENT_PREALLOCATE=false
export XLA_PYTHON_CLIENT_MEM_FRACTION=0.20
cd /workspace/GoalMisgeneralisation
LOG=/workspace/data/steer-differential-global.txt
: > "$LOG"
echo "### differential, applied at every cell (the variant the overnight script missed)" | tee -a "$LOG"
uv run python experiments/008_steer_at_the_head.py \
    /workspace/data/runs/clean11fv/local-files/cp_140206080 \
    --levels /workspace/data/levels11 --episodes 2048 --differential \
    --alphas -12 -6 0 6 12 2>&1 \
    | grep -viE "userwarning|logger\.warn|gym\.logger|deprecationwarning|^\s+moved|^\s*$" | tee -a "$LOG"
echo "DONEDIFFGLOBAL" | tee -a "$LOG"
