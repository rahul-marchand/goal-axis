#!/bin/bash
# E11 continuation: where the route model's value axis lives, and whether a turn works.
# Trimmed after the brightness sweeps showed the input slice moves tau by ~0 at every scale.
set -uo pipefail
ulimit -n $(ulimit -Hn)
export PYTHONUNBUFFERED=1 XLA_PYTHON_CLIENT_PREALLOCATE=false JAX_COMPILATION_CACHE_DIR=/workspace/data/jax-cache

SNAP=/workspace/gvf-e11-snap
PY=/workspace/GoalMisgeneralisation/.venv/bin/python
DATA=/workspace/data
RUNS=$DATA/offline/runs/scaling
DEMOS=$DATA/offline/demos/scaling
REPO=/workspace/GoalMisgeneralisation
OUT=$REPO/results/gain-vs-factorised
JSON=$DATA/figures-data/gain-vs-factorised
LOG=$DATA/logs/gvf
mkdir -p "$OUT" "$JSON" "$LOG"
cd $SNAP

L=$LOG/e11.log
say() { echo "[$(date -u +%H:%M:%S)] $*" >> $L; }

run() { # model tag steps n_edit extra...
  local m=$1 tag=$2 steps=$3 n=$4; shift 4
  say "$m $tag"
  timeout 5400 $PY scripts/cheapest_edit.py $RUNS/sc11.$m.s1 --offline --demos $DEMOS \
    --target soft --seeds 0 1 --steps $steps --n-edit $n --n-eval 2048 \
    --shifts -4 -2 2 4 --eval-shifts -8 -4 -2 2 4 8 --steps-tag 1000 --sweep o1 \
    --json $JSON/e11-$m.$tag.json --save-deltas $JSON/e11-$m.$tag.npz "$@" \
    > $OUT/e11-edit-sc11.$m.$tag.txt 2> $LOG/e11-edit-$m.$tag.err \
    && say "$m $tag ok" || say "$m $tag FAILED"
}

say "=== stage 2: localisation first, then the turn ==="

# Direction profile for the two models the localisation covers (deliverable 4).
for m in d128l4 d512l4; do
  say "$m direction profile"
  timeout 3600 $PY scripts/direction_profile.py $RUNS/sc11.$m.s1 --offline \
    --demos $DEMOS --n-levels 256 --sweep o1 --steps-tag 1000 \
    --json $JSON/direction-sc11.$m.json > $OUT/direction-sc11.$m.txt 2> $LOG/e11-dir-$m.err \
    && say "$m direction ok" || say "$m direction FAILED"
done

# d512l4 -- the veridical-distance model. Where can value live?
run d512l4 head    200 2048 --family dense --modules head
run d512l4 late    200 2048 --family dense --modules "block 2 attention" "block 2 mlp" "block 3 attention" "block 3 mlp"
run d512l4 early   200 2048 --family dense --modules "block 0 attention" "block 0 mlp" "block 1 attention" "block 1 mlp"
run d512l4 embed   200 2048 --family dense --modules embed
run d512l4 all     200 2048 --family dense
say "D512L4_MODULES_DONE"

# d128l4 -- the small reference, same families.
run d128l4 head    300 4096 --family dense --modules head
run d128l4 late    300 4096 --family dense --modules "block 2 attention" "block 2 mlp" "block 3 attention" "block 3 mlp"
run d128l4 early   300 4096 --family dense --modules "block 0 attention" "block 0 mlp" "block 1 attention" "block 1 mlp"
run d128l4 embed   300 4096 --family dense --modules embed
run d128l4 all     300 4096 --family dense
say "D128L4_MODULES_DONE"

# The two-parameter knobs at the embedding: does a turn do what a gain cannot?
run d512l4 rotation.lr3e-2 200 2048 --family rotation --lr 3e-2
run d128l4 rotation.lr3e-2 300 4096 --family rotation --lr 3e-2
run d512l4 gain.lr3e-2     200 2048 --family gain     --lr 3e-2
run d128l4 gain.lr3e-2     300 4096 --family gain     --lr 3e-2
say "KNOBS_DONE"

# Spare capacity: the other two models' knobs and localisation, if the pod is still up.
run d256l4  rotation.lr3e-2 300 4096 --family rotation --lr 3e-2
run d512l16 rotation.lr3e-2 150 2048 --family rotation --lr 3e-2
run d512l16 late 150 2048 --family dense --modules "block 12 attention" "block 12 mlp" "block 13 attention" "block 13 mlp" "block 14 attention" "block 14 mlp" "block 15 attention" "block 15 mlp"
run d512l16 embed 150 2048 --family dense --modules embed
say "E11_CHAIN_DONE"
