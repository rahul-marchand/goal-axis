#!/bin/bash
# Fresh axis through the far (colour-keyed, past-parity) arms, every base, both families.
set -u
export PATH=$HOME/.local/bin:$PATH
export PYTHONUNBUFFERED=1
export JAX_COMPILATION_CACHE_DIR=/workspace/data/jax-cache
export GOALMISGEN_REPO=/workspace/GoalMisgeneralisation
cd /workspace/GoalMisgeneralisation
PY=.venv/bin/python
LEVELS=/workspace/data/levels/values/1.00-0.50@500k
OUT=/workspace/data/figures-data/far-axis
mkdir -p $OUT
BASES="resnet11nvg1.s1234 resnet11nvg1.s2468 resnet11nvg1.s3456 vit11nvg1.s9012 novalue11g1.s1234 novalue11g1.s9012 novalue11g1.s3456e"
for base in $BASES; do
  for spec in "k1:0.5:1.2 1.3 1.4 1.5 1.75 2.0" "k0:1.0:0.0 0.1 0.2 0.3"; do
    IFS=: read -r fam bv far <<< "$spec"
    [ -s "$OUT/$base-$fam.json" ] && { echo "have $base $fam"; continue; }
    echo "=== $base $fam $(date -u +%H:%M)"
    $PY /root/far_axis_fit.py /workspace/data/runs/$base --family $fam --base-value $bv --far $far \
      --levels $LEVELS --json $OUT/$base-$fam.json > results/far-axis-$base-$fam.txt 2> results/far-axis-$base-$fam.err \
      || echo "FARAXIS_FAILED $base $fam"
  done
done
for seed in 1 2 3; do
  for spec in "k1:0.8 0.9 1.0 1.25 1.5" "k0:-0.8 -0.9 -1.0"; do
    IFS=: read -r fam far <<< "$spec"
    [ -s "$OUT/bcnv11.s$seed-$fam.json" ] && { echo "have bc s$seed $fam"; continue; }
    echo "=== bcnv11.s$seed $fam $(date -u +%H:%M)"
    XLA_PYTHON_CLIENT_MEM_FRACTION=0.5 $PY /root/far_axis_fit_bc.py /workspace/data/offline/runs/bcnv11.s$seed --family $fam --far $far \
      --demos /workspace/data/offline/demos/test.rho100 --json $OUT/bcnv11.s$seed-$fam.json \
      > results/far-axis-bcnv11.s$seed-$fam.txt 2> results/far-axis-bcnv11.s$seed-$fam.err \
      || echo "FARAXIS_FAILED bc s$seed $fam"
  done
done
echo FARAXIS_DONE
