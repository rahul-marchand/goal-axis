#!/bin/bash
# edit_pilot.sh TAG [cheapest_edit args...] -> /workspace/data/logs/edit/pilot-TAG.txt
export XLA_PYTHON_CLIENT_PREALLOCATE=false
ulimit -n $(ulimit -Hn)
cd /workspace/GoalMisgeneralisation
TAG=$1; shift
uv run --no-sync python scripts/cheapest_edit.py "$@" > /workspace/data/logs/edit/pilot-$TAG.txt 2>&1
echo "EXIT $?" >> /workspace/data/logs/edit/pilot-$TAG.txt
