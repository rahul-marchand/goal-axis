#!/bin/bash
# Watches a training run and records what happened, so a session that restarts
# overnight picks the story up from a file rather than from memory. Does not
# restart anything: the documented failure here is a hang on the evaluation
# thread, and relaunching a 10-hour run unattended wastes the GPU more often
# than it saves it.
RUN=${1:-novalue11}
LOG=/workspace/data/runs/$RUN.log
STATUS=/workspace/data/runs/$RUN.status
STALL=1500

say () { echo "$(date -u '+%H:%M:%S') $*" >> "$STATUS"; }
say "watchdog started for $RUN"
last=0; changed=$(date +%s); stalled=no

while true; do
    sleep 120
    size=$(stat -c %s "$LOG" 2>/dev/null || echo 0)
    now=$(date +%s)
    [ "$size" -ne "$last" ] && { last=$size; changed=$now; [ "$stalled" = yes ] && { say "RECOVERED"; stalled=no; }; }

    if ! pgrep -f "001_maze_repro.py" > /dev/null; then
        if grep -q "RUN COMPLETE" "$LOG" 2>/dev/null; then say "DONE - finished cleanly"; else
            say "CRASHED - gone without RUN COMPLETE. Last 60 lines:"; tail -60 "$LOG" >> "$STATUS"; fi
        exit 0
    fi
    if [ "$stalled" = no ] && [ $((now - changed)) -gt "$STALL" ]; then
        stalled=yes
        say "STALLED - no output for $((now - changed))s but the process is alive."
        say "That is the signature of an exception on the evaluation thread. Last 60 lines:"
        tail -60 "$LOG" >> "$STATUS"
        say "GPU: $(nvidia-smi --query-gpu=utilization.gpu,memory.used --format=csv,noheader)"
    fi
    [ $(( $(date +%s) % 3600 )) -lt 120 ] && say "alive - $(grep -oE 'learner_policy_version [0-9]+' "$LOG" | tail -1)"
done
