#!/usr/bin/env bash
set -uo pipefail
export PYTHONPATH=/workspace/gm-plan PYTHONUNBUFFERED=1 XLA_PYTHON_CLIENT_PREALLOCATE=false
export XLA_PYTHON_CLIENT_MEM_FRACTION=0.25
PY=/workspace/GoalMisgeneralisation/.venv/bin/python
OUT=/workspace/data/offline/results
D=/workspace/data/offline/demos
R=/workspace/data/offline/runs
cd /workspace/gm-plan

# 1. Is the distance readable at the end-of-input token at all? If not, the
#    write is dead and nothing after this matters. Cheapest decisive check.
echo "=== 1 sep read $(date -u +%H:%M:%S) ==="
$PY experiments/031_bc_outcome_keyed_distance.py $R/bcnv11.s1 --demos $D/test.rho100 \
    --sites sep --json $OUT/offline-bc-distance-sep.bcnv11.s1.json \
    > $OUT/offline-bc-distance-sep.bcnv11.s1.txt 2>&1
echo "exit $? at $(date -u +%H:%M:%S)"

# 2. The write, gap first, at the two depths that can reach the route.
echo "=== 2 sep write (gap) $(date -u +%H:%M:%S) ==="
$PY experiments/032_bc_write_the_distance.py $R/bcnv11.s1 --demos $D/test.rho100 \
    --targets gap --depths 2 3 4 --episodes 1024 \
    --json $OUT/offline-bc-writesep-gap.bcnv11.s1.json \
    > $OUT/offline-bc-writesep-gap.bcnv11.s1.txt 2>&1
echo "exit $? at $(date -u +%H:%M:%S)"

# 3. The write, per-objective, everywhere it could act.
echo "=== 3 sep write (all targets) $(date -u +%H:%M:%S) ==="
$PY experiments/032_bc_write_the_distance.py $R/bcnv11.s1 --demos $D/test.rho100 \
    --json $OUT/offline-bc-writesep.bcnv11.s1.json \
    > $OUT/offline-bc-writesep.bcnv11.s1.txt 2>&1
echo "exit $? at $(date -u +%H:%M:%S)"
echo TRIAGEDONE
