#!/bin/bash
# Extend an argmax-unconverged ViT at its own annealed tail LR, decode-check,
# then arms+measures if converged.  EXTSEED=1234 bash vit_ext.sh
set -u
export PATH=$HOME/.local/bin:$PATH
export PYTHONUNBUFFERED=1
export JAX_COMPILATION_CACHE_DIR=/workspace/data/jax-cache
cd /workspace/GoalMisgeneralisation
UV=$HOME/.local/bin/uv
SRC=/workspace/data/runs/vit11nvg1.s$EXTSEED
CP=$SRC/local-files/cp_249999360
LR=$(python3 -c "import json;print(json.load(open(\"$CP/cfg.json\"))[\"cfg\"][\"final_learning_rate\"])")
EXT=/workspace/data/runs/vit11nvg1.s${EXTSEED}e
NAME=vit11nvg1.s${EXTSEED}e
echo "=== $NAME: extend +100M at tail LR $LR"
$UV run python experiments/013_value_axis.py "$CP" \
  --objective-values 1.0 0.5 --levels /workspace/data/levels/values/1.00-0.50@1M \
  --steps 100000000 --lr "$LR" --checkpoints 8 --seed 43 --run-dir "$EXT" \
  --note "Tail-LR continuation of vit11nvg1.s$EXTSEED (argmax-unconverged at 250M): the g1 protocol extension." \
  || echo "EXT_TRAIN_FAILED $NAME"
LAST=$(ls "$EXT/local-files" | tail -1)
python3 -c "
import json
from pathlib import Path
run = Path(\"$EXT\")
payload = {\"checkpoint\": f\"local-files/$LAST\", \"values\": [1.0, 0.5], \"objectives\": 2,
           \"picked\": \"extension-final\", \"extended_from\": \"s$EXTSEED@250M, +100M at $LR\"}
(run / \"BASE.json\").write_text(json.dumps(payload, indent=1))
print(\"BASE.json ->\", \"$LAST\")"
$UV run python scripts/decode_h1_drc.py "$EXT" --levels /workspace/data/levels/values/1.00-0.50@500k \
  --split test --episodes 2048 --num-envs 128 --out /tmp/vitext_$EXTSEED.npz > /tmp/vitext_$EXTSEED.log 2>&1
grep -E "reached|chose" /tmp/vitext_$EXTSEED.log
if grep -qE "reached (9[0-9]|100)" /tmp/vitext_$EXTSEED.log; then
  echo "EXT_CONVERGED $NAME"
  env NET=vit SEED=43 STEPS=100000000 NAME=$NAME PICK_BAR=0.85 bash /workspace/base_chain_g1.sh >> /workspace/data/logs/g1/$NAME.log 2>&1
else
  echo "EXT_STILL_UNCONVERGED $NAME"
fi
echo "VITEXT_DONE $NAME"
