#!/bin/bash
# E2 plan-invariance: three DRC g1 bases in parallel on one 4090.
cd /workspace/GoalMisgeneralisation
ulimit -n $(ulimit -Hn)
export XLA_PYTHON_CLIENT_PREALLOCATE=false
mkdir -p /workspace/data/logs/gvf /workspace/data/figures-data/plan_invariance
for base in novalue11g1.s1234 novalue11g1.s9012 novalue11g1.s3456e; do
  ( uv run --no-sync python scripts/plan_invariance.py /workspace/data/runs/$base \
      --levels /workspace/data/levels/values/1.00-0.50@500k \
      --json /workspace/data/figures-data/plan_invariance/$base.json \
      > results/plan-invariance-$base.txt 2> /workspace/data/logs/gvf/e2-$base.err
    echo "$base exit $?" >> /workspace/data/logs/gvf/e2.log ) &
done
wait
echo E2_DONE >> /workspace/data/logs/gvf/e2.log
