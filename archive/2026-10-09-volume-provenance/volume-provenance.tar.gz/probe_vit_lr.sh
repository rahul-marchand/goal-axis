#!/bin/bash
# One ViT learning-rate probe: train on the real 250M schedule, stop at ~75M,
# score by argmax decode.  CONF=b LR=4e-4 FLR=4e-5 bash probe_vit_lr.sh
set -u
export PATH=$HOME/.local/bin:$PATH
export PYTHONUNBUFFERED=1
export JAX_COMPILATION_CACHE_DIR=/workspace/data/jax-cache
cd /workspace/GoalMisgeneralisation
NAME=vitlr-$CONF
RUN=/workspace/data/runs/probe/$NAME
rm -rf "$RUN"; mkdir -p "$RUN"
$HOME/.local/bin/uv run python experiments/001_maze_repro.py --net vit --correlation 1.0 \
  --min-size 11 --max-size 11 --levels /workspace/data/levels/values/1.00-0.50@1M --hide-values \
  --gamma 1.0 --lr "$LR" --final-lr "$FLR" --total-timesteps 250000000 --seed 1234 --run-dir "$RUN" \
  --note "ViT LR probe $CONF: peak $LR, floor $FLR, stopped at ~75M for comparison." \
  > /workspace/data/logs/g1/probe-$NAME.log 2>&1 &
sleep 45
while pgrep -f "[0]01_maze_repro" > /dev/null; do
  last=$(ls "$RUN/local-files" 2>/dev/null | tail -1)
  if [ -n "${last:-}" ]; then
    step=$((10#${last#cp_}))
    [ "$step" -ge 75000000 ] && break
  fi
  sleep 60
done
pkill -9 -f "[0]01_maze_repro"; sleep 5
LAST=$(ls "$RUN/local-files" 2>/dev/null | tail -1)
OUT=$($HOME/.local/bin/uv run python scripts/decode_h1_drc.py "$RUN/local-files/$LAST" \
  --levels /workspace/data/levels/values/1.00-0.50@500k --split test --episodes 1024 --num-envs 128 \
  --out /tmp/probe_$CONF.npz 2>/dev/null | grep -oE "reached [0-9.]+%.*")
echo "PROBE_RESULT $CONF peak=$LR floor=$FLR at=$LAST $OUT" >> /workspace/data/probe_results.txt
echo "PROBE_DONE $CONF"
