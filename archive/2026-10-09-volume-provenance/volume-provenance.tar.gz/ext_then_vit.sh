#!/bin/bash
# Extend one near-miss DRC at the annealed tail LR, verify by decode, run its
# arms+measures, then train one fresh ViT seed.
#   EXTSEED=5678 VITSEED=1111 bash ext_then_vit.sh
set -u
export PATH=$HOME/.local/bin:$PATH
export PYTHONUNBUFFERED=1
export JAX_COMPILATION_CACHE_DIR=/workspace/data/jax-cache
cd /workspace/GoalMisgeneralisation
UV=$HOME/.local/bin/uv
SRC=/workspace/data/runs/novalue11g1.s$EXTSEED
EXT=/workspace/data/runs/novalue11g1.s${EXTSEED}e
NAME=novalue11g1.s${EXTSEED}e

echo "=== $NAME: extend +100M at tail LR 4e-6"
$UV run python experiments/013_value_axis.py "$SRC/local-files/cp_149995520" \
  --objective-values 1.0 0.5 --levels /workspace/data/levels/values/1.00-0.50@1M \
  --steps 100000000 --lr 4e-6 --checkpoints 8 --seed 42 --run-dir "$EXT" \
  --note "Tail-LR continuation of novalue11g1.s$EXTSEED (unconverged at 150M): the g1 protocol extension." \
  || echo "EXT_TRAIN_FAILED $NAME"
LAST=$(ls "$EXT/local-files" | tail -1)
python3 - "$EXT" "$LAST" <<PY
import json, sys
from pathlib import Path
run, last = Path(sys.argv[1]), sys.argv[2]
payload = {"checkpoint": f"local-files/{last}", "values": [1.0, 0.5], "objectives": 2,
           "picked": "extension-final", "extended_from": "s$EXTSEED@150M, +100M at 4e-6"}
(run / "BASE.json").write_text(json.dumps(payload, indent=1))
print("BASE.json ->", last)
PY
echo "=== $NAME: convergence decode"
$UV run python scripts/decode_h1_drc.py "$EXT" --levels /workspace/data/levels/values/1.00-0.50@500k \
  --split test --episodes 2048 --num-envs 128 --out /tmp/ext_$EXTSEED.npz > /tmp/ext_$EXTSEED.log 2>&1
grep -E "reached|chose" /tmp/ext_$EXTSEED.log
if grep -qE "reached 9[5-9]|reached 100" /tmp/ext_$EXTSEED.log; then
  echo "EXT_CONVERGED $NAME"
  env NET=drc33 SEED=42 STEPS=100000000 NAME=$NAME bash /workspace/base_chain_g1.sh >> /workspace/data/logs/g1/$NAME.log 2>&1
else
  echo "EXT_STILL_UNCONVERGED $NAME"
fi

echo "=== vit seed s$VITSEED"
env NET=vit SEED=$VITSEED STEPS=250000000 NAME=vit11nvg1.s$VITSEED PICK_BAR=0.85 bash /workspace/base_chain_g1.sh \
  > /workspace/data/logs/g1/vit11nvg1.s$VITSEED.log 2>&1
echo "POD_PROGRAM_DONE s${EXTSEED}e+s$VITSEED"
