#!/bin/bash
# Throughput probe: train NET for 2M steps at gamma=1, report median SPS.
#   TAG=solo NET=drc33 MEMFRAC= bash profile_g1.sh
set -u
export PATH="$HOME/.local/bin:$PATH"
export PYTHONUNBUFFERED=1
[ -n "${MEMFRAC:-}" ] && export XLA_PYTHON_CLIENT_MEM_FRACTION=$MEMFRAC
cd /workspace/GoalMisgeneralisation
RUN=/tmp/profile-$TAG-$NET
rm -rf "$RUN"
"$HOME/.local/bin/uv" run python experiments/001_maze_repro.py --net "$NET" --correlation 1.0 \
  --min-size 11 --max-size 11 --levels /workspace/data/levels/values/1.00-0.50@1M \
  --hide-values --gamma 1.0 --total-timesteps 2000000 --seed 99 --run-dir "$RUN" \
  > /tmp/profile-$TAG-$NET.log 2>&1
python3 - "$RUN/metrics.csv" "$TAG-$NET" <<'PY'
import csv, sys
rows = list(csv.DictReader(open(sys.argv[1])))
vals = sorted(float(r["charts/0/SPS"]) for r in rows if r.get("charts/0/SPS"))
print(f"PROFILE {sys.argv[2]}: median SPS {vals[len(vals)//2]:.0f} (n={len(vals)})" if vals else f"PROFILE {sys.argv[2]}: no SPS rows")
PY
