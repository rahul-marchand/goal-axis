#!/bin/bash
# Stage-2 control with the canonical expert and bedrock walls: regenerate the
# demonstrations now (CPU), then train cxnv15c.s1 (60k steps) + arms + analysis
# once the old-expert continuation chain has finished with the GPU.
set -u
export PATH=$HOME/.local/bin:$PATH UV_NO_SYNC=1 PYTHONUNBUFFERED=1 XLA_PYTHON_CLIENT_PREALLOCATE=false
cd /workspace/gm-craftax
export DEMOS=/workspace/data/craftax/demos-canon NAME=cxnv15c ARM_OFFSETS="0.45 0.3 0.2 0.1" BASE_STEPS=60000
bash scripts/craftax_chain.sh demos || { echo "CONTROL_DEMOS_FAILED"; exit 1; }
echo "CONTROL_DEMOS_DONE"
until grep -q "CONTINUE_DONE\|CONTINUE_FAILED" /workspace/data/logs/craftax/continue_s1.log; do sleep 60; done
bash scripts/craftax_chain.sh seed 1
echo "CONTROL_DONE"
