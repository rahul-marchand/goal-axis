#!/bin/bash
# E8: the leftover patch, the lever's ceiling, the axis's own mix, and censored tau.
set -uo pipefail
ulimit -n $(ulimit -Hn)
export PYTHONUNBUFFERED=1 XLA_PYTHON_CLIENT_PREALLOCATE=false JAX_COMPILATION_CACHE_DIR=/workspace/data/jax-cache
SNAP=/workspace/gvf-e8-snap
cd $SNAP
PY=/workspace/GoalMisgeneralisation/.venv/bin/python
DATA=/workspace/data; LV=$DATA/levels/values/1.00-0.50@500k
REPO=/workspace/GoalMisgeneralisation
RES=$REPO/results/gain-vs-factorised; OUT=$DATA/figures-data/leftover; LOG=$DATA/logs/gvf
mkdir -p $RES $OUT $LOG
L=$LOG/e8.log
say() { echo "[$(date -u +%H:%M:%S)] $*" >> $L; }
say "=== E8 start, snapshot $SNAP"

for BASE in novalue11g1.s1234 novalue11g1.s9012 novalue11g1.s3456e; do
  say "$BASE: leftover + signal + mix"
  $PY scripts/leftover_patch.py $DATA/runs/$BASE --levels $LV \
      --json $OUT/$BASE.json \
      > $RES/leftover-$BASE.o1.txt 2> $LOG/e8-$BASE.err \
    && say "$BASE ok" || say "$BASE FAILED"

  say "$BASE: censored tau"
  JAX_PLATFORMS=cpu $PY scripts/censored_tau.py $DATA/figures-data/axis-far-dose/$BASE \
      --json $OUT/censored-$BASE.json \
      > $RES/censored-tau-$BASE.txt 2> $LOG/e8-$BASE.censored.err \
    && say "$BASE censored ok" || say "$BASE censored FAILED"
done
say "E8_DONE"
