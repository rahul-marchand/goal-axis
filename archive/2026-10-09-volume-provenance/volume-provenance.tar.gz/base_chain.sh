#!/bin/bash
# One new base agent, end to end: train, pick the healthy checkpoint, BASE.json,
# arm grids (even o-grid both sweeps + past-parity x-values), measures.
#   NET=resnet SEED=5678 STEPS=150000000 NAME=resnet11novalue.s5678 bash base_chain.sh
set -uo pipefail
export PATH="$HOME/.local/bin:$PATH"
export PYTHONUNBUFFERED=1
cd /workspace/GoalMisgeneralisation
UV="$HOME/.local/bin/uv"
DATA=/workspace/data
LEVELS_TRAIN=$DATA/levels/values/1.00-0.50@1M
LEVELS_MEASURE=$DATA/levels/values/1.00-0.50@500k
RUN=$DATA/runs/$NAME
LOG=$DATA/logs/base3
mkdir -p "$LOG"

echo "=== $NAME: train $STEPS steps (net=$NET seed=$SEED)"
if [ ! -f "$RUN/BASE.json" ]; then
  $UV run python experiments/001_maze_repro.py --net "$NET" --correlation 1.0 \
    --min-size 11 --max-size 11 --levels "$LEVELS_TRAIN" --hide-values \
    --total-timesteps "$STEPS" --seed "$SEED" --run-dir "$RUN" \
    --note "Third-base replication for the blog core figure, $(date -u +%F)." \
    || { echo "TRAIN_FAILED $NAME"; exit 1; }

  # Pick the last checkpoint before any late collapse (the resnet11novalue.s1234
  # lesson): latest cp whose nearby eval success stays >= 0.95.
  $UV run python - "$RUN" <<'PY' || { echo "BASEPICK_FAILED"; exit 1; }
import json, sys
from pathlib import Path
import pandas as pd
from goalmisgen.volume import parse_checkpoint_dirname

run = Path(sys.argv[1])
frame = pd.read_csv(run / "metrics.csv", index_col=0)
col = next(c for c in frame.columns if c.endswith("returned_avg_episode_success"))
success = frame[col].dropna()
step_col = next((c for c in ("global_step", "_step") if c in frame.columns), None)
steps = frame.loc[success.index, step_col] if step_col else success.index
cps = sorted((parse_checkpoint_dirname(p.name), p.name) for p in (run / "local-files").glob("cp_*"))
healthy = None
for cp_step, name in cps:
    window = success[(steps >= cp_step - 8e6) & (steps <= cp_step + 2e6)]
    if len(window) == 0 or window.min() >= 0.95:
        healthy = (cp_step, name)
final = cps[-1]
chosen = healthy or final
if chosen != final:
    print(f"late collapse detected: using {chosen[1]} not {final[1]}")
payload = {"checkpoint": f"local-files/{chosen[1]}", "values": [1.0, 0.5],
           "objectives": 2, "steps": chosen[0], "picked": "healthy" if chosen != final else "final"}
(run / "BASE.json").write_text(json.dumps(payload, indent=1))
print("BASE.json ->", payload["checkpoint"])
PY
fi

echo "=== $NAME: arms"
$UV run python scripts/value_axis_sweep.py --agent "$NAME" --objectives 0 1 \
  --offsets 0.1 0.2 0.3 0.4 --steps 400000 || echo "SWEEP_FAILED $NAME o"
$UV run python scripts/value_axis_sweep.py --agent "$NAME" --objectives 0 \
  --values 0.45 0.35 0.25 0.15 --steps 400000 --allow-reorder || echo "SWEEP_FAILED $NAME x0"
$UV run python scripts/value_axis_sweep.py --agent "$NAME" --objectives 1 \
  --values 1.05 1.15 1.25 1.35 --steps 400000 --allow-reorder || echo "SWEEP_FAILED $NAME x1"

echo "=== $NAME: measures"
CP=$(python3 -c "import json;print(json.load(open('$RUN/BASE.json'))['checkpoint'])")
m() { local prefix=$1 bv=$2 out=$3; shift 3
  $UV run python experiments/014_value_axis_analysis.py \
    --base "$RUN/$CP" --arms "$RUN/arms" --levels "$LEVELS_MEASURE" \
    --prefix "$prefix" --base-value "$bv" --arm-steps 400000 --at -1 "$@" \
    > "results/base3-$NAME-$prefix.txt" 2> "results/base3-$NAME-$prefix.err" || echo "MEASURE_FAILED $NAME $prefix"
}
m o0 1.0 x --extrapolate 0.45 0.35 0.25 0.15
m o1 0.5 x --extrapolate 1.05 1.15 1.25 1.35
m x0 1.0 x
m x1 0.5 x
echo "BASE_CHAIN_DONE $NAME"
