set -euo pipefail
export PATH=$HOME/.local/bin:$PATH
cd /workspace/GoalMisgeneralisation
until ! pgrep -f "005_outcome" > /dev/null; do sleep 20; done
git fetch -q origin && git checkout -q probe-distance-field && git pull -q
LOG=/workspace/data/psychometric.txt
: > "$LOG"
for rho in 1.0 0.0; do
  echo "### clean11fv, test rho=$rho" | tee -a "$LOG"
  uv run python experiments/006_psychometric.py \
      /workspace/data/runs/clean11fv/local-files/cp_140206080 \
      --levels /workspace/data/levels11 --correlation $rho --episodes 4096 2>&1 \
      | grep -viE "userwarning|logger\.warn|gym\.logger|^\s*$" | tee -a "$LOG"
  echo | tee -a "$LOG"
done
echo "DONEPSYCHO" | tee -a "$LOG"
