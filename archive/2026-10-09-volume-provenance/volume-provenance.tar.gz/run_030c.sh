#!/usr/bin/env bash
set -uo pipefail
export PYTHONPATH=/workspace/gm-plan PYTHONUNBUFFERED=1 XLA_PYTHON_CLIENT_PREALLOCATE=false
PY=/workspace/GoalMisgeneralisation/.venv/bin/python
OUT=/workspace/data/offline/results
D=/workspace/data/offline/demos
R=/workspace/data/offline/runs
cd /workspace/gm-plan

run () {  # name, script, args...
  name="$1"; shift
  echo "=== ${name} $(date -u +%H:%M:%S) ==="
  "$@" > "${OUT}/${name}.txt" 2>&1
  echo "exit $? at $(date -u +%H:%M:%S)"
}

# The Experiment 2 base: values are learned constants, so nothing here is
# readable off the input.
run offline-bc-rewrite.bcnv11.s1 $PY experiments/030_bc_rewrite_the_plan.py $R/bcnv11.s1 \
    --demos $D/test.rho100 --patch --json $OUT/offline-bc-rewrite.bcnv11.s1.json
run offline-bc-distance.bcnv11.s1 $PY experiments/031_bc_outcome_keyed_distance.py $R/bcnv11.s1 \
    --demos $D/test.rho100 --json $OUT/offline-bc-distance.bcnv11.s1.json
# The same read where the value IS an input, so the two can be compared.
run offline-bc-distance.bc11.rho050.s1 $PY experiments/031_bc_outcome_keyed_distance.py $R/bc11.rho050.s1 \
    --demos $D/test.rho050 --json $OUT/offline-bc-distance.bc11.rho050.s1.json
# A second seed of whichever depth moved.
run offline-bc-rewrite.bcnv11.s2 $PY experiments/030_bc_rewrite_the_plan.py $R/bcnv11.s2 \
    --demos $D/test.rho100 --depths 3 --patch --json $OUT/offline-bc-rewrite.bcnv11.s2.json
echo ALLDONE
