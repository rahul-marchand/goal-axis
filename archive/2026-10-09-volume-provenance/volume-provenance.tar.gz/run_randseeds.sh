#!/usr/bin/env bash
set -uo pipefail
export PYTHONPATH=/workspace/gm-plan PYTHONUNBUFFERED=1 XLA_PYTHON_CLIENT_PREALLOCATE=false
export XLA_PYTHON_CLIENT_MEM_FRACTION=0.4
PY=/workspace/GoalMisgeneralisation/.venv/bin/python
OUT=/workspace/data/offline/results
cd /workspace/gm-plan
for seed in 1 2 3 4 5; do
  echo "=== random draw seed $seed $(date -u +%H:%M:%S) ==="
  $PY experiments/030_bc_rewrite_the_plan.py /workspace/data/offline/runs/bc11.rho050.s1 \
      --demos /workspace/data/offline/demos/test.rho050 --depths 3 \
      --arms random shuffled --alphas 0.0 0.2 --seed $seed \
      > $OUT/offline-bc-randdraw.s$seed.txt 2>&1
  echo "exit $? at $(date -u +%H:%M:%S)"
done
echo RANDDONE
