set -uo pipefail
export PATH=$HOME/.local/bin:$PATH
cd /workspace/GoalMisgeneralisation
git fetch -q origin && git checkout -q goal-structure && git pull -q
mkdir -p /workspace/data/valueaxis/results
.venv/bin/python experiments/014_value_axis_analysis.py \
  --base /workspace/data/runs/novalue11/local-files/cp_140206080 \
  --arms /workspace/data/valueaxis/runs \
  --levels /workspace/data/valueaxis/levels/v050 \
  --at -1 \
  --extrapolate -0.5 -0.2 0.0 0.1 0.2 1.1 1.2 1.3 1.5 2.0 3.0 \
  > /workspace/data/valueaxis/results/ood.txt 2>&1
echo "OOD_DONE rc=$?"
