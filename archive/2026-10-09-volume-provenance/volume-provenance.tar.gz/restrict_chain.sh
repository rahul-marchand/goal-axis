#!/usr/bin/env bash
set -uo pipefail
cd /workspace/GoalMisgeneralisation
export PATH="$HOME/.local/bin:$PATH"
export JAX_COMPILATION_CACHE_DIR=/workspace/data/jax-cache
mkdir -p /workspace/data/logs/restrict figures/data/restricted results
LEVELS=/workspace/data/levels/values/1.00-0.50@500k
for base in novalue11g1.s1234 novalue11g1.s9012 novalue11g1.s3456e resnet11nvg1.s1234 resnet11nvg1.s2468 resnet11nvg1.s3456; do
  echo "=== $base $(date -u +%H:%M) ===" >> /workspace/data/logs/restrict/chain.log
  uv run python scripts/restricted_writes.py /workspace/data/runs/$base --levels $LEVELS \
      --json figures/data/restricted/$base.o1.json \
      > results/restrict-$base.o1.txt 2> /workspace/data/logs/restrict/$base.err \
      && echo "$base ok" >> /workspace/data/logs/restrict/chain.log \
      || echo "$base FAILED" >> /workspace/data/logs/restrict/chain.log
done
mkdir -p /workspace/data/figures-data/restricted && cp figures/data/restricted/*.json /workspace/data/figures-data/restricted/
echo RESTRICT_DONE >> /workspace/data/logs/restrict/chain.log
