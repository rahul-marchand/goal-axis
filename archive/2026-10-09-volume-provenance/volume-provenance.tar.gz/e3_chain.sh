#!/bin/bash
# E3 separability: decode all three DRC g1 bases concurrently on one GPU, then report.
ulimit -n $(ulimit -Hn)
export XLA_PYTHON_CLIENT_PREALLOCATE=false
cd /workspace/GoalMisgeneralisation
PY=.venv/bin/python
LOG=/workspace/data/logs/gvf
OUT=/workspace/data/figures-data/separability
mkdir -p $LOG $OUT
for base in novalue11g1.s1234 novalue11g1.s9012 novalue11g1.s3456e; do
  $PY scripts/separability_decode.py /workspace/data/runs/$base \
      --levels /workspace/data/levels/values/1.00-0.50@500k \
      --out $OUT/$base --episodes 131072 --coarse-episodes 16384 --num-envs 128 \
      > $LOG/e3-decode-$base.log 2>&1 &
done
wait
grep -L SEPARABILITY_DECODE_DONE $LOG/e3-decode-*.log && echo "E3 some decode did not finish" >> $LOG/e3.log
$PY scripts/separability_report.py $OUT/novalue11g1.s1234 $OUT/novalue11g1.s9012 $OUT/novalue11g1.s3456e \
    --resamples 200 --txt results/separability-drc-g1.txt --json $OUT/separability-drc-g1.json \
    > $LOG/e3-report.log 2>&1
echo "exit $?" >> $LOG/e3.log
echo E3_DONE >> $LOG/e3.log
