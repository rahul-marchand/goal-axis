#!/bin/bash
# Colour-keyed crossing arms for the route model, and their thresholds.
set -u
export PATH=$HOME/.local/bin:$PATH
export PYTHONUNBUFFERED=1
export JAX_COMPILATION_CACHE_DIR=/workspace/data/jax-cache
cd /workspace/GoalMisgeneralisation
UV=$HOME/.local/bin/uv
DATA=/workspace/data
DEMOS=$DATA/offline/demos
RUNS=$DATA/offline/runs

echo "=== crossing demonstrations (colours pinned to objectives)"
for tag in 1.00-1.00 1.00-1.10 1.00-1.20 0.50-0.50 0.40-0.50 0.30-0.50; do
  src="$DATA/levels/values/$tag@150k"
  for split_n in "train 50000" "test 2048"; do
    set -- $split_n
    out="$DEMOS/arms/$tag.$1.rho100.keyed"
    [ -f "$out/meta.json" ] && { echo "have $(basename $out)"; continue; }
    $UV run python scripts/generate_demos.py --levels "$src" --split "$1" --rho 1.0 --n "$2" \
      --colour-keyed --objective-values ${tag//-/ } --out "$out" > /dev/null 2>&1 \
      || echo "DEMOS_FAILED $tag $1"
  done
done

echo "=== crossing arms, three seeds"
# arm dir, its demo tag, and the seed offset: k1 raises colour 1 past colour 0,
# k0 lowers colour 0 past colour 1.
for seed in 1 2 3; do
  base=$RUNS/bcnv11.s$seed
  [ -d "$base" ] || { echo "no base bcnv11.s$seed"; continue; }
  init=$(ls -d $base/checkpoints/step_* | sort | tail -n1)
  i=0
  for spec in "k1+050@1k:1.00-1.00" "k1+060@1k:1.00-1.10" "k1+070@1k:1.00-1.20" \
              "k0-050@1k:0.50-0.50" "k0-060@1k:0.40-0.50" "k0-070@1k:0.30-0.50"; do
    dirname=${spec%%:*}; tag=${spec##*:}
    out="$base/arms/$dirname"
    [ -f "$out/done.json" ] && { echo "have $dirname of s$seed"; i=$((i+1)); continue; }
    XLA_PYTHON_CLIENT_PREALLOCATE=true XLA_PYTHON_CLIENT_MEM_FRACTION=0.3 \
    $UV run python experiments/023_train_bc.py \
      --demos "$DEMOS/arms/$tag.train.rho100.keyed" --init-from "$init" --schedule constant \
      --eval "base=$DEMOS/test.rho100" "own=$DEMOS/arms/$tag.test.rho100.keyed" --eval-levels 1024 \
      --out "$out" --seed $((7000 + i)) --steps 1000 --lr 3e-5 --warmup 50 \
      --checkpoint-first 100000000 \
      --note "Colour-keyed crossing arm $dirname of bcnv11.s$seed: values $tag, colours pinned to objectives so the arm is asked to reverse a preference rather than relabel one." \
      > /dev/null 2>&1 || echo "BCARM_FAILED s$seed $dirname"
    i=$((i+1))
  done
done

echo "=== thresholds"
for seed in 1 2 3; do
  for spec in "k1:0.5" "k0:1.0"; do
    fam=${spec%%:*}; bv=${spec##*:}
    $UV run python scripts/bc_arm_thresholds.py "$RUNS/bcnv11.s$seed" --family "$fam" --base-value "$bv" \
      --demos "$DEMOS/test.rho100" > "results/g1-bcnv11.s$seed-$fam.txt" 2> "results/g1-bcnv11.s$seed-$fam.err" \
      || echo "BCTHRESH_FAILED s$seed $fam"
  done
done
echo BC_CROSSING_DONE
