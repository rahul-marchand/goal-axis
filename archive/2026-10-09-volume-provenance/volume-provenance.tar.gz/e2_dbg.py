import json, numpy as np, sys
sys.path.insert(0, "/workspace/GoalMisgeneralisation")
from pathlib import Path
import jax
from cleanba.cleanba_impala import load_train_state
from goalmisgen.configs.env import MazeConfig
from goalmisgen.analysis import plan_invariance as pi, fields, targets
from goalmisgen.analysis.probes import fit_ridge
run = Path("/workspace/data/runs/novalue11g1.s1234")
p = json.loads((run/"BASE.json").read_text())
cfg = MazeConfig(max_episode_steps=120, num_envs=64, min_size=11, max_size=11, n_objectives=2, objective_values=(1.0,0.5), feature_value_correlation=1.0, value_encoding="none", colour_is_the_only_value_cue=True, level_dataset="/workspace/data/levels/values/1.00-0.50@500k", dataset_split="valid", asynchronous=False)
policy, _, _, st, _ = load_train_state(run/p["checkpoint"], env_cfg=cfg)
envs = cfg.make()
obs = np.concatenate([np.asarray(envs.reset(seed=s)[0], np.float32) for s in (1, 1001, 2001, 3001)])
h = np.asarray(pi.make_tick_runner(policy, 3)(st.params, obs)[0])
hwc = np.moveaxis(obs, 1, -1)
tgt = targets.DistanceToObjective(targets.fixed(0), name="d0")
X, Y = [], []
for i, o in enumerate(hwc):
    s = type("S", (), {"observation": o, "info": {}})()
    y = tgt.labels(s); r, c = np.nonzero(np.isfinite(y))
    X.append(h[2, 2, i, r, c]); Y.append(y[r, c])
X = np.concatenate(X).astype(np.float64); Y = np.concatenate(Y)
w, mean, std = fit_ridge(X, Y, l2=10.0)
print("std sorted", np.sort(std)[:8], std.max())
print("|w|", np.round(np.abs(w[:-1]), 3))
d = pi.readout_directions(w[:-1], std)
print("dir", np.round(d / np.abs(d).max(), 3))
iso = np.random.default_rng(0).normal(size=(5000, 32))
print("iso share", pi.subspace_share(iso, np.stack([d, d + 1e-3 * np.random.default_rng(1).normal(size=32)])))
dh = h[2, 2] - h[1, 2]
cells = dh.reshape(-1, 32)
print("tick diff share", pi.subspace_share(cells, d[None]))
