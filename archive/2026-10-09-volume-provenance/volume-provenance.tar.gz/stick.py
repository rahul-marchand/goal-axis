"""Does a steering displacement survive the forward pass, or wash out?

Applied before the extra passes, so `steps` measures how much of the shift each
pass keeps. If it holds, a behavioural null means the field is ignored. If it
decays, the perturbation never reached the quantity and the null says nothing.
"""

import operator
import sys
from pathlib import Path

import numpy as np
from cleanba.cleanba_impala import load_train_state

from goalmisgen.analysis import collect_rollouts, fields, steering, targets
from goalmisgen.analysis.probes import Feature, apply_linear, fit_ridge
from goalmisgen.configs.env import MazeConfig

checkpoint, levels = Path(sys.argv[1]), sys.argv[2]


def config(seed, split):
    return MazeConfig(
        max_episode_steps=120, num_envs=32, min_size=11, max_size=11,
        feature_value_correlation=1.0, level_dataset=levels, dataset_split=split,
        asynchronous=False, seed=seed,
    )


policy, _, _, train_state, update = load_train_state(checkpoint, env_cfg=config(0, "valid"))
activations = Feature("activations", operator.attrgetter("features"))
target = targets.DistanceToObjective(targets.fixed(0), name="d->f0", n_features=2)

train = fields.cell_data(
    collect_rollouts(config(0, "valid").make(), policy, train_state.params, 192, seed=0),
    activations, target, drop_degenerate=False,
)
weights, mean, std = fit_ridge(train.x, train.y, l2=fields.choose_l2(train)[0])
direction = steering.from_probe("d->f0", weights, std)
print(f"probe fitted on {len(train.y):,} cells; 1 cell costs norm {direction.unit_norm:.4f}")
print("steps = extra forward passes after the displacement was applied\n")

print(f"{'alpha':>8}{'steps':>8}{'decoded shift':>15}{'fraction kept':>15}")
for steps in (0, 1, 2, 4):
    base = None
    for alpha in (0.0, 6.0, 25.0):
        delta = None if alpha == 0 else direction.scaled(alpha)
        rollouts = collect_rollouts(
            config(9999, "test").make(), policy, train_state.params, 128, seed=9999,
            steer_delta=delta, probe_steps_to_think=steps,
        )
        data = fields.cell_data(rollouts, activations, target, drop_degenerate=False)
        decoded = float(np.mean(apply_linear(data.x, weights, mean, std) - data.y))
        if base is None:
            base = decoded
            continue
        shift = decoded - base
        print(f"{alpha:>8.0f}{steps:>8}{shift:>15.2f}{shift / alpha:>15.2f}")
