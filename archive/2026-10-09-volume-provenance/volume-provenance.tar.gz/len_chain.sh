#!/bin/bash
# Fine-tune-length ladder on one DRC base (appendix: sensitivity to arm length).
#   NAME=novalue11g1.s1234 bash /workspace/len_chain.sh
# 1. the existing 400k o-grid read at its 100k/200k/300k/400k checkpoints
# 2. a 3M o-grid (same offsets, same seeds) with 8 checkpoints, 375k apart
# 3. 014 at every checkpoint of both grids: weight shares, fine-tuned and written thresholds, extrapolation
# 4. colour-keyed k-arms at 3M with 8 checkpoints, thresholds at every checkpoint (the reversal test)
# 5. leave-one-out write error at every checkpoint, last so everything else lands first
# Results: results/len-<base>-<sweep>@<steps>-at<k>.txt (plus -loo variants); logs /workspace/data/logs/len/
set -u
ulimit -n "$(ulimit -Hn)" 2>/dev/null || ulimit -n 65536
export PATH=$HOME/.local/bin:$PATH
export PYTHONUNBUFFERED=1
export JAX_COMPILATION_CACHE_DIR=/workspace/data/jax-cache
cd /workspace/GoalMisgeneralisation
UV=$(command -v uv || echo "$HOME/.local/bin/uv")
DATA=/workspace/data
LEVELS=$DATA/levels/values/1.00-0.50@500k
RUN=$DATA/runs/$NAME
CP=$(python3 -c "import json;print(json.load(open('$RUN/BASE.json'))['checkpoint'])")
mkdir -p "$DATA/logs/len" results
echo "=== $NAME len chain start $(date -u +%F_%T) base $CP"

tag() { case $1 in 400000) echo 400k;; 3000000) echo 3M;; *) echo "$1";; esac; }

# 014 on one sweep at one checkpoint index. Skips a finished table so the chain can be re-run.
m() { local prefix=$1 bv=$2 steps=$3 at=$4 suffix=$5; shift 5
  local out="results/len-$NAME-$prefix@$(tag $steps)-at$at$suffix.txt"
  [ -s "$out" ] && grep -q -E "calibrated|Each written value" "$out" && { echo "have $out"; return; }
  echo "--- $out $(date -u +%H:%M)"
  $UV run python experiments/014_value_axis_analysis.py \
    --base "$RUN/$CP" --arms "$RUN/arms" --levels "$LEVELS" \
    --prefix "$prefix" --base-value "$bv" --arm-steps "$steps" --at "$at" "$@" \
    > "$out.tmp" 2> "${out%.txt}.err" && mv "$out.tmp" "$out" || echo "MEASURE_FAILED $NAME $prefix $steps at$at$suffix"
}
X0="0.5 0.4 0.3 0.2 0.1"
X1="1.0 1.1 1.2 1.3 1.4"

echo "=== 1. the 400k grid at each of its checkpoints"
for at in 0 1 2 3; do
  m o1 0.5 400000 $at "" --extrapolate $X1
  m o0 1.0 400000 $at "" --extrapolate $X0
done

echo "=== 2. the 3M grid, 8 checkpoints per arm $(date -u +%H:%M)"
$UV run python scripts/value_axis_sweep.py --agent "$NAME" --objectives 0 1 \
  --offsets 0.1 0.2 0.3 0.4 --steps 3000000 --checkpoints 8 \
  > "$DATA/logs/len/$NAME.sweep-o.log" 2>&1 || echo "SWEEP_FAILED $NAME o@3M"

echo "=== 3. measures at every checkpoint of the 3M grid $(date -u +%H:%M)"
for at in 0 1 2 3 4 5 6 7; do
  m o1 0.5 3000000 $at "" --extrapolate $X1
  m o0 1.0 3000000 $at "" --extrapolate $X0
done

echo "=== 4. colour-keyed k-arms at 3M $(date -u +%H:%M)"
$UV run python scripts/value_axis_sweep.py --agent "$NAME" --objectives 1 \
  --values 1.0 1.1 1.2 --family k --colour-keyed --allow-reorder --steps 3000000 --checkpoints 8 \
  > "$DATA/logs/len/$NAME.sweep-k1.log" 2>&1 || echo "KSWEEP_FAILED $NAME k1@3M"
$UV run python scripts/value_axis_sweep.py --agent "$NAME" --objectives 0 \
  --values 0.5 0.4 0.3 --family k --colour-keyed --allow-reorder --steps 3000000 --checkpoints 8 \
  > "$DATA/logs/len/$NAME.sweep-k0.log" 2>&1 || echo "KSWEEP_FAILED $NAME k0@3M"
for at in 0 1 2 3 4 5 6 7; do
  for spec in "k1:0.5" "k0:1.0"; do
    fam=${spec%%:*}; bv=${spec##*:}
    out="results/len-$NAME-$fam@3M-at$at.txt"
    [ -s "$out" ] && { echo "have $out"; continue; }
    $UV run python scripts/arm_thresholds.py "$RUN" --family "$fam" --base-value "$bv" \
      --levels "$LEVELS" --arm-steps 3000000 --at $at \
      > "$out.tmp" 2> "${out%.txt}.err" && mv "$out.tmp" "$out" || echo "KTHRESH_FAILED $NAME $fam at$at"
  done
done

echo "=== 5. leave-one-out write error at every checkpoint $(date -u +%H:%M)"
for at in 0 1 2 3; do
  m o1 0.5 400000 $at -loo --leave-one-out
  m o0 1.0 400000 $at -loo --leave-one-out
done
for at in 0 1 2 3 4 5 6 7; do
  m o1 0.5 3000000 $at -loo --leave-one-out
  m o0 1.0 3000000 $at -loo --leave-one-out
done
echo "LEN_CHAIN_DONE $NAME $(date -u +%F_%T)"
