#!/bin/bash
set -u
export PATH=/root/.local/bin:$PATH
export JAX_COMPILATION_CACHE_DIR=/workspace/data/jax-cache
cd /workspace/GoalMisgeneralisation
until grep -q "BASE_CHAIN_DONE vit11nvg1.s5678" /workspace/data/logs/g1/vit11nvg1.s5678.log 2>/dev/null; do sleep 120; done
RUN=/workspace/data/runs/vit11nvg1.s1234
CP=$(python3 -c "import json;print(json.load(open(\"$RUN/BASE.json\"))[\"checkpoint\"])")
/root/.local/bin/uv run python experiments/014_value_axis_analysis.py \
  --base "$RUN/$CP" --arms "$RUN/arms" --levels /workspace/data/levels/values/1.00-0.50@500k \
  --prefix o1 --base-value 0.5 --arm-steps 400000 --at -1 --extrapolate 1.0 1.1 1.2 1.3 1.4 \
  > results/g1-vit11nvg1.s1234-o1.remeasure.txt 2> results/g1-vit11nvg1.s1234-o1.remeasure.err
echo REMEASURE_DONE
