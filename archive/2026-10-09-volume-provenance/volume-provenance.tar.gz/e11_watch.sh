#!/bin/bash
# Keep results/gain-vs-factorised/E11.md current until the chain finishes, then once more.
set -uo pipefail
SNAP=/workspace/gvf-e11-snap
PY=/workspace/GoalMisgeneralisation/.venv/bin/python
JSON=/workspace/data/figures-data/gain-vs-factorised
OUT=/workspace/GoalMisgeneralisation/results/gain-vs-factorised
LOG=/workspace/data/logs/gvf/e11.report.log
cd $SNAP
for i in $(seq 1 60); do
  $PY scripts/e11_report.py --json-dir $JSON --results $OUT >> $LOG 2>&1
  $PY scripts/e11_summary.py $JSON --models d128l4 d256l4 d512l4 d512l16 > $OUT/e11-summary.txt 2>> $LOG
  grep -q E11_CHAIN_DONE /workspace/data/logs/gvf/e11.log && break
  sleep 300
done
$PY scripts/e11_report.py --json-dir $JSON --results $OUT >> $LOG 2>&1
$PY scripts/e11_summary.py $JSON --models d128l4 d256l4 d512l4 d512l16 > $OUT/e11-summary.txt 2>> $LOG
echo "E11_REPORT_DONE $(date -u +%H:%M)" >> $LOG
