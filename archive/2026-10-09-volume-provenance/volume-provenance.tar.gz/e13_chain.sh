#!/bin/bash
# E13: where in the sequence does the route model's value axis act?
#   nohup bash /workspace/e13_chain.sh > /dev/null 2>&1 &
set -uo pipefail
ulimit -n $(ulimit -Hn)
export PYTHONUNBUFFERED=1 XLA_PYTHON_CLIENT_PREALLOCATE=false JAX_COMPILATION_CACHE_DIR=/workspace/data/jax-cache
SNAP=/workspace/gvf-e13-snap
[ -f "$SNAP/scripts/e13_position_patch.py" ] || SNAP=/workspace/GoalMisgeneralisation
cd $SNAP
PY=/workspace/GoalMisgeneralisation/.venv/bin/python
DATA=/workspace/data
DEMOS=$DATA/offline/demos
OUT=$DATA/figures-data/gain-vs-factorised/e13
RES=/workspace/GoalMisgeneralisation/results/gain-vs-factorised
LOG=$DATA/logs/gvf
mkdir -p $OUT $RES $LOG
L=$LOG/e13.log
say() { echo "[$(date -u +%H:%M:%S)] $*" >> $L; }
say "=== E13 start, snapshot $SNAP"

run() {  # run <tag> <rundir> <levels> [extra...]
  local tag=$1 rundir=$2 levels=$3; shift 3
  say "$tag start"
  timeout 9000 $PY scripts/e13_position_patch.py "$rundir" --demos $DEMOS --levels "$levels" \
    --json $OUT/$tag.json "$@" > $RES/e13-$tag.txt 2> $LOG/e13-$tag.err \
    && say "$tag ok" || say "$tag FAILED"
}

# Smoke test: tiny, one depth, one dose. If this fails nothing else will work.
run smoke /workspace/data/offline/runs/scaling/sc11.d512l4.s1 64 --depths 0 1 --doses 0.3 --chunk 64
say "SMOKE_DONE"

# Stage 1: the decisive one, on the model with veridical distances.
run d512l4 /workspace/data/offline/runs/scaling/sc11.d512l4.s1 2048 --chunk 128
say "E13_S1_D512_DONE"

# Stage 4: the small model, to say whether the two differ in WHERE value lives.
run bcnv11.s1 /workspace/data/offline/runs/bcnv11.s1 2048
say "E13_S1_BCNV_DONE"

# Cross-check: a second small-model seed, cheap.
run bcnv11.s2 /workspace/data/offline/runs/bcnv11.s2 2048
say "E13_S1_BCNV2_DONE"

$PY - <<'PYEOF' >> $L 2>&1
import json, pathlib
out = pathlib.Path("/workspace/data/figures-data/gain-vs-factorised/e13")
res = pathlib.Path("/workspace/GoalMisgeneralisation/results/gain-vs-factorised/E13.md")
lines = ["# E13: where in the sequence does the route model's value axis act?", "",
         "Position-masked patching: the fitted axis's own residual-stream change, replayed into",
         "the unedited model at one subset of tokens at a time. `share` is the fraction of the",
         "weight write's threshold shift that subset carries. **Read the `all` row first** -- if it",
         "is not near 1.00 the write is not reproducible by patching at that depth and the other",
         "rows mean nothing.", ""]
for name in ["d512l4", "bcnv11.s1", "bcnv11.s2"]:
    path = out / f"{name}.json"
    if not path.exists():
        lines += [f"## {name}", "", "Did not produce output; see the .err file.", ""]
        continue
    d = json.loads(path.read_text())
    lines += [f"## {name}", "", f"Levels {d['levels']}, |v| {d['axis_norm']:.3f} per unit value.", "",
              "| condition | dose | depth | tau | reached | route | share |", "|---|---|---|---|---|---|---|"]
    for r in d["rows"]:
        dose = f"{r['dose']:+.2f}" if "dose" in r else "-"
        depth = r.get("depth", "-")
        share = f"{r['share']:.2f}" if isinstance(r.get("share"), float) else "-"
        lines.append(f"| {r['condition']} | {dose} | {depth} | {r['tau']:.2f} | "
                     f"{r['reached']:.1%} | {r['on_route']:.1%} | {share} |")
    lines.append("")
lines += ["## How to read it", "",
          "- `objectives` carrying the shift: value is written into the objective's own",
          "  representation, before any comparison.",
          "- `sep` carrying it: value is applied at the decision token -- the factorised story.",
          "- `other cells` carrying it: value is spread over the maze representation.",
          "- Competence columns matter: a subset that moves tau by breaking the model",
          "  (reached far below the base's) is not a value knob.", "",
          "Caveat: three earlier steering attempts on this model were null because the linearly",
          "decodable gap direction is not load-bearing. This patches the axis's own activation",
          "difference instead, which is why the `all` control is the first thing to check.", ""]
res.write_text("\n".join(lines))
print("wrote", res)
PYEOF
say "E13_CHAIN_DONE"
