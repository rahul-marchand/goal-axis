#!/usr/bin/env bash
set -uo pipefail
export PYTHONPATH=/workspace/gm-plan PYTHONUNBUFFERED=1 XLA_PYTHON_CLIENT_PREALLOCATE=false
export XLA_PYTHON_CLIENT_MEM_FRACTION=0.25
PY=/workspace/GoalMisgeneralisation/.venv/bin/python
OUT=/workspace/data/offline/results
D=/workspace/data/offline/demos
R=/workspace/data/offline/runs
cd /workspace/gm-plan

# The maze-token read: the distance as a field, with 005 controls.
echo "=== cells read $(date -u +%H:%M:%S) ==="
$PY experiments/031_bc_outcome_keyed_distance.py $R/bcnv11.s1 --demos $D/test.rho100 \
    --sites cells --train-episodes 256 --test-episodes 512 \
    --json $OUT/offline-bc-distance-cells.bcnv11.s1.json \
    > $OUT/offline-bc-distance-cells.bcnv11.s1.txt 2>&1
echo "exit $? at $(date -u +%H:%M:%S)"

# The plan write on the same model, as the field-versus-summary contrast.
echo "=== plan write $(date -u +%H:%M:%S) ==="
$PY experiments/030_bc_rewrite_the_plan.py $R/bcnv11.s1 --demos $D/test.rho100 --patch \
    --json $OUT/offline-bc-rewrite.bcnv11.s1.json \
    > $OUT/offline-bc-rewrite.bcnv11.s1.txt 2>&1
echo "exit $? at $(date -u +%H:%M:%S)"
echo CELLSDONE
