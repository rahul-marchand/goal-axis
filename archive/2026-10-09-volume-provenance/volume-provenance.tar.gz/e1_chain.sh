#!/bin/bash
# E1 gain-alignment chain. Usage: e1_chain.sh BASE [BASE...]   (runs them in sequence)
export XLA_PYTHON_CLIENT_PREALLOCATE=false
ulimit -n $(ulimit -Hn)
cd /workspace/GoalMisgeneralisation
LOG=/workspace/data/logs/gvf; mkdir -p $LOG results/gain-vs-factorised /workspace/data/figures-data/gain_alignment
LV=/workspace/data/levels/values/1.00-0.50@500k
for b in "$@"; do
  uv run --no-sync python scripts/gain_alignment.py /workspace/data/runs/$b --levels $LV \
    --json /workspace/data/figures-data/gain_alignment/$b.json \
    > results/gain-vs-factorised/gain-alignment-$b.txt 2> $LOG/e1-$b.err
  echo "$(date -u) $b exit $?" >> $LOG/e1.log
done
echo "E1_DONE $*" >> $LOG/e1.log
