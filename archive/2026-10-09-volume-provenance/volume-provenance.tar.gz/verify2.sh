set -euo pipefail
export PATH=$HOME/.local/bin:$PATH
cd /workspace/GoalMisgeneralisation
git fetch -q origin && git checkout -q probe-distance-field && git pull -q
LOG=/workspace/data/verify2.txt
: > "$LOG"
echo "commit $(git rev-parse --short HEAD)" | tee -a "$LOG"
echo "=== fast suite ===" | tee -a "$LOG"
uv run pytest -q -m "not slow" 2>&1 | tail -3 | tee -a "$LOG"
echo "=== 003 must still give 0.967 / 0.523 / 0.583 ===" | tee -a "$LOG"
uv run python experiments/003_probe_plan.py \
    /workspace/data/runs/maze11/local-files/cp_140206080 \
    --levels /workspace/data/levels11 --split test 2>&1 \
    | grep -viE "userwarning|logger\.warn|gym\.logger|^\s*$" | tee -a "$LOG"
echo "VERIFY2DONE" | tee -a "$LOG"
