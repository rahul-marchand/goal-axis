#!/usr/bin/env bash
set -uo pipefail
cd /workspace/GoalMisgeneralisation
export PATH="$HOME/.local/bin:$PATH"
export JAX_COMPILATION_CACHE_DIR=/workspace/data/jax-cache
LOG=/workspace/data/logs/restrict/chain3.log
for s in 2 3; do
  base=bcnv11.s$s
  echo "=== $base $(date -u +%H:%M) ===" >> $LOG
  uv run python scripts/restricted_writes_bc.py /workspace/data/offline/runs/$base --demos /workspace/data/offline/demos/test.rho100 \
      --json figures/data/restricted/$base.o1.json > results/restrict-$base.o1.txt 2> /workspace/data/logs/restrict/$base.err \
      && echo "$base ok" >> $LOG || echo "$base FAILED" >> $LOG
done
cp figures/data/restricted/*.json /workspace/data/figures-data/restricted/ 2>/dev/null
echo RESTRICT3_DONE >> $LOG
