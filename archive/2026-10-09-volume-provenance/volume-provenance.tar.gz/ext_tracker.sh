#!/bin/bash
# Decode every new extension checkpoint; log the argmax trajectory.
set -u
export PATH=$HOME/.local/bin:$PATH
export JAX_COMPILATION_CACHE_DIR=/workspace/data/jax-cache
cd /workspace/GoalMisgeneralisation
SEEN=/tmp/ext_seen; touch $SEEN
while true; do
  for run in novalue11g1.s5678e novalue11g1.s3456e vit11nvg1.s1234e vit11nvg1.s5678e; do
    dir=/workspace/data/runs/$run/local-files
    [ -d "$dir" ] || continue
    for cp in $(ls "$dir" 2>/dev/null); do
      grep -q "$run/$cp" $SEEN && continue
      echo "$run/$cp" >> $SEEN
      out=$($HOME/.local/bin/uv run python scripts/decode_h1_drc.py "$dir/$cp" \
        --levels /workspace/data/levels/values/1.00-0.50@500k --split test \
        --episodes 512 --num-envs 128 --out /tmp/track.npz 2>/dev/null | grep -oE "reached [0-9.]+%")
      echo "TRACK $run $cp $out"
    done
  done
  sleep 300
done
