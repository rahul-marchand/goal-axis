#!/bin/bash
# Weight-space ladder (Table 1 at every checkpoint) for one base, CPU only, beside the GPU chain.
#   NAME=novalue11g1.s1234 bash /workspace/len_weights.sh
set -u
export PATH=$HOME/.local/bin:$PATH PYTHONUNBUFFERED=1 JAX_PLATFORMS=cpu
cd /workspace/GoalMisgeneralisation
UV=$(command -v uv || echo "$HOME/.local/bin/uv")
LOG=/workspace/data/logs/len/$NAME.sweep-o.log
until [ -f "$LOG" ] && grep -q SWEEP_COMPLETE "$LOG"; do sleep 300; done
echo "=== $NAME weights ladder $(date -u +%F_%T)"
$UV run python scripts/arm_length_ladder.py "/workspace/data/runs/$NAME" --arm-steps 400000 3000000 \
  --out "results/len-$NAME-weights.json" > "results/len-$NAME-weights.txt.tmp" 2> "results/len-$NAME-weights.err" \
  && mv "results/len-$NAME-weights.txt.tmp" "results/len-$NAME-weights.txt" || echo "WEIGHTS_FAILED $NAME"
echo "LEN_WEIGHTS_DONE $NAME $(date -u +%F_%T)"
