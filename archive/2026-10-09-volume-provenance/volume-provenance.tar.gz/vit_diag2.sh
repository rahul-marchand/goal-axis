#!/bin/bash
set -u
export PATH=/root/.local/bin:$PATH
export JAX_COMPILATION_CACHE_DIR=/workspace/data/jax-cache
cd /workspace/GoalMisgeneralisation
until grep -q "CROSSCHECK_DONE" /workspace/crosscheck.log 2>/dev/null; do sleep 60; done
/root/.local/bin/uv run python scripts/decode_h1_drc.py /workspace/data/runs/vit11nvg1.s1234 \
  --levels /workspace/data/levels/values/1.00-0.50@1M --split valid --episodes 2048 --num-envs 128 \
  --out /tmp/vit1234_valid.npz > /tmp/vit1234_valid.log 2>&1
/root/.local/bin/uv run python scripts/decode_h1_drc.py /workspace/data/runs/vit11nvg1.s1234 \
  --levels /workspace/data/levels/values/1.00-0.50@500k --split test --episodes 2048 --num-envs 128 \
  --out /tmp/vit1234_500k.npz > /tmp/vit1234_500k.log 2>&1
echo VITDIAG_DONE
