#!/bin/bash
# E16: the field decomposition on the two feedforward architectures.
set -uo pipefail
ulimit -n $(ulimit -Hn) 2>/dev/null
export PYTHONUNBUFFERED=1 XLA_PYTHON_CLIENT_PREALLOCATE=false JAX_COMPILATION_CACHE_DIR=/workspace/data/jax-cache
SNAP=/workspace/gvf-e16-snap
cd $SNAP
PY=/workspace/GoalMisgeneralisation/.venv/bin/python
DATA=/workspace/data
LV=$DATA/levels/values/1.00-0.50@500k
OUT=/workspace/GoalMisgeneralisation/results/gain-vs-factorised
LOG=$DATA/logs/gvf
JS=$DATA/figures-data/gain-vs-factorised/e16
mkdir -p "$OUT" "$LOG" "$JS"
L=$LOG/e16.log
say() { echo "[$(date -u +%H:%M:%S)] $*" >> $L; }

run() {  # tag rundir threshold gain levels
  local tag=$1 rundir=$2 thr=$3 gain=$4 levels=$5
  say "$tag start"
  timeout 7200 $PY scripts/feedforward_field_decomp.py "$rundir" --levels $LV --n-levels "$levels" \
    --batch 128 --threshold "$thr" --gain "$gain" --json "$JS/$tag.json" \
    > "$OUT/e16-$tag.txt" 2> "$LOG/e16-$tag.err" \
    && say "$tag ok" || say "$tag FAILED"
  cp "$OUT/e16-$tag.txt" "$DATA/figures-data/gain-vs-factorised/" 2>/dev/null
  say "E16_STAGE_DONE $tag"
  $PY /workspace/e16_report.py >> "$LOG/e16.report.log" 2>&1
}

say "=== E16 start, snapshot $SNAP"
run resnet11nvg1.s1234 $DATA/runs/resnet11nvg1.s1234 7.48 0.65 256
run vit11nvg1.s9012    $DATA/runs/vit11nvg1.s9012    5.24 0.70 256
say "E16_CHAIN_DONE"
