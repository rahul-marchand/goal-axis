#!/bin/bash
# Re-measure the route model's axis, extrapolated on the crossing side at the
# same offsets the RL panels carry, so the four panels are read off one grid.
set -u
export PATH=$HOME/.local/bin:$PATH
export PYTHONUNBUFFERED=1
export JAX_COMPILATION_CACHE_DIR=/workspace/data/jax-cache
cd /workspace/GoalMisgeneralisation
UV=$HOME/.local/bin/uv
DATA=/workspace/data
RUNS=$DATA/offline/runs
OUT=$DATA/offline/results

# The k arms train first; both want the GPU.
while ! grep -q BC_CROSSING_DONE $DATA/logs/g1/bc-crossing.log 2>/dev/null; do sleep 120; done

for seed in 1 2 3; do
  for objective in 0 1; do
    # Crossing side only: lowering colour 0 (o0) or raising colour 1 (o1).
    if [ "$objective" = "0" ]; then offs="-0.5 -0.6 -0.7"; else offs="0.5 0.6 0.7"; fi
    XLA_PYTHON_CLIENT_MEM_FRACTION=0.5 $UV run python experiments/027_bc_value_axis.py \
      "$RUNS/bcnv11.s$seed" --sweep "o$objective" --steps 1000 \
      --demos "$DATA/offline/demos/test.rho100" --extrapolate $offs \
      --json "$OUT/value_axis.bcnv11.s$seed.o$objective.json" \
      > "$OUT/value_axis.bcnv11.s$seed.o$objective.txt" 2> "$OUT/value_axis.bcnv11.s$seed.o$objective.err" \
      || echo "027_FAILED s$seed o$objective"
  done
done
echo BC_WRITTEN_DONE
