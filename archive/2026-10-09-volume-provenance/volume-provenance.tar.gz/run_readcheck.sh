#!/usr/bin/env bash
set -uo pipefail
export PYTHONPATH=/workspace/gm-plan PYTHONUNBUFFERED=1 XLA_PYTHON_CLIENT_PREALLOCATE=false
export XLA_PYTHON_CLIENT_MEM_FRACTION=0.15
PY=/workspace/GoalMisgeneralisation/.venv/bin/python
OUT=/workspace/data/offline/results
D=/workspace/data/offline/demos
R=/workspace/data/offline/runs
cd /workspace/gm-plan
for spec in "bc11.rho050.s1 test.rho050" "bcnv11.s1 test.rho100"; do
  set -- $spec
  echo "=== read control $1 $(date -u +%H:%M:%S) ==="
  $PY experiments/025_bc_probe_plan.py $R/$1 --demos $D/$2 --untaken --by-distance \
      > $OUT/offline-bc-probe-untaken.$1.txt 2>&1
  echo "exit $? at $(date -u +%H:%M:%S)"
done
echo READDONE
