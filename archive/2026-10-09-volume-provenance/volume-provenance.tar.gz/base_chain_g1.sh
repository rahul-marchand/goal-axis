#!/bin/bash
# One gamma=1.0 base agent, end to end: train, healthy-checkpoint BASE.json,
# the full 0.1-1.4 arm grid (o-family fit window + x-family extensions),
# measures with written-extrapolation. Campaign tag: g1.
#   NET=drc33 SEED=1234 STEPS=150000000 NAME=novalue11g1.s1234 bash base_chain_g1.sh
set -uo pipefail
export PATH="$HOME/.local/bin:$PATH"
export PYTHONUNBUFFERED=1
export JAX_COMPILATION_CACHE_DIR=/workspace/data/jax-cache
[ -n "${MEMFRAC:-}" ] && export XLA_PYTHON_CLIENT_MEM_FRACTION=$MEMFRAC
cd /workspace/GoalMisgeneralisation
UV="$HOME/.local/bin/uv"
DATA=/workspace/data
LEVELS_TRAIN=$DATA/levels/values/1.00-0.50@1M
LEVELS_MEASURE=$DATA/levels/values/1.00-0.50@500k
RUN=$DATA/runs/$NAME
mkdir -p "$DATA/logs/g1"
grep -qx "$NAME" /workspace/data/g1_blocklist 2>/dev/null && { echo "BLOCKED $NAME"; exit 0; }

echo "=== $NAME: train (net=$NET seed=$SEED gamma=1.0 steps=$STEPS)"
if [ ! -f "$RUN/BASE.json" ]; then
  $UV run python experiments/001_maze_repro.py --net "$NET" --correlation 1.0 \
    --min-size 11 --max-size 11 --levels "$LEVELS_TRAIN" --hide-values --gamma 1.0 \
    --total-timesteps "$STEPS" --seed "$SEED" --run-dir "$RUN" \
    --note "g1 campaign: undiscounted base ($NET, seed $SEED) for the clean-task core figure, 2026-08-29." \
    || { echo "TRAIN_FAILED $NAME"; exit 1; }

  $UV run python - "$RUN" <<'PY' || { echo "BASEPICK_FAILED $NAME"; exit 1; }
import json, sys
from pathlib import Path
import pandas as pd
from goalmisgen.volume import parse_checkpoint_dirname

run = Path(sys.argv[1])
frame = pd.read_csv(run / "metrics.csv", index_col=0)
col = next(c for c in frame.columns if c.endswith("returned_avg_episode_success"))
success = frame[col].dropna()
step_col = next((c for c in ("global_step", "_step") if c in frame.columns), None)
steps = frame.loc[success.index, step_col] if step_col else success.index
cps = sorted((parse_checkpoint_dirname(p.name), p.name) for p in (run / "local-files").glob("cp_*"))
healthy = None
for cp_step, name in cps:
    window = success[(steps >= cp_step - 8e6) & (steps <= cp_step + 2e6)]
    if len(window) == 0 or window.min() >= float(__import__("os").environ.get("PICK_BAR", "0.95")):
        healthy = (cp_step, name)
final = cps[-1]
chosen = healthy or final
if chosen != final:
    print(f"late collapse detected: using {chosen[1]} not {final[1]}")
payload = {"checkpoint": f"local-files/{chosen[1]}", "values": [1.0, 0.5],
           "objectives": 2, "steps": chosen[0], "picked": "healthy" if chosen != final else "final"}
(run / "BASE.json").write_text(json.dumps(payload, indent=1))
print("BASE.json ->", payload["checkpoint"])
PY
fi

echo "=== $NAME: arms (o-family fit window, both sweeps)"
$UV run python scripts/value_axis_sweep.py --agent "$NAME" --objectives 0 1 \
  --offsets 0.1 0.2 0.3 0.4 --steps 400000 || echo "SWEEP_FAILED $NAME o"
echo "=== $NAME: arms (x-family extensions, 0.1-1.4 grid completion)"
$UV run python scripts/value_axis_sweep.py --agent "$NAME" --objectives 0 \
  --values 0.5 0.4 0.3 0.2 0.1 --steps 400000 --allow-reorder || echo "SWEEP_FAILED $NAME x0"
$UV run python scripts/value_axis_sweep.py --agent "$NAME" --objectives 1 \
  --values 1.0 1.1 1.2 1.3 1.4 --steps 400000 --allow-reorder || echo "SWEEP_FAILED $NAME x1"

echo "=== $NAME: measures"
CP=$(python3 -c "import json;print(json.load(open('$RUN/BASE.json'))['checkpoint'])")
m() { local prefix=$1 bv=$2; shift 2
  $UV run python experiments/014_value_axis_analysis.py \
    --base "$RUN/$CP" --arms "$RUN/arms" --levels "$LEVELS_MEASURE" \
    --prefix "$prefix" --base-value "$bv" --arm-steps 400000 --at -1 "$@" \
    > "results/g1-$NAME-$prefix.txt" 2> "results/g1-$NAME-$prefix.err" || echo "MEASURE_FAILED $NAME $prefix"
}
m o0 1.0 --extrapolate 0.5 0.4 0.3 0.2 0.1
m o1 0.5 --extrapolate 1.0 1.1 1.2 1.3 1.4
m x0 1.0
m x1 0.5
echo "BASE_CHAIN_DONE $NAME"
