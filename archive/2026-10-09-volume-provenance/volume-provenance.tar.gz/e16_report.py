"""Assemble E16.md from whatever stages have finished, so it is always current."""
from pathlib import Path

OUT = Path("/workspace/GoalMisgeneralisation/results/gain-vs-factorised")
PREAMBLE = """# E16: what the ResNet and the ViT propagate, and where value enters

The feedforward counterpart of E12 (DRC) and E15 (route models), run with
`scripts/feedforward_field_decomp.py` from the frozen snapshot
`/workspace/gvf-e16-snap`. Code: `goalmisgen/analysis/feedforward_fields.py`,
`tests/test_feedforward_fields.py` (8 pass).

**Depth is not time.** These networks have no carry, so one forward pass is the
whole measurement and a layer -- a ResNet stage, a transformer block -- stands
where the DRC's tick stood. A field that reaches further at stage 5 than stage 1
was carried there by five convolutions, which is a different claim from a
recurrence carrying it further on the next tick. Read the layer column as depth,
not as time.

**What is measured.** Four observation variants on the same inputs -- both
objectives, only the richer, only the poorer, neither -- then per maze cell and
per layer `A_c = h(only c) - h(neither)`, `D = h(both) - h(neither)`, and the
interaction `I = D - A_rich - A_poor`. Sizes are L2 norms across channels; there
is no probing and no fitted direction anywhere.

**The source-change control.** `gain` scales colour 1's observation plane, so it
is a source change by construction and calibrates *where* such a change lands.
It does not calibrate how big a threshold move that is: on the ResNet
brightening barely moves the threshold, and on the ViT it moves it the wrong
way (`results/input-gain-*.txt`). The axis rows are the measurement; the gain
rows are the yardstick for the columns.

**Reference points.** DRC (E12): gamma ~0.63, value landing like a source
change, half-distance 3-4 -> 6-11 cells over ticks, bridge -0.66 crossing 8.53
against a threshold of 7.06. Route model d512l4 (E15): gamma 0.64, decay R^2
0.995, bridge -0.757 crossing 10.92 against 10.72. Route model bcnv11 (E15): no
propagation at all, half-distance 1 cell at every block.

**Caveats.** One base per architecture, and the ViT rests on n=1 -- s9012 is the
only ViT base with a fitted axis. 256 levels. The "neither" baseline is off
distribution, and the first table in each section bounds how far.

"""


def main() -> None:
    parts = [PREAMBLE]
    for tag, title in (("resnet11nvg1.s1234", "ResNet s1234"), ("vit11nvg1.s9012", "ViT s9012")):
        path = OUT / f"e16-{tag}.txt"
        parts.append(f"\n## {title}\n")
        if not path.exists() or not path.read_text().strip():
            parts.append("\nNot finished; see the .err file.\n")
            continue
        parts.append("\n```\n" + path.read_text().strip() + "\n```\n")
    (OUT / "E16.md").write_text("".join(parts))
    print(f"wrote {OUT / 'E16.md'}")


if __name__ == "__main__":
    main()
