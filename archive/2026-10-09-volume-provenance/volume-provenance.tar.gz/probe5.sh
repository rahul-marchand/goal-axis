set -euo pipefail
export PATH=$HOME/.local/bin:$PATH
cd /workspace/GoalMisgeneralisation
git pull --ff-only -q
LOG=/workspace/data/probe-smoke5b.txt
: > "$LOG"
echo "### smoke5b - 5x5 colour-follower, live-sampled levels" | tee -a "$LOG"
uv run python experiments/003_probe_plan.py \
    /workspace/data/runs/smoke5b/local-files/cp_9011200 \
    --size 5 --by-distance --think 0 2>&1 \
    | grep -viE "userwarning|logger\.warn|gym\.logger|^\s*$" | tee -a "$LOG"
echo "DONE" | tee -a "$LOG"
