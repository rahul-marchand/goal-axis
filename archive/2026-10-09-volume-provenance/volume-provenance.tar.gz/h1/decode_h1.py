import sys, time, json
import numpy as np
from goalmisgen.offline.demos import DemoSet
from goalmisgen.offline.train import list_checkpoints, load_checkpoint
from goalmisgen.offline.decode import evaluate

run = sys.argv[1]; n = int(sys.argv[2]); out = sys.argv[3]
demos = DemoSet.load('/workspace/data/offline/demos/test.rho100', hide_values=True)
model, params = load_checkpoint(list_checkpoints(run)[-1][1])
idx = np.arange(min(n, len(demos)))
t0 = time.perf_counter()
summary, decoded, outcomes = evaluate(model, params, demos, idx)
print(f'decoded {len(idx):,} in {time.perf_counter()-t0:.1f}s')
print(summary)

vals = np.asarray(demos.values)[idx]; dist = np.asarray(demos.distances)[idx].astype(int)
fid  = np.asarray(demos.feature_ids)[idx].astype(int)
rich = np.argmax(vals, axis=1); rows = np.arange(len(idx))
rec = dict(
    d_rich=dist[rows, rich], d_poor=dist[rows, 1-rich],
    colour_of_rich=fid[rows, rich],
    reached=np.array([bool(o.get('reached_objective')) for o in outcomes]),
    reached_fid=np.array([-1 if o.get('reached_feature_id') is None else int(o['reached_feature_id']) for o in outcomes]),
)
np.savez(out, **rec)
print('saved', out)
