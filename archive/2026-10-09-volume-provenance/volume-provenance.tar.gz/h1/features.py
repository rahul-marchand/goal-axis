'''Geometry of each held-out level, to ask what the choice depends on beyond distance.'''
import numpy as np
from goalmisgen.offline.demos import DemoSet

d = DemoSet.load('/workspace/data/offline/demos/test.rho100', hide_values=True)
n = len(d)
vals = np.asarray(d.values); dist = np.asarray(d.distances).astype(int)
pos = np.asarray(d.positions).astype(int)      # (n, n_obj, 2)
ag  = np.asarray(d.agent).astype(int)          # (n, 2)
rich = np.argmax(vals, axis=1); rows = np.arange(n)
pr = pos[rows, rich]; pp = pos[rows, 1-rich]

def man(a,b): return np.abs(a-b).sum(1).astype(float)
def l2(a,b):  return np.sqrt(((a-b)**2).sum(1)).astype(float)

man_r, man_p = man(ag,pr), man(ag,pp)
l2_r,  l2_p  = l2(ag,pr),  l2(ag,pp)
d_r, d_p = dist[rows,rich].astype(float), dist[rows,1-rich].astype(float)

# angle between the two objectives as seen from the agent
vr = (pr-ag).astype(float); vp = (pp-ag).astype(float)
nr = np.linalg.norm(vr,axis=1); npp = np.linalg.norm(vp,axis=1)
cosang = (vr*vp).sum(1)/np.maximum(nr*npp,1e-9)

np.savez('/workspace/h1/features.npz',
    man_rich=man_r, man_poor=man_p, l2_rich=l2_r, l2_poor=l2_p,
    detour_rich=d_r/np.maximum(man_r,1), detour_poor=d_p/np.maximum(man_p,1),
    cosang=cosang,
    agent_row=ag[:,0], agent_col=ag[:,1],
    edge_rich=np.minimum.reduce([pr[:,0],pr[:,1],10-pr[:,0],10-pr[:,1]]).astype(float),
    edge_poor=np.minimum.reduce([pp[:,0],pp[:,1],10-pp[:,0],10-pp[:,1]]).astype(float),
)
print('saved', n)
