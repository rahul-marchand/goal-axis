set -u
cd /workspace/GoalMisgeneralisation
export CUDA_VISIBLE_DEVICES=$1; shift
export XLA_PYTHON_CLIENT_MEM_FRACTION=0.85
PY=/workspace/GoalMisgeneralisation/.venv/bin/python
for a in "$@"; do
  out=/workspace/h1/arms/o0${a}.npz
  [ -f "$out" ] && { echo "have $a"; continue; }
  echo "$(date -u +%H:%M:%S) start $a"
  $PY scripts/decode_h1.py /workspace/data/offline/runs/bcnv11.s1/arms/o0${a}@1k 50000 $out 2>&1 | tail -1
done
echo WORKER_DONE
