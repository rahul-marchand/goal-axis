import sys
import numpy as np
from goalmisgen.analysis.behaviour import fit_logistic

z = np.load(sys.argv[1])
d_r, d_p = z['d_rich'].astype(int), z['d_poor'].astype(int)
reached, rfid, crich = z['reached'], z['reached_fid'].astype(int), z['colour_of_rich'].astype(int)
gap, dsum = d_r - d_p, d_r + d_p
took = (rfid == crich)

print(f'levels {len(gap):,}   reached {reached.mean():.1%}   took richer (of reached) {took[reached].mean():.1%}')
print()
print('=== failure rate by gap (the selection filter) ===')
for lo, hi in ((-99,-5),(-4,3),(4,8),(9,12),(13,16),(17,99)):
    m = (gap>=lo)&(gap<=hi)
    if m.sum(): print(f'  gap {lo:>4}..{hi:<4} n={m.sum():>6}  failed {1-reached[m].mean():.2%}')

m = reached
g, s, y = gap[m], dsum[m], took[m].astype(float)

def groups(keys):
    _, inv = np.unique(keys, axis=0, return_inverse=True)
    return inv

def cv_logloss(inv, y, seed=0):
    rng = np.random.default_rng(seed); half = rng.random(len(y)) < 0.5
    n = inv.max()+1; err = []; acc = []
    for tr, te in ((half, ~half), (~half, half)):
        num = np.bincount(inv[tr], weights=y[tr], minlength=n)
        den = np.bincount(inv[tr], minlength=n)
        prior = y[tr].mean()
        p = np.where(den>0, (num+2*prior)/(den+2), prior)          # smoothed
        pe = np.clip(p[inv[te]], 1e-6, 1-1e-6)
        err.append(-(y[te]*np.log(pe)+(1-y[te])*np.log(1-pe)).mean())
        acc.append(((pe>0.5)==(y[te]>0.5)).mean())
    return float(np.mean(err)), float(np.mean(acc)), n

print()
print('=== nested models, held-out (2-fold, smoothed cell means) ===')
print(f"  {'model':<34}{'groups':>8}{'logloss':>10}{'acc':>8}")
for name, keys in ((' M0  constant', np.zeros((len(g),1),int)),
                   (' M1  f(gap)', g[:,None]),
                   (' M2  f(d_rich, d_poor)', np.stack([g,s],1))):
    ll, ac, n = cv_logloss(groups(keys), y)
    print(f'  {name:<34}{n:>8}{ll:>10.4f}{ac:>8.3f}')

print()
print('=== H2 directly: does d_sum matter at fixed gap? ===')
X1 = g[:,None].astype(float); X2 = np.stack([g,s],1).astype(float)
w1,_,_ = fit_logistic(X1, y, steps=6000, lr=0.5, l2=1e-6)
w2,mu,sd = fit_logistic(X2, y, steps=6000, lr=0.5, l2=1e-6)
print(f'  logistic(took ~ gap)          coef_gap {w1[0]:+.4f} (standardised)')
print(f'  logistic(took ~ gap + d_sum)  coef_gap {w2[0]:+.4f}   coef_dsum {w2[1]:+.4f} (standardised)')
print(f'    -> per +10 steps of d_sum at fixed gap: {w2[1]/sd[1]*10:+.4f} in log-odds')

print()
print('=== within-cell purity (H1), cells n>=20 ===')
key = np.stack([g,s],1)
uniq, inv = np.unique(key, axis=0, return_inverse=True)
cnt = np.bincount(inv, minlength=len(uniq))
pc  = np.bincount(inv, weights=y, minlength=len(uniq))/np.maximum(cnt,1)
big = cnt >= 20
print(f'  {big.sum()} cells, {cnt[big].sum():,} levels')
print(f'  pure cells (p==0 or 1): {((pc[big]==0)|(pc[big]==1)).mean():.1%}')
imp = np.minimum(pc, 1-pc)
print(f'  mean within-cell impurity (weighted): {np.average(imp[big], weights=cnt[big]):.4f}')
band = big & (np.abs(uniq[:,0]-11) > 4)   # away from the crossing
print(f'  same, cells with |gap-11|>4 (away from crossing): {np.average(imp[band], weights=cnt[band]):.4f}  ({band.sum()} cells)')
