import numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

SURF='#fcfcfb'; INK='#0b0b0b'; INK2='#52514e'; GRID='#e3e2de'
S=['#2a78d6','#eb6834','#1baf7a']; RED='#e34948'; MID='#f0efec'
DIV=LinearSegmentedColormap.from_list('d',[RED,MID,S[0]])

def load(p):
    z=np.load(p); dr=z['d_rich'].astype(int); dp=z['d_poor'].astype(int)
    m=z['reached']
    took=(z['reached_fid'].astype(int)==z['colour_of_rich'].astype(int))
    return dr[m],dp[m],took[m].astype(float)

dr,dp,y=load('/workspace/h1/bcnv11.s1.npz')
gap,dsum=dr-dp,dr+dp

fig,ax=plt.subplots(2,2,figsize=(12.5,9.6),facecolor=SURF)
for a in ax.ravel():
    a.set_facecolor(SURF)
    for s in a.spines.values(): s.set_color(GRID)
    a.tick_params(colors=INK2,labelsize=9); a.grid(color=GRID,lw=.6,zorder=0)

# A: heatmap over (d_poor, d_rich)
A=ax[0,0]; N=26
P=np.full((N,N),np.nan)
for i in range(1,N):
    for j in range(1,N):
        m=(dr==i)&(dp==j)
        if m.sum()>=10: P[i,j]=y[m].mean()
im=A.imshow(P,origin='lower',cmap=DIV,vmin=0,vmax=1,interpolation='nearest')
A.plot([0,N-1],[10,N+9],ls='--',lw=1.6,color=INK,zorder=3)
A.text(15.5,25.2,'expert boundary\n($\\Delta d=10$)',fontsize=8.5,color=INK,ha='center',va='top')
A.set_xlim(0,N-1); A.set_ylim(0,N-1)
A.set_xlabel('distance to poorer objective',color=INK2,fontsize=10)
A.set_ylabel('distance to richer objective',color=INK2,fontsize=10)
A.set_title('A  Choice over both distances (cells n$\\geq$10)',color=INK,fontsize=11.5,loc='left',pad=10)
cb=fig.colorbar(im,ax=A,fraction=.046,pad=.03); cb.set_label('P(takes richer)',color=INK2,fontsize=9)
cb.ax.tick_params(colors=INK2,labelsize=8); cb.outline.set_color(GRID)
A.text(.98,.04,'bands run diagonally $\\Rightarrow$ only $\\Delta d$ matters',transform=A.transAxes,
       ha='right',fontsize=9,color=INK,bbox=dict(fc=SURF,ec=GRID,boxstyle='round,pad=0.35'))

# B: psychometric
B=ax[0,1]
gs=np.arange(-14,25); pm=[]; nn=[]
for g in gs:
    m=gap==g; pm.append(y[m].mean() if m.sum()>=25 else np.nan); nn.append(m.sum())
pm=np.array(pm)
B.step(np.arange(-14,25),(np.arange(-14,25)<10).astype(float),where='mid',color=INK2,ls='--',lw=1.6,zorder=2,label='expert (a step at 10)')
B.plot(gs,pm,color=S[0],lw=2,zorder=4,label='bcnv11.s1')
B.plot(gs,pm,'o',ms=4.5,color=S[0],mec=SURF,mew=1.2,zorder=5)
B.axhline(.5,color=GRID,lw=1,zorder=1)
B.axvline(11.1,color=S[1],lw=1.6,ls=':',zorder=3)
B.text(11.6,.86,'model crosses\n50% at 11.1',color=S[1],fontsize=9)
B.set_xlabel('$\\Delta d$  = (steps to richer) $-$ (steps to poorer)',color=INK2,fontsize=10)
B.set_ylabel('P(takes richer)',color=INK2,fontsize=10)
B.set_title('B  It is a curve, not a step',color=INK,fontsize=11.5,loc='left',pad=10)
lg=B.legend(frameon=False,fontsize=9.5,loc='lower left'); [t.set_color(INK) for t in lg.get_texts()]

# C: H2 - at fixed gap, does absolute distance matter?
C=ax[1,0]
for k,g in enumerate((6,10,14)):
    xs=[];ps=[]
    for s in range(4,50,2):
        m=(gap==g)&(dsum>=s)&(dsum<s+4)
        if m.sum()>=30: xs.append(s+2); ps.append(y[m].mean())
    C.plot(xs,ps,'o-',color=S[k],lw=2,ms=6,mec=SURF,mew=1.2,label=f'$\\Delta d={g}$')
    if xs: C.text(xs[-1]+1,ps[-1],f'$\\Delta d={g}$',color=S[k],fontsize=9.5,va='center',fontweight='bold')
C.set_xlim(2,52); C.set_ylim(-.03,1.03)
C.set_xlabel('$d_{rich}+d_{poor}$  (absolute distance)',color=INK2,fontsize=10)
C.set_ylabel('P(takes richer)',color=INK2,fontsize=10)
C.set_title('C  H2: flat lines $\\Rightarrow$ absolute distance is ignored',color=INK,fontsize=11.5,loc='left',pad=10)

# D: H1 residual, all three seeds
D=ax[1,1]
for k,s in enumerate((1,2,3)):
    dr2,dp2,y2=load(f'/workspace/h1/bcnv11.s{s}.npz'); g2=dr2-dp2
    xs=[];ims=[]
    for g in range(-12,25):
        sel=g2==g
        if sel.sum()<100: continue
        key=dr2[sel]*1000+dp2[sel]; u,inv=np.unique(key,return_inverse=True)
        cnt=np.bincount(inv); pc=np.bincount(inv,weights=y2[sel])/np.maximum(cnt,1)
        ok=cnt>=15
        if ok.sum()<3: continue
        xs.append(g); ims.append(np.average(np.minimum(pc,1-pc)[ok],weights=cnt[ok]))
    D.plot(xs,ims,'o-',color=S[k],lw=2,ms=5,mec=SURF,mew=1.2)
    D.text(xs[-1]+.5,ims[-1],f's{s}',color=S[k],fontsize=9.5,va='center',fontweight='bold')
D.axhline(0,color=INK2,lw=1.4,ls='--')
D.text(-11,.005,'H1 predicts zero',color=INK2,fontsize=9,va='bottom')
D.set_xlabel('$\\Delta d$',color=INK2,fontsize=10)
D.set_ylabel('within-cell disagreement',color=INK2,fontsize=10)
D.set_title('D  H1 fails: identical distances, different choices',color=INK,fontsize=11.5,loc='left',pad=10)

fig.suptitle('Is the route model\'s choice a function of the two distances alone?   bcnv11 (0.8M prefix-LM), 50k held-out levels',
             color=INK,fontsize=12.5,x=.008,ha='left',y=.985)
fig.tight_layout(rect=[0,0,1,.965])
fig.savefig('/workspace/h1/h1_h2.png',dpi=200,facecolor=SURF)
print('saved')
