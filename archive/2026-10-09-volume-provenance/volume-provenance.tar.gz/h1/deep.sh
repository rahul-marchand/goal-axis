#!/usr/bin/env bash
set -euo pipefail
export PATH="/root/.local/bin:${PATH}"
cd /workspace/GoalMisgeneralisation
OFFS="-0.55 -0.65 -0.80 -1.00 -1.20 -1.50 -2.00"
for s in 1 2 3; do
  uv run python scripts/decode_written.py /workspace/data/offline/runs/bcnv11.s$s \
    --sweep o0 --offsets $OFFS --out /workspace/h1/deep/s$s --n 20000
done
uv run python scripts/decode_written.py /workspace/data/offline/runs/bcnv11.s1 \
  --sweep o1 --offsets 0.55 0.65 0.80 1.00 1.20 1.50 2.00 --out /workspace/h1/deep/s1 --n 20000
echo DEEP_DONE
