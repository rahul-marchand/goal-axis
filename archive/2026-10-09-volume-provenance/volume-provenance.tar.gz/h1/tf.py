import jax; jax.config.update("jax_default_matmul_precision", "highest")
import numpy as np, jax.numpy as jnp
from goalmisgen.offline.demos import DemoSet, NO_ACTION
from goalmisgen.offline.train import list_checkpoints, load_checkpoint
from goalmisgen.offline import fast_decode

demos = DemoSet.load('/workspace/data/offline/demos/test.rho100', hide_values=True)
model, params = load_checkpoint(list_checkpoints('/workspace/data/offline/runs/bcnv11.s1')[-1][1])
cfg = model.config
tree = params['params']
obs = jnp.asarray(demos.observations(np.arange(8)))

# A fixed pretend route, so both paths see identical inputs at every position.
rng = np.random.default_rng(0)
route = rng.integers(0, cfg.n_actions, size=(8, cfg.max_actions)).astype(np.int32)

mod_logits, _ = model.apply(params, obs, jnp.asarray(route))     # (B, 65, C)

prefix, cache = fast_decode.prefix_pass(tree, cfg, obs)
mine = [np.asarray(fast_decode._logits(tree, prefix[:, -1:])[:, 0])]
for p in range(cfg.max_actions):
    x, cache = fast_decode.action_step(tree, cfg, cache, jnp.asarray(route[:, p]), p)
    mine.append(np.asarray(fast_decode._logits(tree, x)[:, 0]))
mine = np.stack(mine, 1)
mod = np.asarray(mod_logits)

d = np.abs(mine - mod)
print('teacher-forced logit agreement')
print(f'  max abs diff overall      {d.max():.3e}')
for p in (0, 1, 2, 3, 5, 10, 30, 63, 64):
    print(f'    position {p:>3}: max diff {d[:, p].max():.3e}')
