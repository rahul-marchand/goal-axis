import numpy as np
from goalmisgen.offline.demos import DemoSet

d = DemoSet.load('/workspace/data/offline/demos/test.rho100', hide_values=True)
vals = np.asarray(d.values); dist = np.asarray(d.distances).astype(int)
rich = np.argmax(vals, axis=1)
rows = np.arange(len(rich))
d_r = dist[rows, rich]; d_p = dist[rows, 1 - rich]
ok = (d_r > 0) & (d_p > 0) & (d_r <= 120) & (d_p <= 120)
print(f'levels {len(rich):,}   usable {ok.sum():,}')
d_r, d_p = d_r[ok], d_p[ok]
gap = d_r - d_p
print(f'gap (d_rich - d_poor): min {gap.min()} max {gap.max()}  |gap|<=20: {(abs(gap)<=20).mean():.1%}')
print(f'd_rich range {d_r.min()}-{d_r.max()}   sum range {(d_r+d_p).min()}-{(d_r+d_p).max()}')

from collections import Counter
cells = Counter(zip(d_r.tolist(), d_p.tolist()))
for thr in (10, 20, 50, 100):
    big = {c:n for c,n in cells.items() if n >= thr}
    cov = sum(big.values())
    print(f'  cells with n>={thr:<4}: {len(big):>5}   covering {cov:,} levels ({cov/len(d_r):.0%})')

# the decision-relevant band: gap near the threshold of 10
print()
print('cells with n>=20, restricted to gap in [4,16] (near the boundary):')
band = {c:n for c,n in cells.items() if n >= 20 and 4 <= c[0]-c[1] <= 16}
print(f'  {len(band)} cells, {sum(band.values()):,} levels')
gaps = sorted({c[0]-c[1] for c in band})
print(f'  gaps covered: {gaps}')
for g in gaps:
    sub = {c:n for c,n in band.items() if c[0]-c[1]==g}
    sums = sorted(c[0]+c[1] for c in sub)
    print(f'   gap {g:>3}: {len(sub):>3} cells  n={sum(sub.values()):>5}  d_sum from {sums[0]} to {sums[-1]}')
