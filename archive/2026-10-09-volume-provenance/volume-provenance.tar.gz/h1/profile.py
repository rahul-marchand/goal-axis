import time, numpy as np
from goalmisgen.offline.demos import DemoSet
from goalmisgen.offline.train import list_checkpoints, load_checkpoint
from goalmisgen.offline.decode import replay_all, summarise_routes, decode_batch_size
from goalmisgen.offline import fast_decode

demos = DemoSet.load('/workspace/data/offline/demos/test.rho100', hide_values=True)
model, params = load_checkpoint(list_checkpoints('/workspace/data/offline/runs/bcnv11.s1')[-1][1])
idx = np.arange(10000)
print('default decode_batch_size:', decode_batch_size(model))
print('expert route lengths: mean %.1f  p90 %d  max %d' % (
    np.asarray(demos.lengths)[idx].mean(), np.percentile(np.asarray(demos.lengths)[idx],90), np.asarray(demos.lengths)[idx].max()))

t=time.perf_counter(); obs = demos.observations(idx); t_obs=time.perf_counter()-t
fast_decode.greedy_decode_cached(model, params, obs[:256])
t=time.perf_counter(); dec = fast_decode.greedy_decode_cached(model, params, obs); t_dec=time.perf_counter()-t
t=time.perf_counter(); outcomes = replay_all(demos, idx, dec); t_rep=time.perf_counter()-t
t=time.perf_counter(); summarise_routes(demos, idx, dec, outcomes); t_sum=time.perf_counter()-t
tot=t_obs+t_dec+t_rep+t_sum
for n,v in (('observations',t_obs),('decode',t_dec),('replay_all',t_rep),('summarise',t_sum)):
    print(f'  {n:<14}{v:7.2f}s  {100*v/tot:5.1f}%')
print(f'  {"TOTAL":<14}{tot:7.2f}s for 10k  ->  {5*tot:.0f}s for 50k')

print()
for bs in (256, 512, 1024, 2048, 4096):
    fast_decode.greedy_decode_cached(model, params, obs[:256], batch_size=bs)
    t=time.perf_counter(); fast_decode.greedy_decode_cached(model, params, obs, batch_size=bs); d=time.perf_counter()-t
    print(f'  batch {bs:>5}: {d:6.2f}s / 10k')
