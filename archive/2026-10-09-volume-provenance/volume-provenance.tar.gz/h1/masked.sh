#!/usr/bin/env bash
set -euo pipefail
export PATH="/root/.local/bin:${PATH}"
cd /workspace/GoalMisgeneralisation
for s in 1 2 3; do
  uv run python scripts/decode_masked.py /workspace/data/offline/runs/bcnv11.s$s \
    --sweep o0 --out /workspace/h1/masked/s$s --n 20000
done
echo ALL_MASKED_DONE
