import sys, time, numpy as np, jax
if len(sys.argv) > 1 and sys.argv[1] == 'highest':
    jax.config.update('jax_default_matmul_precision', 'highest')
from goalmisgen.offline.demos import DemoSet
from goalmisgen.offline.train import list_checkpoints, load_checkpoint
from goalmisgen.offline.decode import greedy_decode
from goalmisgen.offline import fast_decode

demos = DemoSet.load('/workspace/data/offline/demos/test.rho100', hide_values=True)
model, params = load_checkpoint(list_checkpoints('/workspace/data/offline/runs/bcnv11.s1')[-1][1])
obs = demos.observations(np.arange(4000))
a = greedy_decode(model, params, obs); b = fast_decode.greedy_decode_cached(model, params, obs)
n = int((a.actions != b.actions).any(1).sum())
print(f'precision={sys.argv[1] if len(sys.argv)>1 else "default":<8} routes differing: {n}/4000')
for name, fn in (('uncached', greedy_decode), ('cached', fast_decode.greedy_decode_cached)):
    fn(model, params, obs[:256])
    t=time.perf_counter(); fn(model, params, obs); dt=time.perf_counter()-t
    print(f'   {name:<9} {dt:6.2f}s / 4000  ->  {50000*dt/4000:6.1f}s for 50k')
