import time, numpy as np
from goalmisgen.offline.demos import DemoSet
from goalmisgen.offline.train import list_checkpoints, load_checkpoint
from goalmisgen.offline.decode import greedy_decode
from goalmisgen.offline import fast_decode

demos = DemoSet.load('/workspace/data/offline/demos/test.rho100', hide_values=True)
model, params = load_checkpoint(list_checkpoints('/workspace/data/offline/runs/bcnv11.s1')[-1][1])
idx = np.arange(4000)
obs = demos.observations(idx)

a = greedy_decode(model, params, obs)
b = fast_decode.greedy_decode_cached(model, params, obs)
print('actions equal:', np.array_equal(a.actions, b.actions))
print('lengths equal:', np.array_equal(a.lengths, b.lengths))
print('eos     equal:', np.array_equal(a.emitted_eos, b.emitted_eos))
print('mean route length', a.lengths.mean().round(2), ' max', a.lengths.max())

for name, fn in (('uncached', greedy_decode), ('cached', fast_decode.greedy_decode_cached)):
    fn(model, params, obs[:256])
    t=time.perf_counter(); fn(model, params, obs); dt=time.perf_counter()-t
    print(f'  {name:<9} {dt:6.2f}s / 4000 levels  ->  {50000*dt/4000:6.1f}s for 50k')
