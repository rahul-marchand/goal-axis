set -u
cd /workspace/GoalMisgeneralisation
export CUDA_VISIBLE_DEVICES=$1; shift
export XLA_PYTHON_CLIENT_MEM_FRACTION=0.85
/workspace/GoalMisgeneralisation/.venv/bin/python scripts/decode_written.py   /workspace/data/offline/runs/bcnv11.s1 --sweep o0 --drift   --offsets "$@" --out /workspace/h1/written
echo WRITTEN_DONE
