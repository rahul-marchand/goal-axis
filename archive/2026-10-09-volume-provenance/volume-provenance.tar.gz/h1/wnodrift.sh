set -u
cd /workspace/GoalMisgeneralisation
export CUDA_VISIBLE_DEVICES=0
export XLA_PYTHON_CLIENT_MEM_FRACTION=0.85
/workspace/GoalMisgeneralisation/.venv/bin/python scripts/decode_written.py   /workspace/data/offline/runs/bcnv11.s1 --sweep o0   --offsets -0.45 -0.40 -0.30 -0.20 -0.10 -0.05 0.00 0.05 0.10 0.20 0.30 0.40 0.45   --out /workspace/h1/written_nodrift
echo NODRIFT_DONE
