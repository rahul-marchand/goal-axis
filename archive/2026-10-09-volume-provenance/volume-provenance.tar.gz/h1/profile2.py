import time, numpy as np
from goalmisgen.offline.demos import DemoSet
from goalmisgen.offline.train import list_checkpoints, load_checkpoint
from goalmisgen.offline.decode import replay_all
from goalmisgen.analysis.behaviour import summarise, value_distance_decisions, indifference_point
from goalmisgen.offline import fast_decode

demos = DemoSet.load('/workspace/data/offline/demos/test.rho100', hide_values=True)
model, params = load_checkpoint(list_checkpoints('/workspace/data/offline/runs/bcnv11.s1')[-1][1])
idx = np.arange(10000)
obs = demos.observations(idx)
fast_decode.greedy_decode_cached(model, params, obs[:256])

def clock(f):
    t=time.perf_counter(); r=f(); return r, time.perf_counter()-t

dec, t_dec   = clock(lambda: fast_decode.greedy_decode_cached(model, params, obs))
out, t_rep   = clock(lambda: replay_all(demos, idx, dec))
_,   t_beh   = clock(lambda: summarise(out))
vdd, t_vdd   = clock(lambda: value_distance_decisions(out))
_,   t_fit   = clock(lambda: indifference_point(vdd[0], vdd[1]))
tot = t_dec+t_rep+t_beh+t_vdd+t_fit
for n,v in (('decode (cached)',t_dec),('replay_all',t_rep),('summarise()',t_beh),
            ('value_distance_decisions',t_vdd),('indifference_point (fit_logistic)',t_fit)):
    print(f'  {n:<36}{v:7.2f}s  {100*v/tot:5.1f}%')
print(f'  {"TOTAL":<36}{tot:7.2f}s / 10k   ->  {5*tot:.0f}s per 50k')
print(f'\n  needed for the npz: decode + replay only = {t_dec+t_rep:.2f}s / 10k -> {5*(t_dec+t_rep):.0f}s per 50k')
