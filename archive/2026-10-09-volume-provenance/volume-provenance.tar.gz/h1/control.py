'''Norm-matched random directions: does any edit of that size move the threshold?'''
import numpy as np
from goalmisgen.analysis.weights import fit_axis_and_drift
from goalmisgen.offline.axis import arm_dirs, load_base, load_diffs
from goalmisgen.offline.decode import replay_all
from goalmisgen.offline.demos import DemoSet
from goalmisgen.offline.fast_decode import greedy_decode_cached

demos = DemoSet.load('/workspace/data/offline/demos/test.rho100', hide_values=True)
idx = np.arange(20000); obs = demos.observations(idx)
vals = np.asarray(demos.values)[idx]; dist = np.asarray(demos.distances)[idx].astype(int)
fid = np.asarray(demos.feature_ids)[idx].astype(int)
rich = np.argmax(vals,1); rows = np.arange(len(idx))
d_r, d_p, c_r = dist[rows,rich], dist[rows,1-rich], fid[rows,rich]

def theta(params):
    dec = greedy_decode_cached(base.model, params, obs)
    out = replay_all(demos, idx, dec)
    m = np.array([bool(o.get('reached_objective')) for o in out])
    rf = np.array([-1 if o.get('reached_feature_id') is None else int(o['reached_feature_id']) for o in out])
    gap = (d_r-d_p)[m]; took = (rf==c_r)[m].astype(float)
    gs = np.arange(-20,50)
    p = np.array([took[gap==g].mean() if (gap==g).sum()>=25 else np.nan for g in gs])
    ok = np.isfinite(p); xs, ys = gs[ok], p[ok]
    for a in range(len(xs)-1):
        if (ys[a]-0.5)*(ys[a+1]-0.5)<=0 and ys[a]!=ys[a+1]:
            return xs[a]+(ys[a]-0.5)/(ys[a]-ys[a+1])*(xs[a+1]-xs[a]), m.mean()
    return float('nan'), m.mean()

base = load_base('/workspace/data/offline/runs/bcnv11.s1')
arms = arm_dirs('/workspace/data/offline/runs/bcnv11.s1','o0',1000)
diffs = load_diffs(base, arms)
offs = np.array(sorted(o for o in diffs if abs(o)>1e-9))
axis,_ = fit_axis_and_drift(offs, np.stack([diffs[o] for o in offs]))

t,r = theta(base.params); print(f'base                       theta {t:6.2f}  reached {r:.3f}')
rng = np.random.default_rng(0)
for scale in (0.20, 0.45):
    target = scale*np.linalg.norm(axis)
    t,r = theta(base.unravel(np.asarray(base.flat + scale*axis, np.float32)))
    print(f'axis   x{scale:.2f}  |.|={target:8.3f}  theta {t:6.2f}  reached {r:.3f}')
    for k in range(3):
        v = rng.standard_normal(len(axis)).astype(np.float64); v *= target/np.linalg.norm(v)
        t,r = theta(base.unravel(np.asarray(base.flat + v, np.float32)))
        print(f'random #{k} |.|={target:8.3f}  theta {t:6.2f}  reached {r:.3f}')
