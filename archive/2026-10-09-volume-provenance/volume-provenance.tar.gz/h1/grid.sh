set -u
cd /workspace/GoalMisgeneralisation
export CUDA_VISIBLE_DEVICES=0
export XLA_PYTHON_CLIENT_MEM_FRACTION=0.85
PY=/workspace/GoalMisgeneralisation/.venv/bin/python
OFF='-0.45 -0.40 -0.30 -0.20 -0.10 -0.05 0.00 0.05 0.10 0.20 0.30 0.40 0.45'
R=/workspace/data/offline/runs
G=/workspace/h1/grid
mkdir -p $G
for s in 1 2 3; do
  # the base itself, on the same decoder as everything else
  [ -f $G/base.s$s.npz ] || $PY scripts/decode_h1.py $R/bcnv11.s$s 50000 $G/base.s$s.npz 2>&1 | tail -1
  for k in 0 1; do
    echo "=== seed $s sweep o$k $(date -u +%H:%M:%S) ==="
    for o in $OFF; do
      sign=$($PY -c "print('-' if $o<0 else '+')"); d=$($PY -c "print(f'{abs(round($o*100)):03d}')")
      tag=o${k}${sign}${d}
      out=$G/arms.s$s/$tag.npz
      [ -f "$out" ] || { mkdir -p $G/arms.s$s; $PY scripts/decode_h1.py $R/bcnv11.s$s/arms/${tag}@1k 50000 $out 2>&1 | tail -1; }
    done
    $PY scripts/decode_written.py $R/bcnv11.s$s --sweep o$k --offsets $OFF --out $G/written.s$s 2>&1 | tail -2
  done
done
echo GRID_DONE
