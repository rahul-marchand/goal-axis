set -u
cd /workspace/GoalMisgeneralisation
export PATH=$HOME/.local/bin:$PATH
for a in $(ls /workspace/data/offline/runs/bcnv11.s1/arms/ | grep '^o0'); do
  out=/workspace/h1/arms/${a%@1k}.npz
  [ -f "$out" ] && { echo "have $a"; continue; }
  echo "$(date -u +%H:%M:%S) $a"
  uv run python scripts/decode_h1.py /workspace/data/offline/runs/bcnv11.s1/arms/$a 50000 $out 2>&1 | tail -2
done
echo ALL_DONE
