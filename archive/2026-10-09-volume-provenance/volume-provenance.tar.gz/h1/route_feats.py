'''Route-shape features: how hard is the shortest path to *compute*, not how long it is.'''
import numpy as np
from goalmisgen.offline.demos import DemoSet
from goalmisgen.envs.solver import path_to_objective

d = DemoSet.load('/workspace/data/offline/demos/test.rho100', hide_values=True)
n = len(d)
vals = np.asarray(d.values); rich = np.argmax(vals, axis=1)
out = {k: np.zeros(n, np.float32) for k in
       ('turns_rich','turns_poor','back_rich','back_poor','excur_rich','excur_poor','branch_rich','branch_poor')}

def feats(level, k):
    p = path_to_objective(level, k)
    if p is None or len(p) < 2: return 0.,0.,0.,0.
    p = np.array(p); tgt = p[-1]
    steps = np.diff(p, axis=0)
    turns = int((np.abs(np.diff(steps, axis=0)).sum(1) > 0).sum())
    md = np.abs(p - tgt).sum(1)                 # Manhattan distance to target along the route
    back = int((np.diff(md) >= 0).sum())        # steps that do not close the gap
    excur = float((md - (len(p)-1-np.arange(len(p)))).min())  # how far 'behind' the route falls
    free = ~level.walls
    br = 0
    for (r,c) in p:
        nb = sum(free[r+dr, c+dc] for dr,dc in ((-1,0),(1,0),(0,-1),(0,1))
                 if 0 <= r+dr < free.shape[0] and 0 <= c+dc < free.shape[1])
        br += nb > 2
    return float(turns), float(back), excur, float(br)

for i in range(n):
    lv = d.level(i); r = int(rich[i])
    tr, ba, ex, bb = feats(lv, r);        out['turns_rich'][i],out['back_rich'][i],out['excur_rich'][i],out['branch_rich'][i]=tr,ba,ex,bb
    tr, ba, ex, bb = feats(lv, 1-r);      out['turns_poor'][i],out['back_poor'][i],out['excur_poor'][i],out['branch_poor'][i]=tr,ba,ex,bb
    if i % 10000 == 0: print(i, flush=True)
np.savez('/workspace/h1/route_feats.npz', **out); print('saved')
