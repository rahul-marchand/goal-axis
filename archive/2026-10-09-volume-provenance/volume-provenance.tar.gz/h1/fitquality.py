'''How good a model is drift + offset*axis, and how big is each piece?'''
import numpy as np
from goalmisgen.analysis.weights import fit_axis_and_drift, cosine
from goalmisgen.offline.axis import arm_dirs, load_base, load_diffs

for seed in (1, 2, 3):
    base = load_base(f'/workspace/data/offline/runs/bcnv11.s{seed}')
    for sweep in ('o0', 'o1'):
        arms = arm_dirs(f'/workspace/data/offline/runs/bcnv11.s{seed}', sweep, 1000)
        diffs = load_diffs(base, arms)
        offs = np.array(sorted(o for o in diffs if abs(o) > 1e-9))
        D = np.stack([diffs[o] for o in offs]).astype(np.float64)
        axis, drift = fit_axis_and_drift(offs, D)
        pred = drift[None] + offs[:, None] * axis[None]
        res = D - pred
        centred = D - D.mean(0)
        r2 = 1 - (res**2).sum() / (centred**2).sum()
        # split-half reliability: fit the axis on alternate offsets
        a1, _ = fit_axis_and_drift(offs[0::2], D[0::2])
        a2, _ = fit_axis_and_drift(offs[1::2], D[1::2])
        print(f'seed {seed} {sweep}: {len(offs)} arms')
        print(f'   |drift| {np.linalg.norm(drift):6.3f}   |axis| per unit value {np.linalg.norm(axis):6.3f}'
              f'   cos(drift,axis) {cosine(drift,axis):+.3f}')
        print(f'   R^2 of the affine fit across arms {r2:.3f}   split-half reliability of the axis {cosine(a1,a2):+.3f}')
        for o in (0.05, 0.20, 0.45):
            i = int(np.argmin(np.abs(offs - o)))
            print(f'     offset {offs[i]:+.2f}: |diff| {np.linalg.norm(D[i]):5.3f}'
                  f'  = |drift| {np.linalg.norm(drift):5.3f}'
                  f'  + |offset*axis| {abs(offs[i])*np.linalg.norm(axis):5.3f}'
                  f'  + |residual| {np.linalg.norm(res[i]):5.3f}')
