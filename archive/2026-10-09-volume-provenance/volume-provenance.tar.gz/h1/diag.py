import numpy as np, jax.numpy as jnp, jax
from goalmisgen.offline.demos import DemoSet, NO_ACTION
from goalmisgen.offline.train import list_checkpoints, load_checkpoint
from goalmisgen.offline.decode import greedy_decode
from goalmisgen.offline import fast_decode

demos = DemoSet.load('/workspace/data/offline/demos/test.rho100', hide_values=True)
model, params = load_checkpoint(list_checkpoints('/workspace/data/offline/runs/bcnv11.s1')[-1][1])
obs = demos.observations(np.arange(4000))
a = greedy_decode(model, params, obs); b = fast_decode.greedy_decode_cached(model, params, obs)

diff_rows = np.where((a.actions != b.actions).any(1) | (a.lengths != b.lengths))[0]
print(f'{len(diff_rows)} of 4000 routes differ ({100*len(diff_rows)/4000:.2f}%)')
print('length differences:', np.unique(a.lengths[diff_rows]-b.lengths[diff_rows], return_counts=True))

# For each differing route, find the first position where they diverge and
# measure how close the top-two logits were there in the UNCACHED model.
cfg = model.config
margins = []
for r in diff_rows[:40]:
    pos = int(np.argmax(a.actions[r] != b.actions[r]))
    acts = a.actions[r:r+1].copy(); acts[0, pos:] = NO_ACTION
    lg, _ = model.apply(params, jnp.asarray(obs[r:r+1]), jnp.asarray(acts))
    row = np.sort(np.asarray(lg)[0, pos])[::-1]
    margins.append(row[0]-row[1])
margins = np.array(margins)
print(f'top-two logit margin at first divergence: median {np.median(margins):.2e}  max {margins.max():.2e}')
print(f'  (float32 eps on logits of size ~{np.abs(row).max():.1f} is ~{np.abs(row).max()*1.2e-7:.1e})')
