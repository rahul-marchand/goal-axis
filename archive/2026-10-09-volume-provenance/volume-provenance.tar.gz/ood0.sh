set -uo pipefail
cd /workspace/GoalMisgeneralisation
git fetch -q origin && git checkout -q goal-structure && git pull -q
.venv/bin/python experiments/014_value_axis_analysis.py \
  --base /workspace/data/runs/novalue11/local-files/cp_140206080 \
  --arms /workspace/data/valueaxis/runs \
  --levels /workspace/data/valueaxis/levels/v050 \
  --at -1 --prefix c \
  --extrapolate -1.5 -1.0 -0.5 -0.2 0.0 0.2 0.4 1.3 1.5 1.8 2.0 2.5 \
  > /workspace/data/valueaxis/results/ood-colour0.txt 2>&1
echo "OOD0_DONE rc=$?"
