#!/bin/bash
# E9: the edit families on the route model, now that --offline runs at all.
#   nohup bash /workspace/e9_chain.sh > /dev/null 2>&1 &
# Everything runs from the frozen snapshot with --target soft pinned, because
# another session edits the shared scripts.
set -uo pipefail
ulimit -n $(ulimit -Hn)
export PYTHONUNBUFFERED=1 XLA_PYTHON_CLIENT_PREALLOCATE=false JAX_COMPILATION_CACHE_DIR=/workspace/data/jax-cache

SNAP=/workspace/gvf-e9-snap
PY=/workspace/GoalMisgeneralisation/.venv/bin/python
DATA=/workspace/data
DEMOS=$DATA/offline/demos
OUT=$DATA/figures-data/gain-vs-factorised/e9
RES=/workspace/GoalMisgeneralisation/results/gain-vs-factorised
LOG=$DATA/logs/gvf
mkdir -p "$OUT" "$RES" "$LOG"
cd $SNAP || exit 1
L=$LOG/e9.log
say() { echo "[$(date -u +%H:%M:%S)] $*" >> $L; }

SHIFTS="-4 -2 2 4"
EVAL="-16 -12 -8 -4 -2 2 4 8"

# $1 base name, $2 run dir, $3 demos dir, $4 tag, rest: extra args
edit() {
  local name=$1 run=$2 demos=$3 tag=$4; shift 4
  if [ -f "$OUT/$name.$tag.json" ]; then say "$name $tag done already"; return; fi
  say "$name $tag: $*"
  timeout 5400 $PY scripts/cheapest_edit.py "$run" --offline --demos "$demos" \
    --target soft --seeds 0 1 --steps 400 --shifts $SHIFTS --eval-shifts $EVAL \
    --json "$OUT/$name.$tag.json" --save-deltas "$OUT/$name.$tag.npz" "$@" \
    > "$RES/e9-edit-$name.$tag.txt" 2> "$LOG/e9-edit-$name.$tag.err" \
    && say "$name $tag ok" || say "$name $tag FAILED"
}

profile() {
  local name=$1 run=$2 demos=$3
  if [ -f "$OUT/$name.profile.json" ]; then say "$name profile done already"; return; fi
  say "$name direction profile"
  timeout 3600 $PY scripts/direction_profile.py "$run" --offline --demos "$demos" \
    --json "$OUT/$name.profile.json" \
    > "$RES/e9-profile-$name.txt" 2> "$LOG/e9-profile-$name.err" \
    && say "$name profile ok" || say "$name profile FAILED"
}

say "=== E9 start, snapshot $SNAP"

# --- 1. which two-parameter knob works, all three seeds -------------------------
for s in 1 2 3; do
  edit bcnv11.s$s $DATA/offline/runs/bcnv11.s$s $DEMOS gain --family gain
  edit bcnv11.s$s $DATA/offline/runs/bcnv11.s$s $DEMOS rotation --family rotation
done

# --- 3. what shape is the axis (cheap, no search) ------------------------------
for s in 1 2 3; do
  profile bcnv11.s$s $DATA/offline/runs/bcnv11.s$s $DEMOS
done

# --- 2. where value can live: module-restricted dense edits, seed 1 first ------
EARLY=("block 0 attention" "block 0 mlp" "block 1 attention" "block 1 mlp")
LATE=("block 2 attention" "block 2 mlp" "block 3 attention" "block 3 mlp")
for s in 1 2 3; do
  run=$DATA/offline/runs/bcnv11.s$s
  edit bcnv11.s$s $run $DEMOS all --family dense
  edit bcnv11.s$s $run $DEMOS embed --family dense --modules embed
  edit bcnv11.s$s $run $DEMOS head --family dense --modules head
  edit bcnv11.s$s $run $DEMOS early --family dense --modules "${EARLY[@]}"
  edit bcnv11.s$s $run $DEMOS late --family dense --modules "${LATE[@]}"
done

# --- the scaling twin, last: same questions at 16x the width -------------------
D512=$DATA/offline/runs/scaling/sc11.d512l4.s1
edit sc11.d512l4.s1 $D512 $DEMOS/scaling gain --family gain
edit sc11.d512l4.s1 $D512 $DEMOS/scaling rotation --family rotation
profile sc11.d512l4.s1 $D512 $DEMOS/scaling

say "E9_CHAIN_DONE"
