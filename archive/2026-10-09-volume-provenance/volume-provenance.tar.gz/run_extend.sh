#!/bin/bash
# Past-parity extension arms (x families) on every existing base, plus measures.
set -uo pipefail
export PATH=/root/.local/bin:$PATH
cd /workspace/GoalMisgeneralisation
UV=/root/.local/bin/uv
LEVELS=/workspace/data/levels/values/1.00-0.50@500k
while pgrep -f run_program.sh > /dev/null; do sleep 120; done

xsweep() { # agent objective values...
  local agent=$1 obj=$2; shift 2
  $UV run python scripts/value_axis_sweep.py --agent "$agent" --objectives "$obj" \
    --values "$@" --steps 400000 --allow-reorder || echo "XSWEEP_FAILED $agent o$obj"
}
xmeasure() { # agent prefix base_value outfile
  local agent=$1 prefix=$2 bv=$3 out=$4
  local cp; cp=$(python3 -c "import json;print(json.load(open('/workspace/data/runs/$agent/BASE.json'))['checkpoint'])")
  $UV run python experiments/014_value_axis_analysis.py \
    --base "/workspace/data/runs/$agent/$cp" --arms "/workspace/data/runs/$agent/arms" \
    --levels "$LEVELS" --prefix "$prefix" --base-value "$bv" --arm-steps 400000 --at -1 \
    > "results/$out.txt" 2> "results/$out.err" || echo "XMEASURE_FAILED $out"
}

for agent in novalue11.s1234 novalue11.s5678 novalue11.s9012 resnet11novalue.s1234-cp130M vit11novalue.s1234; do
  xsweep "$agent" 0 0.45 0.35 0.25 0.15
  xsweep "$agent" 1 1.05 1.15 1.25 1.35
done
for agent in novalue11.s1234 novalue11.s5678 novalue11.s9012 resnet11novalue.s1234-cp130M vit11novalue.s1234; do
  xmeasure "$agent" x0 1.0 "extend-$agent-x0"
  xmeasure "$agent" x1 0.5 "extend-$agent-x1"
done
echo EXTEND_DONE
