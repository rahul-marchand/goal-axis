#!/usr/bin/env bash
set -uo pipefail
cd /workspace/GoalMisgeneralisation
export PATH=/root/.local/bin:$PATH
FD=/workspace/data/figures-data
S=/workspace/scurves-g1.status
run() { echo "== $*" ; "$@" || echo "FAILED: $*" >> $S ; }

run uv run python /workspace/fit_axis_cache.py --agent /workspace/data/runs/resnet11nvg1.s1234 --sweep o1 --out $FD/resnet
run uv run python /workspace/fit_axis_cache.py --agent /workspace/data/runs/vit11nvg1.s9012 --sweep o1 --out $FD/vit

run uv run python scripts/written_scurves.py --agent /workspace/data/runs/novalue11g1.s1234 --axis $FD/drc/basin-g1/axis.novalue11g1.s1234.o1@400000.npz --alphas -0.2 0 0.2 --out $FD/drc/scurves-g1
run uv run python scripts/written_scurves.py --agent /workspace/data/runs/resnet11nvg1.s1234 --axis $FD/resnet/axis.resnet11nvg1.s1234.o1@400000.npz --alphas -0.2 0 0.2 --out $FD/resnet/scurves
run uv run python scripts/written_scurves.py --agent /workspace/data/runs/vit11nvg1.s9012 --axis $FD/vit/axis.vit11nvg1.s9012.o1@400000.npz --alphas -0.2 0 0.2 --out $FD/vit/scurves

mkdir -p $FD/drc/g1 $FD/resnet/base $FD/vit/base
for r in novalue11g1.s1234 novalue11g1.s9012 novalue11g1.s3456e; do
  run uv run python scripts/decode_h1_drc.py /workspace/data/runs/$r --episodes 50000 --out $FD/drc/g1/$r.npz
done
for r in resnet11nvg1.s1234 resnet11nvg1.s2468 resnet11nvg1.s3456; do
  run uv run python scripts/decode_h1_drc.py /workspace/data/runs/$r --episodes 50000 --out $FD/resnet/base/$r.npz
done
run uv run python scripts/decode_h1_drc.py /workspace/data/runs/vit11nvg1.s9012 --episodes 50000 --out $FD/vit/base/vit11nvg1.s9012.npz
echo ALL_DONE >> $S
