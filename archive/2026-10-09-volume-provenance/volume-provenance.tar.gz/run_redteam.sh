#!/usr/bin/env bash
set -uo pipefail
export PYTHONPATH=/workspace/gm-plan PYTHONUNBUFFERED=1 XLA_PYTHON_CLIENT_PREALLOCATE=false
export XLA_PYTHON_CLIENT_MEM_FRACTION=0.2
PY=/workspace/GoalMisgeneralisation/.venv/bin/python
OUT=/workspace/data/offline/results
D=/workspace/data/offline/demos
R=/workspace/data/offline/runs
cd /workspace/gm-plan
ARMS="plan route erase erase_start erase_tail erase_other sham self shuffled random"

# The model the +7.4 was measured on, at the depth it was measured at.
echo "=== redteam bc11.rho050.s1 $(date -u +%H:%M:%S) ==="
$PY experiments/030_bc_rewrite_the_plan.py $R/bc11.rho050.s1 --demos $D/test.rho050 \
    --depths 3 --arms $ARMS --alphas 0.0 0.05 0.1 0.2 0.4 \
    --json $OUT/offline-bc-redteam.bc11.rho050.s1.json \
    > $OUT/offline-bc-redteam.bc11.rho050.s1.txt 2>&1
echo "exit $? at $(date -u +%H:%M:%S)"

echo "=== redteam bcnv11.s1 $(date -u +%H:%M:%S) ==="
$PY experiments/030_bc_rewrite_the_plan.py $R/bcnv11.s1 --demos $D/test.rho100 \
    --depths 3 --arms $ARMS --alphas 0.0 0.05 0.1 0.2 0.4 \
    --json $OUT/offline-bc-redteam.bcnv11.s1.json \
    > $OUT/offline-bc-redteam.bcnv11.s1.txt 2>&1
echo "exit $? at $(date -u +%H:%M:%S)"
echo REDTEAMDONE
