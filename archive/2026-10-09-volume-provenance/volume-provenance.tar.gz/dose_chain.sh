#!/usr/bin/env bash
# usage: dose_chain.sh <tag> <base>...   (bases prefixed bc: use the offline script)
set -uo pipefail
TAG=$1; shift
cd /workspace/GoalMisgeneralisation
export PATH="$HOME/.local/bin:$PATH"
export JAX_COMPILATION_CACHE_DIR=/workspace/data/jax-cache
mkdir -p /workspace/data/logs/dose figures/data/restricted results
LOG=/workspace/data/logs/dose/$TAG.log
DOSES="0.5 1 2 4 8"
for base in "$@"; do
  echo "=== $base $(date -u +%H:%M) ===" >> $LOG
  if [[ $base == bc* ]]; then
    uv run python scripts/restricted_writes_bc.py /workspace/data/offline/runs/$base --demos /workspace/data/offline/demos/test.rho100 \
        --doses $DOSES --json figures/data/restricted/$base.dose.json > results/dose-$base.o1.txt 2> /workspace/data/logs/dose/$base.err \
        && echo "$base ok" >> $LOG || echo "$base FAILED" >> $LOG
  else
    uv run python scripts/restricted_writes.py /workspace/data/runs/$base --levels /workspace/data/levels/values/1.00-0.50@500k \
        --doses $DOSES --json figures/data/restricted/$base.dose.json > results/dose-$base.o1.txt 2> /workspace/data/logs/dose/$base.err \
        && echo "$base ok" >> $LOG || echo "$base FAILED" >> $LOG
  fi
done
mkdir -p /workspace/data/figures-data/restricted && cp figures/data/restricted/*.dose.json /workspace/data/figures-data/restricted/ 2>/dev/null
echo DOSE_DONE >> $LOG
