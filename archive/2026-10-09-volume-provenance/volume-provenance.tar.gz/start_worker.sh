#!/bin/bash
# start_worker.sh : wait for any running edit_chain on this pod, then run the queue worker.
for pid in $(ps aux | grep "[/]workspace/edit_chain.sh" | awk '{print $2}'); do while kill -0 $pid 2>/dev/null; do sleep 30; done; done
for pid in $(ps aux | grep "[w]ait_g_e3.sh" | awk '{print $2}'); do while kill -0 $pid 2>/dev/null; do sleep 30; done; done
/workspace/edit_worker.sh /workspace/matrix.jobs
