set -euo pipefail
export PATH=$HOME/.local/bin:$PATH
cd /workspace/GoalMisgeneralisation
LOG=/workspace/data/steering-sanity.txt
: > "$LOG"
echo "### does the intervention reach the network at all?" | tee -a "$LOG"
uv run python experiments/007_steer_distance.py \
    /workspace/data/runs/clean11fv/local-files/cp_140206080 \
    --levels /workspace/data/levels11 --episodes 512 --alphas -200 -50 0 50 200 2>&1 \
    | grep -viE "userwarning|logger\.warn|gym\.logger|^\s*$" | tee -a "$LOG"
echo "DONESANITY" | tee -a "$LOG"
