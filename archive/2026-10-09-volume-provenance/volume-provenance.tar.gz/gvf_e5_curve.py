import sys, pandas as pd
cols_want = ["charts/0/returned_avg_episode_success", "charts/0/returned_avg_episode_return"]
frames = {n: pd.read_csv(f"/workspace/data/runs/{n}/metrics.csv", index_col=0) for n in sys.argv[1:]}
for n, f in frames.items():
    ent = [c for c in f.columns if "entropy" in c.lower()]
    ev = [c for c in f.columns if c.startswith("rho") or "valid" in c or "eval" in c.lower()][:6]
    print(n, "last step", int(f.index.max()), "entropy col", ent[:2], "eval cols", ev)
marks = [0.5e6, 1e6, 2e6, 5e6, 10e6, 20e6, 30e6, 40e6, 50e6, 60e6, 80e6, 100e6, 120e6, 150e6]
for s in marks:
    line = f"{s/1e6:>6.1f}M"
    for n, f in frames.items():
        ent = [c for c in f.columns if "entropy" in c.lower()][:1]
        w = f[(f.index >= s - 1e6) & (f.index <= s + 1e6)]
        if len(w) == 0:
            continue
        vals = [w[c].mean() for c in cols_want + ent]
        line += f" | {n[:14]} succ {vals[0]:.3f} ret {vals[1]:+.3f}" + (f" ent {vals[2]:.3f}" if ent else "")
    print(line)
