#!/bin/bash
# Replicate sweeps (r2, r3) for the even o1 grid on ResNet and ViT, then measure.
set -uo pipefail
export PATH=/root/.local/bin:$PATH
cd /workspace/GoalMisgeneralisation
UV=/root/.local/bin/uv
# wait for the s9012 measure to release the GPU

for agent in resnet11novalue.s1234-cp130M vit11novalue.s1234; do
  for r in 2 3; do
    echo "=== sweep $agent r$r"
    $UV run python scripts/value_axis_sweep.py --agent "$agent" --objectives 1 \
      --offsets 0.1 0.2 0.3 0.4 --steps 400000 --replicate "$r" || echo "SWEEP_FAILED $agent r$r"
  done
done
for agent in resnet11novalue.s1234-cp130M vit11novalue.s1234; do
  cp=$(python3 -c "import json;print(json.load(open('/workspace/data/runs/$agent/BASE.json'))['checkpoint'])")
  for r in 2 3; do
    echo "=== measure $agent r$r"
    $UV run python experiments/014_value_axis_analysis.py \
      --base "/workspace/data/runs/$agent/$cp" --arms "/workspace/data/runs/$agent/arms" \
      --levels /workspace/data/levels/values/1.00-0.50@500k --prefix o1 --base-value 0.5 \
      --arm-steps 400000 --at -1 --replicate "$r" \
      > "results/arch-swap-value-axis-$agent-o1.r$r.txt" 2> "results/arch-swap-value-axis-$agent-o1.r$r.err" \
      || echo "MEASURE_FAILED $agent r$r"
  done
done
echo REPLICATES_DONE
