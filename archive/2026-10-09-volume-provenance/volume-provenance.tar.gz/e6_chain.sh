#!/bin/bash
# E6: far-dose decodes for the three DRC g1 bases in parallel from a frozen snapshot, then the report.
#   nohup bash /workspace/e6_chain.sh > /dev/null 2>&1 &
set -uo pipefail
ulimit -n $(ulimit -Hn)
export PYTHONUNBUFFERED=1 XLA_PYTHON_CLIENT_PREALLOCATE=false JAX_COMPILATION_CACHE_DIR=/workspace/data/jax-cache
SNAP=/workspace/gvf-e6-snap
cd $SNAP
PY=$SNAP/.venv/bin/python
LV=/workspace/data/levels/values/1.00-0.50@500k
DATA=/workspace/data/figures-data/axis-far-dose
REPO=/workspace/GoalMisgeneralisation
LOG=/workspace/data/logs/gvf
mkdir -p $LOG $DATA $REPO/results/gain-vs-factorised
say() { echo "[$(date -u +%H:%M:%S)] $*" >> $LOG/e6.log; }
BASES="novalue11g1.s1234 novalue11g1.s9012 novalue11g1.s3456e"
say "E6 start from $SNAP"
for b in $BASES; do
  ( $PY scripts/axis_far_dose.py /workspace/data/runs/$b --levels $LV --split test --out $DATA/$b \
      --sweep o1 --arm-steps 400000 --fit-window 0.45 --episodes 16384 --coarse-episodes 4096 --num-envs 128 --seed 0 \
      > $LOG/e6-$b.log 2>&1; say "decode $b exit $?" ) &
done
wait
for b in $BASES; do grep -q FAR_DOSE_DONE $LOG/e6-$b.log || say "decode $b did not finish"; done
$PY scripts/axis_far_dose_report.py $(for b in $BASES; do echo $DATA/$b; done) --resamples 200 \
  --txt $REPO/results/gain-vs-factorised/axis-far-dose.txt --json $DATA/axis_far_dose.json > $LOG/e6-report.log 2>&1
say "report exit $?"
say "E6_DONE"
