#!/bin/bash
# E7: the direction (rotation) edit against the gain edit, per architecture.
#   nohup bash /workspace/e7_chain.sh A > /dev/null 2>&1 &
set -uo pipefail
ulimit -n $(ulimit -Hn)
export PYTHONUNBUFFERED=1 XLA_PYTHON_CLIENT_PREALLOCATE=false JAX_COMPILATION_CACHE_DIR=/workspace/data/jax-cache
SNAP=/workspace/gvf-e7-snap
cd $SNAP
PY=/workspace/GoalMisgeneralisation/.venv/bin/python
DATA=/workspace/data
LV=$DATA/levels/values/1.00-0.50@500k
REPO=/workspace/GoalMisgeneralisation
OUT=$REPO/figures/data/gain_vs_factorised/e7
RES=$REPO/results/gain-vs-factorised
LOG=$DATA/logs/gvf
mkdir -p $OUT $RES $LOG
CHAIN=$1
L=$LOG/e7-$CHAIN.log
say() { echo "[$(date -u +%H:%M:%S)] $*" >> $L; }

# One search. Every default that matters is pinned, because another session edits these scripts.
edit() {  # edit <tag> <run> <family> [extra args...]
  local tag=$1 run=$2 family=$3; shift 3
  say "edit $tag: family $family"
  timeout 5400 $PY scripts/cheapest_edit.py $run --family $family --target soft --rule threshold \
    --seeds 0 1 --steps 400 --batch 32 --lr 3e-2 --l2 1e-3 --optimizer adam \
    --shifts -4 -2 2 4 --eval-shifts -8 -6 -4 -2 2 4 6 8 --sweep o1 --fit-window 0.45 \
    --json $OUT/$tag.$family.json --save-deltas $OUT/$tag.$family.npz "$@" \
    > $RES/e7-edit-$tag.$family.txt 2> $LOG/e7-edit-$tag.$family.err \
    && say "edit $tag $family ok" || say "edit $tag $family FAILED"
}

profile() {  # profile <tag> <run> [extra args...]
  local tag=$1 run=$2; shift 2
  say "profile $tag"
  timeout 3600 $PY scripts/direction_profile.py $run --n-levels 256 --json $OUT/$tag.profile.json "$@" \
    > $RES/e7-profile-$tag.txt 2> $LOG/e7-profile-$tag.err \
    && say "profile $tag ok" || say "profile $tag FAILED"
}

RL_EDIT="--levels $LV --n-edit 4096 --n-eval 2048 --arm-steps 400000"
BC_EDIT="--offline --demos $DATA/offline/demos --n-edit 4096 --n-eval 2048 --steps-tag 1000"

if [ "$CHAIN" = "A" ]; then
  # The prediction: a turn works where a gain does not.
  edit vit11nvg1.s9012   $DATA/runs/vit11nvg1.s9012      rotation $RL_EDIT
  edit bcnv11.s1         $DATA/offline/runs/bcnv11.s1    rotation $BC_EDIT
  edit vit11nvg1.s9012   $DATA/runs/vit11nvg1.s9012      gain     $RL_EDIT
  edit bcnv11.s1         $DATA/offline/runs/bcnv11.s1    gain     $BC_EDIT
  profile vit11nvg1.s9012 $DATA/runs/vit11nvg1.s9012 --levels $LV
  profile bcnv11.s1       $DATA/offline/runs/bcnv11.s1 --offline --demos $DATA/offline/demos --steps-tag 1000
  edit bcnv11.s2         $DATA/offline/runs/bcnv11.s2    rotation $BC_EDIT
else
  # The controls: architectures where the gain already works.
  edit novalue11g1.s1234 $DATA/runs/novalue11g1.s1234    rotation $RL_EDIT
  edit resnet11nvg1.s1234 $DATA/runs/resnet11nvg1.s1234  rotation $RL_EDIT
  edit resnet11nvg1.s2468 $DATA/runs/resnet11nvg1.s2468  rotation $RL_EDIT
  profile novalue11g1.s1234 $DATA/runs/novalue11g1.s1234 --levels $LV
  profile resnet11nvg1.s1234 $DATA/runs/resnet11nvg1.s1234 --levels $LV
  edit resnet11nvg1.s1234 $DATA/runs/resnet11nvg1.s1234  gain     $RL_EDIT
fi
say "E7_CHAIN_DONE $CHAIN"
