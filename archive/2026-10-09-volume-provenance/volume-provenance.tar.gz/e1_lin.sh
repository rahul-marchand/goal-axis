#!/bin/bash
# E1 linearised profile (offset 0.03, no mediation). Usage: e1_lin.sh BASE...
export XLA_PYTHON_CLIENT_PREALLOCATE=false
export PYTHONUNBUFFERED=1
ulimit -n $(ulimit -Hn)
cd /workspace/GoalMisgeneralisation
LOG=/workspace/data/logs/gvf; mkdir -p $LOG results/gain-vs-factorised /workspace/data/figures-data/gain_alignment
LV=/workspace/data/levels/values/1.00-0.50@500k
for b in "$@"; do
  uv run --no-sync python scripts/gain_alignment.py /workspace/data/runs/$b --levels $LV --offset 0.03 \
    --match-gains 0.02 0.05 0.1 0.15 --mediate \
    --json /workspace/data/figures-data/gain_alignment/$b.lin.json \
    > results/gain-vs-factorised/gain-alignment-lin-$b.txt 2> $LOG/e1-lin-$b.err
  echo "$(date -u) lin $b exit $?" >> $LOG/e1.log
done
echo "E1_LIN_DONE" >> $LOG/e1.log
