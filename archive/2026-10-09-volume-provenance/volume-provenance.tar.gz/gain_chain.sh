#!/bin/bash
# Brightness / input-gain sweep. Usage: gain_chain.sh A|B
export XLA_PYTHON_CLIENT_PREALLOCATE=false
ulimit -n $(ulimit -Hn)
cd /workspace/GoalMisgeneralisation
LOG=/workspace/data/logs/gain; mkdir -p $LOG results figures/data/input_gain
LV=/workspace/data/levels/values/1.00-0.50@500k
CHAIN=$1
rl() { uv run --no-sync python scripts/input_gain.py /workspace/data/runs/$1 --levels $LV --json figures/data/input_gain/$1.json > results/input-gain-$1.txt 2> results/input-gain-$1.err; echo "$1 exit $?" >> $LOG/$CHAIN.log; }
bc() { uv run --no-sync python scripts/input_gain_bc.py /workspace/data/offline/runs/$1 --demos /workspace/data/offline/demos/test.rho100 --json figures/data/input_gain/$1.json > results/input-gain-$1.txt 2> results/input-gain-$1.err; echo "$1 exit $?" >> $LOG/$CHAIN.log; }
if [ "$CHAIN" = A ]; then
  for r in novalue11g1.s1234 novalue11g1.s9012 novalue11g1.s3456e vit11nvg1.s9012 vit11nvg1.s1234 vit11nvg1lr.s1234; do rl $r; done
else
  for r in resnet11nvg1.s1234 resnet11nvg1.s2468 resnet11nvg1.s3456; do rl $r; done
  for r in bcnv11.s1 bcnv11.s2 bcnv11.s3; do bc $r; done
fi
echo GAIN_DONE >> $LOG/$CHAIN.log
