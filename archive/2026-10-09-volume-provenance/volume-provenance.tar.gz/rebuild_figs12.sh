#!/bin/bash
# Rebuild the basin and planning figure data on the undiscounted DRC.
set -u
export PATH=$HOME/.local/bin:$PATH
export PYTHONUNBUFFERED=1
export JAX_COMPILATION_CACHE_DIR=/workspace/data/jax-cache
cd /workspace/GoalMisgeneralisation
UV=$HOME/.local/bin/uv
AGENT=/workspace/data/runs/novalue11g1.s1234
LEVELS=/workspace/data/levels/values/1.00-0.50@1M
OUT=/workspace/data/figures-data/drc/basin-g1

echo "=== basin: axis fit + rollouts on the g1 DRC"
for seed in 9645 20329 8280 5767 38721; do
  $UV run python scripts/basin_map.py --agent "$AGENT" --sweep o1 --arm-steps 400000 \
    --level-seed $seed --alphas -0.6 0.6 31 --out "$OUT" \
    >> /workspace/data/logs/g1/basin-g1.log 2>&1 || echo "BASIN_FAILED seed $seed"
done

echo "=== plan probe on the g1 DRC"
CP=$(python3 -c "import json;print(json.load(open('$AGENT/BASE.json'))['checkpoint'])")
$UV run python experiments/003_probe_plan.py "$AGENT/$CP" --levels "$LEVELS" --split test \
  --think 0 4 --test-correlations 1.0 > results/g1-probe-plan-novalue11g1.s1234.txt 2>&1 \
  || echo "PROBE_FAILED"
$UV run python scripts/plan_heatmap.py "$AGENT/$CP" --levels "$LEVELS" --split test \
  --examples 48 --think 0 1 2 4 --out /workspace/data/figures-data/plan-probes/plan.novalue11g1.s1234.npz \
  >> /workspace/data/logs/g1/planheat-g1.log 2>&1 || echo "HEATMAP_FAILED"
echo FIGS12_DONE
