"""Exact drift / axis / residual decomposition, without assuming orthogonality.

The table in the note was derived by Pythagoras: residual = sqrt(|dtheta|^2 -
|drift|^2 - offset^2 |axis|^2). That is only the residual if the three parts are
mutually orthogonal in weight space, which the least-squares fit does not
guarantee -- it orthogonalises in arm-index space, not here. This computes the
residual as the vector it actually is and reports the cosines, so the shares in
the note are either confirmed or replaced.
"""
import importlib.util, sys
from pathlib import Path
import numpy as np

sys.argv = ["decomp"]
spec = importlib.util.spec_from_file_location("g", "/workspace/GoalMisgeneralisation/experiments/015_value_or_gap.py")
g = importlib.util.module_from_spec(spec); spec.loader.exec_module(g)
from jax.flatten_util import ravel_pytree
from cleanba.cleanba_impala import load_train_state

import argparse
ns = argparse.Namespace(levels=Path(sys.argv[1] if len(sys.argv) > 1 else "/workspace/data/valueaxis/levels/v050"),
                        objective_values=None, num_envs=1, seed=0, size=11)
cfg = g.eval_config(argparse.Namespace(**{**vars(ns)}))
_, _, _, base_state, _ = load_train_state(Path("/workspace/data/runs/novalue11/local-files/cp_140206080"), env_cfg=cfg)
base_flat, _ = ravel_pytree(base_state.params)

arms = g.load_sweep(Path("/workspace/data/valueaxis/runs"), "v", -1, 0.5, base_flat, cfg)
vals = np.array(sorted(arms))
offs = vals - 0.5
D = np.stack([arms[v] for v in vals])
# Fit exactly as 015 does -- the null arm is excluded, so its decomposition
# below is out of sample, which is the honest way to read it anyway.
keep = np.abs(offs) > 1e-9
axis, drift = g.fit_axis_and_drift(offs[keep], D[keep])

na, nd = np.linalg.norm(axis), np.linalg.norm(drift)
print(f"\n|axis| {na:.3f}   |drift| {nd:.3f}   cos(drift, axis) = {float(drift @ axis / (na*nd)):+.4f}\n")
print(f"{'offset':>7} {'|dtheta|':>9} {'|eps| true':>11} {'|eps| pythag':>13} {'cos(eps,drift)':>15} {'cos(eps,axis)':>14}")
for off, d in zip(offs, D):
    eps = d - drift - off * axis
    ne, nm = np.linalg.norm(eps), np.linalg.norm(d)
    pyth = np.sqrt(max(nm**2 - (off*na)**2 - nd**2, 0))
    print(f"{off:>+7.2f} {nm:>9.3f} {ne:>11.3f} {pyth:>13.3f} "
          f"{float(eps@drift/(ne*nd)):>+15.4f} {float(eps@axis/(ne*na)):>+14.4f}")
print(f"\n{'offset':>7} {'drift%':>8} {'axis%':>8} {'eps%':>8} {'cross%':>8}")
for off, d in zip(offs, D):
    eps = d - drift - off * axis
    tot = float(d @ d)
    print(f"{off:>+7.2f} {nd**2/tot:>7.0%} {(off*na)**2/tot:>8.0%} {float(eps@eps)/tot:>8.0%} "
          f"{1 - (nd**2 + (off*na)**2 + float(eps@eps))/tot:>+8.0%}")
