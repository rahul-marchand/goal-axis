#!/bin/bash
# E4 re-run: all four edit families with the target pinned (soft), from a frozen code snapshot, then collateral.
#   nohup bash /workspace/e4_rerun.sh novalue11g1.s1234 > /dev/null 2>&1 &
set -uo pipefail
ulimit -n $(ulimit -Hn)
export PYTHONUNBUFFERED=1 XLA_PYTHON_CLIENT_PREALLOCATE=false JAX_COMPILATION_CACHE_DIR=/workspace/data/jax-cache
SNAP=/workspace/gvf-e4-snap
cd $SNAP
BASE=$1
PY=/workspace/GoalMisgeneralisation/.venv/bin/python
DATA=/workspace/data; RUN=$DATA/runs/$BASE; LV=$DATA/levels/values/1.00-0.50@500k
REPO=/workspace/GoalMisgeneralisation
OUT=$REPO/figures/data/gain_vs_factorised/e4; RES=$REPO/results/gain-vs-factorised; LOG=$DATA/logs/gvf
mkdir -p $OUT/stale-mixed-target
L=$LOG/e4r-$BASE.log
say() { echo "[$(date -u +%H:%M:%S)] $*" >> $L; }
say "=== $BASE re-run from $SNAP, target soft"
mv $OUT/$BASE.*.json $OUT/$BASE.*.npz $OUT/stale-mixed-target/ 2>/dev/null
edit() { local name=$1; shift
  say "edit $name: $*"
  $PY scripts/cheapest_edit.py $RUN --levels $LV --family dense --target soft --seeds 0 1 --steps 400 \
    --shifts -4 -2 2 4 --eval-shifts -4 -2 2 4 --json $OUT/$BASE.$name.json --save-deltas $OUT/$BASE.$name.npz "$@" \
    > $RES/e4-edit-$BASE.$name.txt 2> $LOG/e4r-edit-$BASE.$name.err \
    && say "edit $name ok" || say "edit $name FAILED"
}
edit readout --modules dense heads
edit late --modules "cell 2 input" "cell 2 recurrent" dense heads
edit input --modules "input conv"
edit all
say "collateral"
arms=()
for arm in o1-030 o1-020 o1+020 o1+030; do arms+=("frozen/$arm=$RUN/arms-frozen/$arm@400k" "free/$arm=$RUN/arms/$arm@400k"); done
deltas=()
for n in readout late input all; do [ -f $OUT/$BASE.$n.npz ] && deltas+=("$n=$OUT/$BASE.$n.npz"); done
$PY scripts/edit_collateral.py $RUN --levels $LV --deltas "${deltas[@]}" --axis-from all --arms "${arms[@]}" \
  --json $OUT/$BASE.collateral.json > $RES/e4-collateral-$BASE.txt 2> $LOG/e4r-collateral-$BASE.err \
  && say "collateral ok" || say "collateral FAILED"
say "E4R_DONE $BASE"
