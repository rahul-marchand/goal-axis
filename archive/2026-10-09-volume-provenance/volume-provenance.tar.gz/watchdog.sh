#!/bin/bash
# Watches the clean11fv training run and records what happened, so a session
# that restarts overnight can pick the story up from a file rather than from
# memory. Deliberately does not restart anything: the documented failure mode
# is a *hang* on the evaluation thread, and relaunching a 10-hour run
# automatically is more likely to waste the GPU than to save it.
RUN=clean11fv
LOG=/workspace/data/runs/$RUN.log
STATUS=/workspace/data/runs/$RUN.status
STALL_SECONDS=1500

say () { echo "$(date -u '+%Y-%m-%d %H:%M:%S') $*" >> "$STATUS"; }

say "watchdog started"
last_size=0
last_change=$(date +%s)
stalled=no

while true; do
    sleep 120
    size=$(stat -c %s "$LOG" 2>/dev/null || echo 0)
    now=$(date +%s)

    if [ "$size" -ne "$last_size" ]; then
        last_size=$size
        last_change=$now
        if [ "$stalled" = yes ]; then
            say "RECOVERED - log is growing again"
            stalled=no
        fi
    fi

    if ! pgrep -f "001_maze_repro.py" > /dev/null; then
        if grep -q "RUN COMPLETE" "$LOG" 2>/dev/null; then
            say "DONE - run finished cleanly"
        else
            say "CRASHED - process gone without RUN COMPLETE. Last 60 lines:"
            tail -60 "$LOG" >> "$STATUS"
        fi
        exit 0
    fi

    if [ "$stalled" = no ] && [ $((now - last_change)) -gt "$STALL_SECONDS" ]; then
        stalled=yes
        say "STALLED - no log output for $((now - last_change))s but the process is alive."
        say "This is the signature of an exception on the evaluation thread. Last 60 lines:"
        tail -60 "$LOG" >> "$STATUS"
        say "GPU: $(nvidia-smi --query-gpu=utilization.gpu,memory.used --format=csv,noheader)"
    fi

    # Hourly heartbeat with the most recent progress line.
    if [ $(( $(date +%s) % 3600 )) -lt 120 ]; then
        say "alive - $(grep -oE 'learner_policy_version [0-9]+' "$LOG" | tail -1)"
    fi
done
