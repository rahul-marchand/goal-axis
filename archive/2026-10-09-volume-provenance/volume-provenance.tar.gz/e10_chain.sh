#!/bin/bash
# E10: the instrument control. Run the study's gain tests on knobs that are not a gain.
#   nohup bash /workspace/e10_chain.sh novalue11g1.s1234 rotation > /dev/null 2>&1 &
# Arg 2 "rotation" means a rotation json already exists; "search-rotation" means search one first.
set -uo pipefail
ulimit -n $(ulimit -Hn)
export PYTHONUNBUFFERED=1 XLA_PYTHON_CLIENT_PREALLOCATE=false JAX_COMPILATION_CACHE_DIR=/workspace/data/jax-cache

SNAP=/workspace/gvf-e10-snap
BASE=$1
ROT_MODE=${2:-rotation}
PY=/workspace/GoalMisgeneralisation/.venv/bin/python
DATA=/workspace/data
RUN=$DATA/runs/$BASE
LV=$DATA/levels/values/1.00-0.50@500k
REPO=/workspace/GoalMisgeneralisation
E4=$REPO/figures/data/gain_vs_factorised/e4
E7=$REPO/figures/data/gain_vs_factorised/e7
OUT=$DATA/figures-data/gain-vs-factorised
RES=$REPO/results/gain-vs-factorised
LOG=$DATA/logs/gvf
mkdir -p "$OUT" "$RES" "$LOG" "$DATA/figures-data/control"
L=$LOG/e10-$BASE.log
say() { echo "[$(date -u +%H:%M:%S)] $*" >> "$L"; }

cd $SNAP
say "=== $BASE start (snapshot $SNAP) ==="

# 1. The contingent distractor: trained to move the threshold up where the richer
#    objective is above the agent and down where it is below. No saved delta exists.
CONT=$OUT/contingent-$BASE.npz
if [ ! -f "$CONT" ]; then
  say "contingent search"
  $PY scripts/cheapest_edit.py "$RUN" --levels "$LV" --family dense --target soft --rule contingent \
      --seeds 0 1 --steps 400 --shifts -4 -2 2 4 --eval-shifts -4 -2 2 4 \
      --json $OUT/contingent-$BASE.json --save-deltas "$CONT" \
      > $RES/e10-contingent-$BASE.txt 2> $LOG/e10-contingent-$BASE.err \
      && say "contingent ok" || { say "contingent FAILED"; }
else
  say "contingent already there"
fi

# 2. A rotation for this base, if E7 did not leave one.
ROT=$E7/$BASE.rotation.json
if [ "$ROT_MODE" = "search-rotation" ] && [ ! -f "$ROT" ]; then
  ROT=$OUT/rotation-$BASE.json
  if [ ! -f "$ROT" ]; then
    say "rotation search"
    $PY scripts/cheapest_edit.py "$RUN" --levels "$LV" --family rotation --target soft \
        --seeds 0 1 --steps 400 --shifts -4 -2 2 4 --eval-shifts -4 -2 2 4 \
        --json "$ROT" --save-deltas $OUT/rotation-$BASE.npz \
        > $RES/e10-rotation-$BASE.txt 2> $LOG/e10-rotation-$BASE.err \
        && say "rotation ok" || { say "rotation FAILED"; ROT=""; }
  fi
fi
[ -f "$ROT" ] || ROT=""

# 3. Scale every knob to the axis's own threshold shift, and read the behavioural table.
PAIRS=$DATA/figures-data/control/$BASE.npz
EDITS="late=$E4/$BASE.late.npz:seed0 readout=$E4/$BASE.readout.npz:seed0"
[ -f "$CONT" ] && EDITS="$EDITS contingent=$CONT:seed0"
say "matching: $EDITS ${ROT:+rotation=$ROT}"
$PY scripts/control_writes.py "$RUN" --levels "$LV" --edits $EDITS --split-match contingent --rounds 3 \
    ${ROT:+--rotation "$ROT"} --pairs "$PAIRS" --json $OUT/control-$BASE.json \
    > $RES/e10-control-$BASE.txt 2> $LOG/e10-control-$BASE.err \
    && say "matching ok" || { say "matching FAILED"; echo "E10_DONE $BASE" >> "$L"; exit 1; }

# 4. Test 1: the gain-alignment profile and the mediation patch, on every knob.
say "gain alignment"
$PY scripts/gain_alignment.py "$RUN" --levels "$LV" --extra-writes "$PAIRS" \
    --mediate "full axis" "brightness colour 1, tau-matched" late contingent \
    --json $OUT/gain-align-control-$BASE.json \
    > $RES/e10-gain-align-$BASE.txt 2> $LOG/e10-gain-align-$BASE.err \
    && say "gain alignment ok" || say "gain alignment FAILED"

# 5. Test 2: the object-removal share, on every knob.
say "leftover"
$PY scripts/leftover_patch.py "$RUN" --levels "$LV" --extra-writes "$PAIRS" --parts leftover \
    --mediate "full axis" "random, module-matched" late contingent \
    --json $OUT/leftover-control-$BASE.json \
    > $RES/e10-leftover-$BASE.txt 2> $LOG/e10-leftover-$BASE.err \
    && say "leftover ok" || say "leftover FAILED"

say "E10_DONE $BASE"
echo "E10_DONE $BASE" >> "$L"
