#!/bin/bash
# After the stage-4 base finishes: one DAgger pass on 5000 training fields with the
# guard, a 12k-step continuation on pool + visited states (cxcraft15.s1d), then that
# model's arms and analysis. Runs beside the plain base's chain on the other pod.
set -u
export PATH=$HOME/.local/bin:$PATH UV_PROJECT_ENVIRONMENT=/root/venv-control UV_CACHE_DIR=/root/.cache/uv UV_NO_SYNC=1 PYTHONUNBUFFERED=1 XLA_PYTHON_CLIENT_PREALLOCATE=false
cd /workspace/gm-control
D=/workspace/data/craftax/craft; R=$D/runs; LOGS=/workspace/data/logs/craftax
until [ -f $R/cxcraft15.s1/done.json ]; do sleep 120; done
git pull -q origin craftax 2>&1 | tail -1
echo "$(date -u +%FT%TZ) base done; collecting"
[ -f $D/demos-rh/dagger.s1/meta.json ] || uv run python scripts/craft_dagger.py $R/cxcraft15.s1 $D/demos-rh/train.rho100 --fields 5000 --start 900000 --guard --states-per-route 8 --out $D/demos-rh/dagger.s1 > $LOGS/dagger.s1.collect.log 2>&1 || { echo "DAGGER_COLLECT_FAILED"; exit 1; }
tail -4 $LOGS/dagger.s1.collect.log
if [ ! -f $R/cxcraft15.s1d/done.json ]; then
  uv run python experiments/023_train_bc.py --demos $D/demos-rh/train.rho100 --extra-demos $D/demos-rh/dagger.s1 --extra-fraction 0.33 --hide-values \
    --init-from $R/cxcraft15.s1/checkpoints/step_00060000 --schedule cosine --lr 1e-4 --warmup 200 \
    --eval rho100=$D/demos-rh/valid.rho100 rho050=$D/demos-rh/valid.rho050 rho000=$D/demos-rh/valid.rho000 --eval-levels 512 \
    --out $R/cxcraft15.s1d --seed 21 --steps 24000 --batch-size 128 --checkpoint-first 6000 --checkpoint-ratio 2.0 \
    --note "DAgger continuation of cxcraft15.s1: 24k steps at batch 128, visited states a third of samples, from step 60000 on the suffix pool plus the states the base visited on 5000 training fields (guarded rollouts), labelled by the planner from each state." \
    > $LOGS/cxcraft15.s1d.log 2>&1 || { echo "DAGGER_TRAIN_FAILED"; exit 1; }
fi
grep checkpoint $LOGS/cxcraft15.s1d.log | tail -2
export DEMOS=$D/demos-rh ARM_OFFSETS="0.45 0.3 0.2 0.1"
bash scripts/craft_chain.sh arms cxcraft15.s1d
bash scripts/craft_chain.sh analysis cxcraft15.s1d
echo "DAGGER_ROUND_DONE"
