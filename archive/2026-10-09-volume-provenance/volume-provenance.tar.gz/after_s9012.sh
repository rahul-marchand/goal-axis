#!/bin/bash
# Wait for the running sweep to exit, then produce exactly the files fig13 needs
# for the s9012 panels: the fine-tuned points and the held-out writes, per
# objective. Nothing else -- the three-objective and ladder analyses are
# deliberately not queued here.
set -u
cd /workspace/GoalMisgeneralisation-campaign
export PATH=$HOME/.local/bin:$PATH XLA_PYTHON_CLIENT_PREALLOCATE=false PYTHONUNBUFFERED=1

while pgrep -f "[v]alue_axis_sweep" >/dev/null; do sleep 30; done
echo "sweep exited $(date +%H:%M)"

ARMS=$(ls -d /workspace/data/runs/novalue11.s9012/arms/*/ | wc -l)
echo "arms on disk: ${ARMS}"
if [ "${ARMS}" -lt 40 ]; then
    echo "REFUSING: only ${ARMS} arms, the sweep did not finish -- a partial grid would"
    echo "plot as a complete panel and there is no way to tell from the figure."
    exit 1
fi

BASE=/workspace/data/runs/novalue11.s9012/local-files/cp_149995520
COMMON="--base ${BASE} --arms /workspace/data/runs/novalue11.s9012/arms \
 --levels /workspace/data/levels/values/1.00-0.50@500k --arm-steps 400000 --at 7"

for spec in "o1 0.5" "o0 1.0"; do
    set -- ${spec}; prefix=$1; bv=$2
    for extra in "" "--leave-one-out"; do
        suffix=""; [ -n "${extra}" ] && suffix="-heldout"
        out="/workspace/results/wide-novalue11.s9012-${prefix}${suffix}.txt"
        echo "=== ${out} ==="
        uv run python experiments/014_value_axis_analysis.py ${COMMON} \
            --prefix "${prefix}" --base-value "${bv}" ${extra} > "${out}" 2>&1 \
            && echo "  ok" || echo "  FAILED"
    done
done
echo "ALL DONE $(date +%H:%M)"
