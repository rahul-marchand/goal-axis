#!/bin/bash
# Waits for the stage-2 seed-1 chain (arms + analysis on the 20k base) to finish, then
# continues the base for 40k more steps as cxnv15.s1c and runs its arms + analysis.
set -u
export PATH=$HOME/.local/bin:$PATH UV_NO_SYNC=1 PYTHONUNBUFFERED=1 XLA_PYTHON_CLIENT_PREALLOCATE=false
cd /workspace/gm-craftax
until grep -q "CRAFTAX_SEED_DONE\|CRAFTAX_SEED_FAILED" /workspace/data/logs/craftax/seed1.log; do sleep 60; done
D=/workspace/data/craftax; R=$D/runs; L=$D/logs 2>/dev/null; LOGS=/workspace/data/logs/craftax
if [ ! -f $R/cxnv15.s1c/done.json ]; then
  uv run python experiments/023_train_bc.py --demos $D/demos/train.rho100 --hide-values \
    --eval rho100=$D/demos/valid.rho100 rho050=$D/demos/valid.rho050 rho000=$D/demos/valid.rho000 \
    --init-from $R/cxnv15.s1/checkpoints/step_00020000 --schedule cosine --lr 3e-4 --warmup 500 \
    --out $R/cxnv15.s1c --seed 11 --steps 40000 --eval-levels 512 --checkpoint-ratio 2.0 \
    --note "Continuation of cxnv15.s1 (54% reached at 20k): 40k more steps, fresh cosine at 3e-4, from step 20000." \
    > $LOGS/cxnv15.s1c.log 2>&1 || { echo "CONTINUE_FAILED"; exit 1; }
fi
ARM_OFFSETS="0.45 0.3 0.2 0.1" bash scripts/craftax_chain.sh arms cxnv15.s1c
ARM_OFFSETS="0.45 0.3 0.2 0.1" bash scripts/craftax_chain.sh analysis cxnv15.s1c
echo "CONTINUE_DONE"
