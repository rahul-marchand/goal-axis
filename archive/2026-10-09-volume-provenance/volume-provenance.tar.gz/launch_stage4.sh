#!/bin/bash
# Waits on the volume for the receding-horizon pool (generated on pod 1), then
# runs the stage-4 chain for seed 1. Self-contained: needs no other session.
set -u
export PATH=$HOME/.local/bin:$PATH
cd /workspace/gm-craft
D=/workspace/data/craftax/craft/demos-rh
until [ -f $D/train.rho100/meta.json ] && [ -f $D/test.rho100/meta.json ] && [ "$(ls $D/arms 2>/dev/null | wc -l)" -ge 34 ] && ! ls $D/arms/*/ 2>/dev/null | grep -q "^$" ; do sleep 120; done
sleep 60  # let the last arm set finish writing
echo "$(date -u +%FT%TZ) pool present, launching"
DEMOS=$D BASE_STEPS=60000 ARM_OFFSETS="0.45 0.3 0.2 0.1" bash scripts/craft_chain.sh seed 1
echo "LAUNCHER_DONE"
