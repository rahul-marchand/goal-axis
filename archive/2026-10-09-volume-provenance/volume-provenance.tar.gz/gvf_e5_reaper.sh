#!/bin/bash
# Delete this pod once the E5 chain has exited (done or failed). Everything it
# writes is on the network volume, so nothing is lost with the container.
export $(tr "\0" "\n" < /proc/1/environ | grep -E "^RUNPOD_(API_KEY|POD_ID)=" | xargs)
while true; do
  n=$(pgrep -fc "scripts/legend_chain.sh" 2>/dev/null | head -1)
  t=$(pgrep -fc "001_maze_repro.py.*legend11g1" 2>/dev/null | head -1)
  [ "${n:-0}" -eq 0 ] && [ "${t:-0}" -eq 0 ] && break
  sleep 300
done
echo "chain gone at $(date -u); tail of chain log:" >> /workspace/data/logs/gvf/e5.reaper.log
tail -5 /workspace/data/logs/gvf/e5.chain.log >> /workspace/data/logs/gvf/e5.reaper.log
sleep 600
echo "deleting pod $RUNPOD_POD_ID at $(date -u)" >> /workspace/data/logs/gvf/e5.reaper.log
runpodctl pod delete "$RUNPOD_POD_ID" >> /workspace/data/logs/gvf/e5.reaper.log 2>&1
