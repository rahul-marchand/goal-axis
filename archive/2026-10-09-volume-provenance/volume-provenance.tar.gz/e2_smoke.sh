#!/bin/bash
mkdir -p /workspace/data/logs/gvf
cd /workspace/GoalMisgeneralisation
ulimit -n $(ulimit -Hn)
export XLA_PYTHON_CLIENT_PREALLOCATE=false
timeout 2400 uv run --no-sync python scripts/plan_invariance.py /workspace/data/runs/novalue11g1.s1234 --levels /workspace/data/levels/values/1.00-0.50@500k --doses -0.3 0.3 --gains 0.5 2.0 --behaviour-episodes 256 --fit-levels 256 --test-levels 256 --ticks 3 --json /workspace/data/logs/gvf/e2-smoke.json > /workspace/data/logs/gvf/e2-smoke.log 2>&1
echo "EXIT $?" >> /workspace/data/logs/gvf/e2-smoke.log
