#!/bin/bash
# Threshold of every colour-keyed k-arm at each saved checkpoint (100k..400k), ResNet + ViT.
ulimit -n $(ulimit -Hn)
cd /workspace/GoalMisgeneralisation
mkdir -p /workspace/data/logs/kladder
run() {  # base family base_value
  for at in 0 1 2 3; do
    out=results/len-$1-$2@400k-at$at.txt
    [ -s "$out" ] && grep -q "fine-tuned" "$out" && continue
    uv run python scripts/arm_thresholds.py /workspace/data/runs/$1 --family $2 --base-value $3 \
      --levels /workspace/data/levels/values/1.00-0.50@500k --arm-steps 400000 --at $at > "$out" 2> "${out%.txt}.err"
  done
}
stream() { for b in "$@"; do run $b k1 0.5; run $b k0 1.0; done; }
stream resnet11nvg1.s1234 resnet11nvg1.s2468 > /workspace/data/logs/kladder/A.log 2>&1 &
stream resnet11nvg1.s3456 vit11nvg1.s9012 > /workspace/data/logs/kladder/B.log 2>&1 &
wait
echo KLADDER_DONE >> /workspace/data/logs/kladder/done.log
