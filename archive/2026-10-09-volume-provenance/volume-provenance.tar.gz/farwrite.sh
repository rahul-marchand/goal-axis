#!/bin/bash
# Appendix: the axis written far past the fitted window, every base, both sweeps.
# RL bases: 014 re-run with a long --extrapolate list -> results/g1-<base>-<sweep>-far.txt
# BC: axis-only writes at the same offsets -> figures-data/bc/extrap_axisonly_far.json
set -u
export PATH=$HOME/.local/bin:$PATH
export PYTHONUNBUFFERED=1
export JAX_COMPILATION_CACHE_DIR=/workspace/data/jax-cache
cd /workspace/GoalMisgeneralisation
UV=$HOME/.local/bin/uv
LEVELS=/workspace/data/levels/values/1.00-0.50@500k
BASES="novalue11g1.s1234 novalue11g1.s9012 novalue11g1.s3456e resnet11nvg1.s1234 resnet11nvg1.s2468 resnet11nvg1.s3456 vit11nvg1.s9012"
# dv = +0.5..+1.0 by 0.1, then 1.2..2.0 by 0.2, then 2.5 3.0 3.5 (mirrored for o0)
O1="1.0 1.1 1.2 1.3 1.4 1.5 1.7 1.9 2.1 2.3 2.5 3.0 3.5 4.0"
O0="0.5 0.4 0.3 0.2 0.1 0.0 -0.2 -0.4 -0.6 -0.8 -1.0 -1.5 -2.0 -2.5"

echo "=== BC far writes (axis-only)"
.venv/bin/python -u /workspace/bc_extrap_far.py || echo "BCFAR_FAILED"

for base in $BASES; do
  cp=$(python3 -c "import json;print(json.load(open('/workspace/data/runs/$base/BASE.json'))['checkpoint'])")
  for spec in "o1:0.5:$O1" "o0:1.0:$O0"; do
    IFS=: read -r prefix bv vals <<< "$spec"
    [ -s "results/g1-$base-$prefix-far.txt" ] && grep -q "calibrated" "results/g1-$base-$prefix-far.txt" && { echo "have $base $prefix"; continue; }
    echo "=== $base $prefix far writes $(date -u +%H:%M)"
    $UV run python experiments/014_value_axis_analysis.py \
      --base "/workspace/data/runs/$base/$cp" --arms "/workspace/data/runs/$base/arms" \
      --levels "$LEVELS" --prefix "$prefix" --base-value "$bv" --arm-steps 400000 --at -1 \
      --extrapolate $vals \
      > "results/g1-$base-$prefix-far.txt" 2> "results/g1-$base-$prefix-far.err" \
      || echo "FARWRITE_FAILED $base $prefix"
  done
done
echo FARWRITE_DONE
