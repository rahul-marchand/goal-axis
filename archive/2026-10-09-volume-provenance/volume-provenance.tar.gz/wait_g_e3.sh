#!/bin/bash
while kill -0 2995 2>/dev/null; do sleep 30; done
/workspace/edit_chain.sh /workspace/g_e3.jobs
