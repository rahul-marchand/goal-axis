#!/bin/bash
# E15: E12's field decomposition on the route models.
set -uo pipefail
ulimit -n $(ulimit -Hn) 2>/dev/null
export PYTHONUNBUFFERED=1 XLA_PYTHON_CLIENT_PREALLOCATE=false JAX_COMPILATION_CACHE_DIR=/workspace/data/jax-cache
SNAP=/workspace/gvf-e15-snap
PY=/workspace/GoalMisgeneralisation/.venv/bin/python
DATA=/workspace/data
REPO=/workspace/GoalMisgeneralisation
OUT=$REPO/results/gain-vs-factorised
JSON=$DATA/figures-data/gain-vs-factorised/e15
LOG=$DATA/logs/gvf
mkdir -p "$OUT" "$JSON" "$LOG"
L=$LOG/e15.log
say() { echo "[$(date -u +%H:%M:%S)] $*" >> $L; }
cd $SNAP

run() {  # run <tag> <rundir> [extra...]
  local tag=$1 rundir=$2; shift 2
  say "$tag start"
  timeout 9000 $PY scripts/route_field_decomp.py "$rundir" --demos $DATA/offline/demos \
    --n-levels 256 --chunk 64 --json $JSON/$tag.json "$@" \
    > $OUT/e15-$tag.txt 2> $LOG/e15-$tag.err \
    && say "$tag ok" || say "$tag FAILED"
  cp -f $OUT/e15-$tag.txt $DATA/figures-data/gain-vs-factorised/ 2>/dev/null
}

say "=== E15 start, snapshot $SNAP"
run d512l4 $DATA/offline/runs/scaling/sc11.d512l4.s1
say "E15_D512_DONE"
run bcnv11.s1 $DATA/offline/runs/bcnv11.s1
say "E15_BCNV_DONE"

# The report, assembled from whatever finished.
{
  echo "# E15: what the route model propagates, and where value enters it"
  echo
  echo "E12's five measurements, run on route models so the two architectures can be read"
  echo "side by side. Erasure is exact here: a colour plane holds a single 1.0 at its"
  echo "objective's cell, so deleting an objective deletes one cell's content."
  echo
  echo "The value manipulation is the fitted axis at +-0.30. Its calibration is objective"
  echo "scaling -- multiplying the poorer objective's own cell -- which is a source change"
  echo "by construction. A route model answers scaling non-monotonically in threshold"
  echo "terms, so it cannot be dose-matched the way E12 matched brightness; it calibrates"
  echo "WHERE a source change lands, not how large the threshold move is."
  echo
  for tag in d512l4 bcnv11.s1; do
    echo "## $tag"
    echo
    if [ -s "$OUT/e15-$tag.txt" ] && grep -q ROUTE_FIELD_DECOMP_DONE "$OUT/e15-$tag.txt"; then
      echo '```'
      cat "$OUT/e15-$tag.txt"
      echo '```'
    else
      echo "Did not produce output; see \`e15-$tag.err\`."
    fi
    echo
  done
  echo "## How to read it"
  echo
  echo "- **combination**: superposition is (1, 1), winner-take-all (1, 0); \`gamma\` is how"
  echo "  much of the further objective survives. The DRC (E12) gave alpha ~0.7, gamma ~0.63."
  echo "- **where value lands**: mass on \`dA_c\` means value rides the objective's own field;"
  echo "  mass on \`dI\` means it acts where the two meet. Read the axis rows against the"
  echo "  \`scale\` rows, which are a source change by construction."
  echo "- **profile**: both fits' R^2 are given, so exponential decay and a cost-subtracted"
  echo "  straight line can be told apart. The \`differ\` columns keep only cells where BFS"
  echo "  and grid distance disagree by 3 or more, which is where routing and blur differ."
  echo "- **bridge**: the threshold on the same levels is printed above each table."
} > $OUT/E15.md
cp -f $OUT/E15.md $DATA/figures-data/gain-vs-factorised/E15.md 2>/dev/null
say "E15_CHAIN_DONE"
