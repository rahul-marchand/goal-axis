#!/bin/bash
# E12: the erasure decomposition, self-sufficient. Writes its own report.
set -uo pipefail
ulimit -n $(ulimit -Hn) 2>/dev/null
export PYTHONUNBUFFERED=1 XLA_PYTHON_CLIENT_PREALLOCATE=false
export JAX_COMPILATION_CACHE_DIR=/workspace/data/jax-cache
SNAP=/workspace/gvf-e12-snap
PY=/workspace/GoalMisgeneralisation/.venv/bin/python
DATA=/workspace/data
LOG=$DATA/logs/gvf
OUT=/workspace/GoalMisgeneralisation/results/gain-vs-factorised
JSON=$DATA/figures-data/gain-vs-factorised/e12
MD=$OUT/E12.md
mkdir -p "$LOG" "$OUT" "$JSON"
L=$LOG/e12.log
say() { echo "[$(date -u +%H:%M:%S)] $*" >> "$L"; }
cd "$SNAP" || { say "NO SNAPSHOT"; exit 1; }

cat > "$MD" <<'PREAMBLE'
# E12: what the DRC propagates, and where value enters it

Run by the chain on the pod (`/workspace/e12_chain.sh`), from the frozen
snapshot `/workspace/gvf-e12-snap`. Code: `goalmisgen/analysis/field_decomp.py`,
`scripts/field_decomp.py`, `tests/test_field_decomp.py` (8 pass).

## What is measured

Four observation variants on the SAME teacher-forced positions -- both
objectives, only the richer, only the poorer, neither -- so every variant sees
identical states and the later ticks stay comparable. Per site, step and maze
cell:

    A_c = h(only c) - h(neither)      what is there because objective c is
    D   = h(both)  - h(neither)
    I   = D - A_rich - A_poor         what the two do only together

## How to read each table

**baseline distance** -- rms(h_neither - h_both) / rms(h_both). The
objective-free observation is off distribution; this says how far, and so how
much the subtraction can be trusted. Large values mean the A_c are differences
between distant states, not local perturbations.

**combination** -- least squares `D ~ alpha A_near + gamma A_far`, fitted only
where both fields are present, `near` chosen by BFS distance (geometry, not
magnitude, so no selection bias). Superposition predicts (1, 1) -- hypothesis
B, salience-weighted diffusion. Winner-take-all predicts (1, 0) -- hypothesis
A, a utility field with competition. `gamma` is how much of the further
objective survives. `|I|/|D|` is the raw non-additivity; a ConvLSTM is
non-linear everywhere, so this is never exactly zero, which is why the fitted
gamma is the statistic to read.

**where a value manipulation lands** -- the decisive test. Under a value
change, `dh(both) = dh(neither) + dA_rich + dA_poor + dI`, and the columns are
each term's share of the total energy. Weight in `dA_c` means value rides the
field, i.e. it is at the source (A or B). Weight in `dI` means value acts where
the two objectives meet, i.e. at the comparison (C, factorised). Weight in
`neither` is a bias needing no objective at all (E8 found that component
carries 0-13% of the threshold shift).

**field shape and propagation** -- the field's size against BFS distance from
its own objective. A straight line in `ln size` is exponential decay
(discounted); a straight line in size itself is a cost-subtracted utility,
which is what gamma=1 plus a step penalty would give. `BFS R^2` against
`grid R^2` is propagation against blur: a convolution spreads in grid distance
whatever the walls do, so a field that follows the maze is routing around
them. Read down the `step` column for growth over steps.

**bridge** -- the two fields' sizes at the agent's own cell against the level's
distance gap. A planner that decides by comparing fields should show a strong
correlation and a crossing near the measured threshold.

## Caveats carried by every table

- One base per table; cross-base agreement is the check, see the sections below.
- The "neither" baseline is off distribution (first table bounds it).
- `gamma` is identifiable only where both fields overlap; the cell count is
  printed with it, and the fit reports `identifiable: false` if the two
  regressors are collinear.
- Sites are the DRC's own, read after each nonlinearity, cells once per tick.
- ResNet and ViT are NOT covered: they have no ticks, so propagation is depth,
  and they need `StateReader` rather than the DRC's reassembled step. That
  stage was not built.

PREAMBLE

run_base() {
  local base=$1 bright=$2
  say "$base start (bright $bright)"
  timeout 7200 $PY scripts/field_decomp.py "$DATA/runs/$base" \
    --levels "$DATA/levels/values/1.00-0.50@500k" --split test \
    --n-levels 256 --n-steps 4 --offset 0.30 --bright "$bright" \
    --json "$JSON/$base.json" > "$OUT/e12-$base.txt" 2> "$LOG/e12-$base.err" \
    && say "$base ok" || say "$base FAILED"
  {
    echo
    echo "## $base"
    echo
    echo '```'
    cat "$OUT/e12-$base.txt" 2>/dev/null
    echo '```'
  } >> "$MD"
  cp "$MD" "$DATA/figures-data/gain-vs-factorised/E12.md" 2>/dev/null
  say "E12_STAGE_DONE $base"
}

# Brightness standing in for +0.30 of the axis, from E6's per-base g = 1 + k dv.
run_base novalue11g1.s1234 1.52
run_base novalue11g1.s9012 1.49
run_base novalue11g1.s3456e 1.39
say "E12_CHAIN_DONE"
