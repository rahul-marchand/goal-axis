set -euo pipefail
export PATH=$HOME/.local/bin:$PATH
cd /workspace/GoalMisgeneralisation
until ! pgrep -f "verify2.sh" > /dev/null; do sleep 20; done
LOG=/workspace/data/outcome-keyed-rho0.txt
: > "$LOG"
echo "### same probe, rho=0.0: feature 0 now marks the LOWER-value objective" | tee -a "$LOG"
uv run python experiments/005_outcome_keyed_distance.py \
    /workspace/data/runs/clean11fv/local-files/cp_140206080 \
    --levels /workspace/data/levels11 --correlation 0.0 --think 0 4 2>&1 \
    | grep -viE "userwarning|logger\.warn|gym\.logger|^\s*$" | tee -a "$LOG"
echo "DONERHO0" | tee -a "$LOG"
