#!/usr/bin/env bash
set -uo pipefail
export PYTHONPATH=/workspace/gm-plan PYTHONUNBUFFERED=1 XLA_PYTHON_CLIENT_PREALLOCATE=false
PY=/workspace/GoalMisgeneralisation/.venv/bin/python
OUT=/workspace/data/offline/results
cd /workspace/gm-plan

# The proxy-trained model on its own correlation, the like-for-like of run 1.
echo "=== bc11.rho100.s1 on test.rho100 $(date -u +%H:%M:%S) ==="
$PY experiments/030_bc_rewrite_the_plan.py /workspace/data/offline/runs/bc11.rho100.s1 \
    --demos /workspace/data/offline/demos/test.rho100 --patch \
    --json $OUT/offline-bc-rewrite.bc11.rho100.s1.json > $OUT/offline-bc-rewrite.bc11.rho100.s1.txt 2>&1
echo "exit $? at $(date -u +%H:%M:%S)"

# Where the value evidence enters: patch only the two objective cells.
echo "=== objectives-only patch $(date -u +%H:%M:%S) ==="
$PY experiments/030_bc_rewrite_the_plan.py /workspace/data/offline/runs/bc11.rho050.s1 \
    --demos /workspace/data/offline/demos/test.rho050 --alphas 0.0 --arms plan \
    --patch --patch-cells objectives \
    --json $OUT/offline-bc-patch-objectives.bc11.rho050.s1.json \
    > $OUT/offline-bc-patch-objectives.bc11.rho050.s1.txt 2>&1
echo "exit $? at $(date -u +%H:%M:%S)"

# A second seed of the control, at the depth that moved.
echo "=== bc11.rho050.s2 depth 3 $(date -u +%H:%M:%S) ==="
$PY experiments/030_bc_rewrite_the_plan.py /workspace/data/offline/runs/bc11.rho050.s2 \
    --demos /workspace/data/offline/demos/test.rho050 --depths 3 --patch \
    --json $OUT/offline-bc-rewrite.bc11.rho050.s2.json > $OUT/offline-bc-rewrite.bc11.rho050.s2.txt 2>&1
echo "exit $? at $(date -u +%H:%M:%S)"
echo ALLDONE
