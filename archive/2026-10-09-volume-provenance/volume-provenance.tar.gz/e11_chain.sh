#!/bin/bash
# E11: does a route model with veridical distances hold value differently from the small one?
#   nohup bash /workspace/e11_chain.sh > /dev/null 2>&1 &
set -uo pipefail
ulimit -n $(ulimit -Hn)
export PYTHONUNBUFFERED=1 XLA_PYTHON_CLIENT_PREALLOCATE=false JAX_COMPILATION_CACHE_DIR=/workspace/data/jax-cache

SNAP=/workspace/gvf-e11-snap
PY=/workspace/GoalMisgeneralisation/.venv/bin/python
DATA=/workspace/data
RUNS=$DATA/offline/runs/scaling
DEMOS=$DATA/offline/demos/scaling
REPO=/workspace/GoalMisgeneralisation
OUT=$REPO/results/gain-vs-factorised
JSON=$DATA/figures-data/gain-vs-factorised
LOG=$DATA/logs/gvf
mkdir -p "$OUT" "$JSON" "$LOG"
cd $SNAP

L=$LOG/e11.log
say() { echo "[$(date -u +%H:%M:%S)] $*" >> $L; }
MODELS="d128l4 d256l4 d512l4 d512l16"

say "=== E11 start (snapshot $SNAP) ==="

# --- 1. token budget: what a cell token is made of, and what an input edit can reach
for m in $MODELS; do
  say "$m token budget"
  timeout 1800 $PY scripts/token_budget.py $RUNS/sc11.$m.s1 --demos $DEMOS --n-levels 256 \
    --json $JSON/token-budget-$m.json > $OUT/token-budget-$m.txt 2> $LOG/e11-token-$m.err \
    && say "$m token budget ok" || say "$m token budget FAILED"
done

# --- 2. brightness: is the response monotone, and does it move the right way?
for m in $MODELS; do
  say "$m brightness"
  timeout 7200 $PY scripts/input_gain_bc.py $RUNS/sc11.$m.s1 \
    --demos $DEMOS/test.rho100 --sweep o1 --steps 1000 --levels 2048 \
    --json $JSON/input-gain-sc11.$m.json > $OUT/input-gain-sc11.$m.o1.txt 2> $LOG/e11-gain-$m.err \
    && say "$m brightness ok" || say "$m brightness FAILED"
done

# --- 3. direction profile: is the axis's change a gain or a turn, per block?
for m in $MODELS; do
  say "$m direction profile"
  timeout 5400 $PY scripts/direction_profile.py $RUNS/sc11.$m.s1 --offline \
    --demos $DEMOS --n-levels 256 --sweep o1 --steps-tag 1000 \
    --json $JSON/direction-sc11.$m.json > $OUT/direction-sc11.$m.txt 2> $LOG/e11-dir-$m.err \
    && say "$m direction ok" || say "$m direction FAILED"
done
say "CHEAP_STAGES_DONE"

# --- 4. the two-parameter knobs at the embedding, two learning rates
#    2 scalars, so the dense default of 3e-4 barely moves them; 3e-2 and 1e-1.
edit() { # model family lr tag extra...
  local m=$1 fam=$2 lr=$3 tag=$4; shift 4
  say "$m $fam lr$lr"
  timeout 7200 $PY scripts/cheapest_edit.py $RUNS/sc11.$m.s1 --offline --demos $DEMOS \
    --family $fam --target soft --lr $lr --seeds 0 1 --steps 300 --n-edit 4096 --n-eval 2048 \
    --shifts -4 -2 2 4 --eval-shifts -8 -4 -2 2 4 8 --steps-tag 1000 --sweep o1 \
    --json $JSON/e11-$m.$tag.json --save-deltas $JSON/e11-$m.$tag.npz "$@" \
    > $OUT/e11-edit-sc11.$m.$tag.txt 2> $LOG/e11-edit-$m.$tag.err \
    && say "$m $fam lr$lr ok" || say "$m $fam lr$lr FAILED"
}
for m in $MODELS; do
  edit $m gain 3e-2 gain.lr3e-2
  edit $m rotation 3e-2 rotation.lr3e-2
done
say "KNOBS_LR1_DONE"
for m in $MODELS; do
  edit $m gain 1e-1 gain.lr1e-1
  edit $m rotation 1e-1 rotation.lr1e-1
done
say "KNOBS_LR2_DONE"

# --- 5. where value can live: module-restricted dense edits
mod() { # model tag modules...
  local m=$1 tag=$2; shift 2
  say "$m modules $tag"
  timeout 7200 $PY scripts/cheapest_edit.py $RUNS/sc11.$m.s1 --offline --demos $DEMOS \
    --family dense --target soft --seeds 0 1 --steps 300 --n-edit 4096 --n-eval 2048 \
    --shifts -4 -2 2 4 --eval-shifts -8 -4 -2 2 4 8 --steps-tag 1000 --sweep o1 \
    --json $JSON/e11-$m.$tag.json --save-deltas $JSON/e11-$m.$tag.npz "$@" \
    > $OUT/e11-edit-sc11.$m.$tag.txt 2> $LOG/e11-edit-$m.$tag.err \
    && say "$m modules $tag ok" || say "$m modules $tag FAILED"
}
for m in d512l4 d128l4; do
  mod $m embed --modules embed
  mod $m head --modules head
  mod $m late --modules "block 2 attention" "block 2 mlp" "block 3 attention" "block 3 mlp"
  mod $m early --modules "block 0 attention" "block 0 mlp" "block 1 attention" "block 1 mlp"
  mod $m all
done
say "E11_CHAIN_DONE"
