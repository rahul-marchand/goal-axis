set -euo pipefail
export PATH=$HOME/.local/bin:$PATH
cd /workspace/GoalMisgeneralisation
git fetch -q origin && git checkout -q probe-distance-field && git pull -q
LOG=/workspace/data/outcome-keyed.txt
: > "$LOG"
uv run python experiments/005_outcome_keyed_distance.py \
    /workspace/data/runs/clean11fv/local-files/cp_140206080 \
    --levels /workspace/data/levels11 --think 0 4 2>&1 \
    | grep -viE "userwarning|logger\.warn|gym\.logger|^\s*$" | tee -a "$LOG"
echo "DONE005" | tee -a "$LOG"
